# Based on the installer contribution by @alex-paradeyev (2026).
# Sourced by the shared installer; no discovery occurs until requested.
# Requires installer UI functions, build/base, and route-specific validation flags.
typeset -a bottles=() available=() steam_choices=()
typeset -A preferred_steam=() scanned_depths=()
bottle='' steam='' app=''
add_bottle() {
  local candidate=${1:a} found
  [[ $candidate != *[[:cntrl:]]* && -f $candidate/cxbottle.conf && -d $candidate/drive_c ]] || return 0
  for found in "${bottles[@]}"; do
    [[ ! $candidate -ef $found ]] || return 0
  done
  bottles+=("$candidate")
}
scan_bottles() {
  local folder=${1:a} depth=$2 found marker
  [[ -d $folder && $folder != / ]] && path_without_links "$folder" || return 0
  # A manual deeper search must not be skipped after a shallow automatic scan.
  # Use physical identity for deduplication; symlink paths were already refused.
  local identity=${folder:A}
  (( ${scanned_depths[$identity]:-0} < depth )) || return 0
  scanned_depths[$identity]=$depth
  while IFS= read -r -d '' marker; do
    add_bottle "${marker:h}"
  done < <(/usr/bin/find -P "$folder" -xdev -maxdepth "$depth" \
    \( -type d \( -name '.*' -o -name '*.app' -o -name drive_c -o -name dosdevices \) -prune \) \
    -o \( -type f -name cxbottle.conf -print0 \) 2>/dev/null)
}
discover_bottles() {
  local configured folder
  local config="$HOME/Library/Application Support/CrossOver/CrossOver.conf"
  bottles=()
  scanned_depths=()
  configured=$(/usr/bin/defaults read com.codeweavers.CrossOver BottleDir 2>/dev/null) || configured=''
  [[ $configured != /* ]] || scan_bottles "$configured" 4
  if [[ -f $config ]]; then
    configured=$(/usr/bin/awk '
      /^\[/ { active = ($0 == "[CrossOver]") }
      active && /^[[:space:]]*"BottlePath"[[:space:]]*=[[:space:]]*"/ {
        sub(/^[^=]*=[[:space:]]*"/, ""); sub(/"[[:space:]]*$/, ""); print; exit
      }' "$config")
    for folder in "${(@s/:/)configured}"; do
      [[ $folder != /* ]] || scan_bottles "$folder" 4
    done
  fi
  for folder in "${(@s/:/)${CX_BOTTLE_PATH:-}}"; do
    [[ $folder != /* ]] || scan_bottles "$folder" 4
  done
  scan_bottles "$HOME/Library/Application Support/CrossOver/Bottles" 3
  scan_bottles '/Library/Application Support/CrossOver/Bottles' 3
  if [[ -f ${base:h}/cxbottle.conf ]]; then
    add_bottle "${base:h}"
    scan_bottles "${base:h:h}" 4
  else
    scan_bottles "${base:h}" 2
  fi
  for folder in /Volumes/*(N/); do
    scan_bottles "$folder" 4
  done
}
bottle_issue() {
  local conf="$1/cxbottle.conf"
  if ! path_without_links "$conf" || ! path_without_links "$1/drive_c"; then
    print -r -- 'path contains a symbolic link'
  elif ! /usr/bin/grep -Eq '^"WineArch"[[:space:]]*=[[:space:]]*"win64"' "$conf"; then
    print -r -- 'requires a 64-bit bottle'
  elif (( require_preview )) && ! /usr/bin/grep -Eq '^"Preview"[[:space:]]*=[[:space:]]*"1"' "$conf"; then
    print -r -- 'requires a CrossOver Preview bottle'
  elif /usr/bin/grep -Eq "$bottle_guard_regex" "$conf"; then
    print -r -- 'CrossOver runtime paths are overridden'
  fi
}
add_steam() {
  local folder=$1 exe=$2 existing
  steam_path_ok "$folder" "$exe" || return 0
  for existing in "${steam_choices[@]}"; do
    if [[ $exe -ef $existing && ${exe:h} -ef ${existing:h} ]]; then return 0; fi
  done
  steam_choices+=("$exe")
}
find_steam() {
  local folder=$1 exe
  steam_choices=()
  path_without_links "$folder/drive_c" || return 0
  add_steam "$folder" "$folder/drive_c/Steam/Steam.exe"
  add_steam "$folder" "$folder/drive_c/Program Files (x86)/Steam/Steam.exe"
  while IFS= read -r -d '' exe; do
    add_steam "$folder" "$exe"
  done < <(/usr/bin/find -P "$folder/drive_c" -xdev -maxdepth 6 \
    \( -type d \( -iname windows -o -iname steamapps -o -iname appcache -o -iname depotcache \) -prune \) \
    -o \( -type f -iname Steam.exe -print0 \) 2>/dev/null)
  if [[ -n ${preferred_steam[$folder]:-} ]]; then
    add_steam "$folder" "$preferred_steam[$folder]"
  fi
}
show_bottles() {
  local folder issue exe
  available=()
  section 'CrossOver Bottles'
  (( $#bottles )) || notice 'No bottles found. You can enter a folder manually.'
  for folder in "${bottles[@]}"; do
    issue=$(bottle_issue "$folder")
    find_steam "$folder"
    if [[ -z $issue && $#steam_choices == 0 ]]; then issue='Steam.exe not found'; fi
    if [[ -z $issue ]]; then
      available+=("$folder")
      print -r -- "  ${good}[$#available]${reset}  ${folder:t}"
    else
      print -r -- "  ${warn}[–]${reset}  ${folder:t}  ${dim}· $issue${reset}"
    fi
    print -r -- "       ${dim}$folder${reset}"
    for exe in "${steam_choices[@]}"; do
      print -r -- "       ↳ ${exe#"$folder/"}"
    done
    print
  done
}
manual_bottle() {
  local target folder
  ask 'Drag in a bottle folder, a folder containing bottles, or Steam.exe (0 to go back):'
  [[ $REPLY != 0 ]] || return 0
  if ! parse_location "$REPLY"; then
    notice 'Enter the full path to a folder or Steam.exe.'
    return 0
  fi
  target=$REPLY
  if [[ -d $target ]]; then
    scanned_depths[${target:A}]=0
    scan_bottles "$target" 4
  elif [[ ${target:t:l} == steam.exe ]]; then
    folder=${target:h}
    while [[ $folder != / && ${folder:t} != drive_c ]]; do folder=${folder:h}; done
    if [[ $folder != / && -f ${folder:h}/cxbottle.conf ]] && steam_path_ok "${folder:h}" "$target"; then
      add_bottle "${folder:h}"
      preferred_steam[${folder:h}]=$target
    else
      notice 'Choose a regular Steam.exe file inside the bottle’s drive_c folder.'
    fi
  else
    notice 'Folder or Steam.exe not found at that path.'
  fi
}
pick_steam() {
  local n exe issue
  issue=$(bottle_issue "$bottle")
  [[ -z $issue ]] || { notice "$issue"; return 1; }
  find_steam "$bottle"
  (( $#steam_choices )) || return 1
  if (( $#steam_choices == 1 )); then steam=$steam_choices[1]; return 0; fi
  section "Steam · ${bottle:t}"
  for (( n=1; n<=$#steam_choices; ++n )); do
    exe=$steam_choices[n]
    print -rl -- "  [$n]  $(steam_windows_path "$bottle" "$exe")" "       $exe"
  done
  while true; do
    ask 'Select a Steam installation (0 to go back):'
    [[ $REPLY != 0 ]] || return 1
    if valid_number "$REPLY" "$#steam_choices"; then
      steam=$steam_choices[REPLY]
      return 0
    fi
    notice 'Enter a number from the list.'
  done
}
pick_bottle() {
  discover_bottles
  while true; do
    show_bottles
    print -r -- '  [M]  Enter a path    [R]  Scan again    [0]  Back'
    ask 'Select a bottle:'
    case ${REPLY:l} in
      0) return 1 ;;
      m) manual_bottle ;;
      r) discover_bottles ;;
      *)
        if valid_number "$REPLY" "$#available"; then
          bottle=$available[REPLY]
          pick_steam && return 0
        else
          notice 'Enter an available bottle number, M, R, or 0.'
        fi ;;
    esac
  done
}

app_build() {
  /usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$1/Contents/Info.plist" 2>/dev/null
}
pick_app() {
  local candidate n
  local -a matches=()
  for candidate in /Applications/*.app(N/) "$HOME"/Applications/*.app(N/); do
    [[ $candidate != *[[:cntrl:]]* && -f $candidate/Contents/Info.plist && -d $candidate/Contents/SharedSupport/CrossOver ]] || continue
    [[ $(app_build "$candidate") != $build ]] || matches+=("$candidate")
  done
  if (( $#matches == 1 )); then app=$matches[1]; return 0; fi
  section "CrossOver · $build"
  (( $#matches )) || notice 'The required build was not found in Applications.'
  for (( n=1; n<=$#matches; ++n )); do
    print -r -- "  [$n]  $matches[n]"
  done
  while true; do
    ask 'Select a number or drag in the matching CrossOver app (0 to go back):'
    [[ $REPLY != 0 ]] || return 1
    if valid_number "$REPLY" "$#matches"; then app=$matches[REPLY]; return 0; fi
    if parse_location "$REPLY" && [[ -d $REPLY/Contents/SharedSupport/CrossOver && $(app_build "$REPLY") == $build ]]; then
      app=$REPLY
      return 0
    fi
    notice "This package requires CrossOver build $build."
  done
}
