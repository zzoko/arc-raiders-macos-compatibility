"""Create an ARC-only PE sibling, guarded to the exact audited Preview build."""
from pathlib import Path
import hashlib, json, sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 patch-preview-tls.py /absolute/private/CrossOver')
root = Path(sys.argv[1]).expanduser().resolve()
source = root / 'lib/wine/x86_64-windows/ntdll.dll'
target = source.with_name('ntdll-arc.dll')
original = source.read_bytes()
GUARDED = {  # exact input ntdll -> (TLS site offset, sha256 of the 0x6e-byte site)
    '6c57653f9b42668fffe90c8cc36ed0434825fc43880b40cb8b80b9df3a2c45a9': (0x6269a, '2eab99d1cfa4a2ac7e9f22e5a52abb4ce029590e946ec4194f5e6366476e4f93'),  # 27.0.0.40734 NotProton runner
    '6b8dab5e4f32d95b33ac7b7ba1920de05ba2fbaa7111264afa4505cf0f04adb2': (0x6269a, '2eab99d1cfa4a2ac7e9f22e5a52abb4ce029590e946ec4194f5e6366476e4f93'),  # 27.0.0.40734 vendor
    '901bff9138707d90efecc592bd9bd3062075a350add4b3a283b089c1da635a61': (0x6291a, '0fc3c64d7bcaaf45800da8856129c7803206f4a78197e1dc64ea535e96efa219'),  # 27.0.0.41073 NotProton 1.2.x runner
    'f489347e59d4e8b43c2b0d2abbff9ee31e2059d45fd75fc04e2f4c0d8b04464a': (0x6291a, '0fc3c64d7bcaaf45800da8856129c7803206f4a78197e1dc64ea535e96efa219'),  # 27.0.0.41073 vendor
    'ef878e75661de8d955a42dc2fc76a84ca95574d48923dfc7f3f7db04a4d4f2b6': (0x30f11, 'e86b990a3c765b0aa1767367b93c31b135d325fafddc6c75aebcf6d60d9dd51c'),  # 27.0.0.41303 vendor
    '503c4a6f71822b212bcfaaf210ba76e838998fa2c61957a64e5c0da3f9b3a6e9': (0x30f11, 'e86b990a3c765b0aa1767367b93c31b135d325fafddc6c75aebcf6d60d9dd51c'),  # 27.0.0.41303 runner
}
digest = hashlib.sha256(original).hexdigest()
assert digest in GUARDED, 'Unsupported ntdll.dll input'
offset, region = GUARDED[digest]
expected = bytes.fromhex('756b' if offset == 0x30f11 else '756c')
assert original[offset:offset + 2] == expected
if region: assert hashlib.sha256(original[offset:offset + 0x6e]).hexdigest() == region
patched = bytearray(original)
patched[offset] = 0xeb  # Unconditional skip of CW18756; mirrors the 26.3 source deletion.
target.write_bytes(patched)
assert source.read_bytes() == original
record = {'source': str(source), 'target': str(target), 'offset': hex(offset),
          'before': expected.hex(), 'after': bytes(patched[offset:offset+2]).hex(),
          'original_sha256': hashlib.sha256(original).hexdigest(),
          'patched_sha256': hashlib.sha256(patched).hexdigest(),
          'scope': 'Companion selects this sibling only for opted-in ARC/probe processes'}
print(json.dumps(record, indent=2))
