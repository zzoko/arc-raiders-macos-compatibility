#!/bin/zsh
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL EXTENDED_GLOB
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
umask 077
base=${0:A:h}; support="$base/Support"
profile=bottle; build=26.3.0.39832; short=26.3
root="$HOME/Library/Application Support/ARC Raiders Compatibility"
version=$(<"$support/version.txt")
dest="$root/$short-$version-$profile"
source "$support/lib/installer-ui.zsh"
preview=0 list_only=0
case ${1:-} in
  '') ;;
  --preview) preview=1 ;;
  --list-bottles) list_only=1 ;;
  --help|-h)
    print -r -- 'Install.command [--preview]'
    print -r -- '  --preview       Select locations and review the plan without installing'
    print -r -- '  --list-bottles  List discovered bottles and their Steam installations'
    exit 0 ;;
  *) fail "Unknown argument: $1" ;;
esac
(( $# <= 1 )) || fail 'Choose one command-line option.'
finish() {
  local code=$?
  if [[ -t 0 && -t 1 && $preview == 0 && $list_only == 0 ]]; then
    print -nr -- $'\n  Press Enter to close… '
    IFS= read -r _ || true
  fi
  return $code
}
trap finish EXIT
source "$support/lib/steam-paths.zsh"
require_preview=0
bottle_guard_regex='^"(BinPath|LibPath|DllPath|CX_ROOT|ARC_[A-Z0-9_]+)"[[:space:]]*='
source "$support/lib/bottle-discovery.zsh"

prepare_launch() {
  while true; do
    pick_bottle || return 1
    pick_app && break
  done
  args+=(--crossover "$app")
}
show_plan() {
  section 'Installation plan'
  print -rl -- '  ARC Raiders · CrossOver 26.3 — CrossOver Steam bottle' "  Runtime: $dest"
  print -rl -- "  CrossOver: $app" "  Bottle: $bottle" \
    "  Steam: $(steam_windows_path "$bottle" "$steam")" "         $steam" \
    '  Launcher: ARC Raiders (Patched), inside the selected bottle'
  if [[ -f ${steam:h}/steamapps/appmanifest_1808500.acf ]]; then
    print -r -- "  ${good}✓${reset} Game manifest found in this Steam library."
  else
    notice 'Game manifest not found here; the game may be in another Steam library.'
  fi
}
install_flow() {
  local -a args=()
  while true; do
    args=(--profile "$profile" --destination "$dest")
    prepare_launch || return 0
    show_plan
    if (( preview )); then
      print -r -- '  Preview complete. Nothing was installed or changed.'
      return 0
    fi
    ask 'Start installation? [y/N] (B to change selection)'
    case ${REPLY:l} in
      y|yes) break ;;
      b) continue ;;
      *) print -r -- '  Installation canceled.'; return 0 ;;
    esac
  done
  /bin/zsh "$support/install.zsh" --check "${args[@]}"
  if [[ -d $dest/CrossOver ]]; then
    /bin/zsh "$support/lib/bottle.zsh" --runtime "$dest/CrossOver" \
      --bottle "$bottle" --steam-exe "$steam" --dry-run
  fi
  if [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) != *enabled* ]]; then
   print -r -- 'The private runtime needs macOS Developer Tools authorization for its startup setup.
This is a system authorization setting; it does not require installing Xcode.
macOS will ask for an administrator password. No game is being launched.'
   read -r 'allow?Enable this authorization now? [y/N]: '
   [[ ${allow:l} == y || ${allow:l} == yes ]] || fail 'Setup cancelled; authorization was not changed.'
   /usr/bin/osascript -e 'do shell script "/usr/sbin/DevToolsSecurity -enable" with administrator privileges' || fail 'Administrator authorization was cancelled or failed.'
   [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) == *enabled* ]] || fail 'macOS has not enabled the required authorization.'
  fi
  /bin/zsh "$support/install.zsh" --install "${args[@]}"
  /bin/zsh "$support/install.zsh" --verify --destination "$dest"
   /bin/zsh "$support/lib/bottle.zsh" --runtime "$dest/CrossOver" --bottle "$bottle" --steam-exe "$steam"
   print -r -- "Ready: reopen the matching CrossOver app, select ${bottle:t}, and double-click ARC Raiders (Patched).
Graphics settings stay in the CrossOver bottle panel. Close other apps in that bottle before switching runtimes."
}

print -rl -- "${accent}ARC Raiders / Compatibility installer${reset}" \
  'CrossOver 26.3 — CrossOver Steam bottle' "  $version · Apple Silicon · macOS 27 · automatic compatibility check"
if (( list_only )); then discover_bottles; show_bottles; exit 0; fi
if (( preview )); then install_flow; exit 0; fi
section 'Actions'
print -rl -- '  [1] Install / update' '  [2] Verify installed runtime and launcher' \
  '  [3] Restore previous launcher' '  [4] Remove launcher (preserve game and runtime)' \
  '  [5] Clear D3DMetal shader cache' '  [0] Exit'
while true; do
  ask 'Select an action:'
  case $REPLY in
    0) exit 0 ;;
    1) install_flow; exit 0 ;;
    2)
      /bin/zsh "$support/install.zsh" --verify --destination "$dest"
      /bin/zsh "$support/lib/$profile.zsh" --verify
      exit 0 ;;
    3|4)
      if [[ $REPLY == 3 ]]; then mode=--rollback; else mode=--remove; fi
      ask 'Confirm launcher action? [y/N]'
      if confirmed "$REPLY"; then /bin/zsh "$support/lib/$profile.zsh" "$mode"; fi
      exit 0 ;;
    5)
      cache_dir="$(/usr/bin/getconf DARWIN_USER_CACHE_DIR)d3dm/PioneerGame.exe"
      if /usr/bin/pgrep -if 'PioneerGame.exe' >/dev/null; then fail 'Quit ARC Raiders before clearing the cache.'; fi
      if [[ -d $cache_dir ]]; then
        ask 'Clear the shader cache? [y/N]'
        if confirmed "$REPLY"; then
          /bin/rm -rf -- "$cache_dir"
          print -r -- '  Shader cache cleared. It will rebuild on the next launch.'
        fi
      else print -r -- '  No shader cache found.'; fi
      exit 0 ;;
    *) notice 'Enter an action number from the menu.' ;;
  esac
done
