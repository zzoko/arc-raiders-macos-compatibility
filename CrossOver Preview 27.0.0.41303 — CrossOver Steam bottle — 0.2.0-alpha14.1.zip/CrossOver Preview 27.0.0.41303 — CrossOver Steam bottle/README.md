# CrossOver Preview 27.0.0.41303 — CrossOver Steam bottle

ARC Raiders compatibility installer **0.2.0-alpha14.1**.

## What you need

- An Apple Silicon Mac running **macOS 27.x**, with Rosetta installed.
  **macOS 27.2 or 27.2.1 is required to use the improved Wine performance optimization.**
- Your own **CrossOver Preview 20261111 (build 27.0.0.41303)**: `crossover-preview-20261111.zip`
  from CodeWeavers' Preview Center (not the `arm64` download), Steam account and ARC Raiders license.
- This package supports exactly that Preview build; other Preview builds are rejected.
- Windows Steam installed and signed in inside a **64-bit CrossOver bottle**, with
  ARC Raiders downloaded. Use the same bottle you normally use for Windows Steam.
  Create or import the bottle with the matching Preview app first; its wrapper
  does not launch stable CrossOver bottles directly.

NotProton is not needed for this download. The installer checks the actual Rosetta
components and CPU behavior automatically; no exact macOS build number, Xcode,
Python or compiler is required. If startup authorization is needed, it explains
the system setting and asks before showing macOS's administrator prompt.

## Install and play

1. Extract the entire ZIP. Keep `Install.command` beside `Support`.
2. Close the Windows applications running in the chosen bottle.
3. Open **Install.command**, choose **1 — Install / update**, and select the
   Steam bottle and matching CrossOver app when prompted. Standard and custom
   Steam locations are supported; review the paths before confirming installation.
4. Reopen CrossOver to refresh its icons. Select that bottle and launch
   **ARC Raiders (Patched)**. This starts Windows Steam and ARC using the patched
   runtime. The ordinary Steam icon continues to use the original runtime.
5. Let the initial shaders compile, then try the Practice Range.

Use the bottle's normal CrossOver graphics settings. Select **D3DMetal** as the graphics backend. DLSS-to-MetalFX and High Resolution are optional; DLSS also needs a
suitable selection in the game's graphics menu. Close the bottle's applications
before changing runtimes or applying settings that require a restart.

## What gets installed

A private patched runtime is created under
`~/Library/Application Support/ARC Raiders Compatibility/` and an ARC launcher is
added inside the selected bottle. The installed CrossOver app, ordinary Steam icon
and game files are preserved. There is no second game download or Finder
Applications launcher to manage. Game and anti-cheat binaries are not patched.

## If something needs attention

- If macOS blocks the unsigned installer, use Finder's **Open** command and review
  the prompt. Compatibility-check failures write a report under
  `~/Library/Logs/ARC Raiders Compatibility`; the new launcher is not activated.
- Launch through **ARC Raiders (Patched)** to use the compatibility changes.
- The launcher supplies English (`-culture=en`) to avoid the observed missing-text
  startup screen.
- If startup reports an RTPSO/pipeline error, quit the game and try **5 — Clear D3DMetal shader cache**, then relaunch.

## Manage the installation

Open `Install.command` again: **2** verifies this package's installation, **3**
restores its previous launcher, and **4** removes its launcher while keeping the
game, bottle and runtime files. **5** clears the D3DMetal shader cache if the game freezes after long play (it rebuilds automatically). To update, run the newer package's installer.
Verification applies to an installation made by this package, not a separate
personal or manually patched runtime.

## Files in this download

- **Install.command** — install, verify, restore or remove the launcher.
- **README.md** — this setup guide.
- **Support/** — patches, automatic checks, source, rebuild instructions and
  license notices. Keep this folder intact; nothing inside needs manual editing.
- **release.json** — version and compatibility metadata.
- **SHA256SUMS.txt** — checksums for the extracted files.
