/* Native NTDLL identity only; no MSync state is read. */
static bool pf_cxcompat_matches(void *,void *,void **);
struct pf_sync_snapshot {unsigned char uuid[16],cache_signature[40],shm_signature[15];unsigned identity_guard;};
static const unsigned char pf_sync_uuid[16]={0x1e,0xcf,0x35,0xe8,0x8e,0x89,0x37,0x69,0xa2,0x0e,0x5a,0xea,0xd4,0xc2,0xcd,0x0f};
static const unsigned char pf_sync_cache_sig[40]={0x3d,0xff,0xff,0x07,0x00,0x77,0x6b,0x89,0xc1,0xc1,0xe9,0x0c,0x48,0x8d,0x15,0x22,0xca,0x04,0x00,0x48,0x8b,0x14,0xca,0x48,0x85,0xd2,0x74,0x56,0x25,0xff,0x0f,0x00,0x00,0xc1,0xe0,0x04,0x48,0x8d,0x0c,0x02};
static const unsigned char pf_sync_shm_sig[15]={0x3b,0x05,0x60,0x7b,0x06,0x00,0x7d,0x26,0x48,0x8b,0x0d,0x4f,0x7b,0x06,0x00};
static const unsigned char pf_wait_abi_wrapper[9]={0x40,0x0f,0xb6,0xf6,0xe9,0x37,0xb0,0xff,0xff};
static bool pf_sync_identity(uint64_t base,struct pf_sync_snapshot *s)
{
    struct mach_header_64 h;
    if(!pf_user_pointer(base) || pf_read(&h,base,sizeof(h),NULL)!=sizeof(h) || h.magic!=MH_MAGIC_64 ||
       h.cputype!=CPU_TYPE_X86_64 || !h.ncmds || h.ncmds>128 || h.sizeofcmds>65536)return false;
    uint64_t off=sizeof(h),end=off+h.sizeofcmds;bool found=false;
    for(unsigned i=0;i<h.ncmds;i++){
        struct load_command c;if(off+sizeof(c)>end || pf_read(&c,base+off,sizeof(c),NULL)!=sizeof(c) || c.cmdsize<sizeof(c) || off+c.cmdsize>end)return false;
        if(c.cmd==LC_UUID){if(c.cmdsize<24 || pf_read(s->uuid,base+off+8,16,NULL)!=16 || memcmp(s->uuid,pf_sync_uuid,16))return false;found=true;}
        off+=c.cmdsize;
    }
    if(!found || pf_read(s->cache_signature,base+0x44f8b,40,NULL)!=40 || memcmp(s->cache_signature,pf_sync_cache_sig,40) ||
       pf_read(s->shm_signature,base+0x19962,15,NULL)!=15 || memcmp(s->shm_signature,pf_sync_shm_sig,15))return false;
    s->identity_guard=7;return true;
}
/* Preserve the audited downstream normalization and CrossOver hook chain. */
static bool pf_match_wait_wrapper(void *exported,void *slot)
{
    uint64_t base=(uint64_t)exported-0x47310;unsigned char code[9];struct pf_sync_snapshot s={0};
    if((uint64_t)slot!=base+0x4c2d0 || !pf_sync_identity(base,&s) ||
       pf_read(code,(uint64_t)slot,9,NULL)!=9 || memcmp(code,pf_wait_abi_wrapper,9))return false;
    int32_t displacement;memcpy(&displacement,code+5,4);
    return (uint64_t)slot+9+(int64_t)displacement==(uint64_t)exported;
}
/* Validate before the baseline memory helper publishes its initial table.
 * Defer file wrapping until cxcompatdb's constructor has installed its hooks. */
static void pf_prepare(void *lib,void **replacement,struct service_table *table)
{
    int saved=errno;const char *flag=getenv("ARC_ASYNC_COMPLETION_FENCE");
    if(!flag||strcmp(flag,"1")){errno=saved;return;}
    static const char *names[8]={"NtCreateFile","NtOpenFile","NtClose","NtQueryPerformanceCounter","NtWaitForSingleObject","NtSetEvent","NtResetEvent","NtCreateUserProcess"};
    static const unsigned char args[8]={88,48,8,16,24,16,16,88};
    if(table->count!=266||!table->args||!replacement){errno=saved;return;}
    bool valid=true;
    for(unsigned k=0;k<8;k++){
        void *fn=dlsym(lib,names[k]);unsigned any=0,matched=0;size_t found=0;
        if(k==PF_WAIT&&pf_match_wait_wrapper(fn,replacement[4]))fn=replacement[4];
        for(size_t i=0;i<table->count;i++)if(fn&&replacement[i]==fn){any++;if(table->args[i]==args[k]){matched++;found=i;}}
        if(any!=1||matched!=1||(k==PF_QPC&&found!=0x31)||(k==PF_WAIT&&found!=4)||
           (k==PF_SET&&found!=14)||(k==PF_RESET&&found!=222))valid=false;
        pf_original[k]=fn;pf_indices[k]=found;
    }
    pf_current_teb=dlsym(lib,"NtCurrentTeb");
    if(!valid||!pf_current_teb){fprintf(stderr,"ARC_ASYNC_FENCE refused service identity\n");errno=saved;return;}
    pf_table=table;pf_prepared=true;errno=saved;
}
static void pf_after_cxcompatdb(void)
{
    int saved=errno;if(!pf_prepared||pf_active){errno=saved;return;}pf_prepared=false;
    void **current=__atomic_load_n(&pf_table->functions,__ATOMIC_ACQUIRE);void *base=NULL;
    static const unsigned char args[8]={88,48,8,16,24,16,16,88};bool valid=pf_table->count==266;
    for(unsigned k=0;k<8;k++)if(pf_indices[k]>=pf_table->count||pf_table->args[pf_indices[k]]!=args[k]||
       (k!=PF_CREATE&&k!=PF_PROCESS&&current[pf_indices[k]]!=pf_original[k]))valid=false;
    if(!valid||!pf_cxcompat_matches(current[pf_indices[PF_CREATE]],current[pf_indices[PF_PROCESS]],&base)){
        fprintf(stderr,"ARC_ASYNC_FENCE refused completed cxcompatdb chain\n");errno=saved;return;}
    void **replacement=malloc(pf_table->count*sizeof(void *));if(!replacement){errno=saved;return;}
    memcpy(replacement,current,pf_table->count*sizeof(void *));uint64_t now=pf_now();
    if(!now){free(replacement);errno=saved;return;}
    pf_real_create=current[pf_indices[PF_CREATE]];pf_real_open=pf_original[PF_OPEN];pf_real_close=pf_original[PF_CLOSE];
    pf_real_qpc=pf_original[PF_QPC];pf_real_wait=pf_original[PF_WAIT];pf_real_setevent=pf_original[PF_SET];pf_real_resetevent=pf_original[PF_RESET];
    void *wrappers[7]={pf_create,pf_open,pf_close,pf_qpc,pf_wait,pf_setevent,pf_resetevent};
    for(unsigned k=0;k<7;k++)replacement[pf_indices[k]]=wrappers[k];
    pf_start=now;pf_enabled=true;
    __atomic_store_n(&pf_table->functions,replacement,__ATOMIC_RELEASE);pf_active=true;
    fprintf(stderr,"ARC_ASYNC_FENCE ready: 7 services, exact provider, bound100ms\n");errno=saved;
}
static bool pf_cxcompat_matches(void *create,void *process,void **base_out)
{
    static const unsigned char expected_uuid[16]={0x18,0x64,0xf5,0x5b,0x3c,0xf7,0x36,0x97,0x98,0x53,0x81,0x46,0x0f,0xb6,0x3a,0x47};
    static const unsigned char create_entry[32]={0x55,0x48,0x89,0xe5,0x41,0x57,0x41,0x56,0x41,0x55,0x41,0x54,0x53,0x48,0x81,0xec,0x88,0x00,0x00,0x00,0x44,0x8b,0x75,0x30,0x4c,0x8b,0x6d,0x28,0x44,0x8b,0x65,0x20};
    static const unsigned char process_entry[32]={0x55,0x48,0x89,0xe5,0x41,0x57,0x41,0x56,0x41,0x55,0x41,0x54,0x53,0x48,0x81,0xec,0xe8,0x00,0x00,0x00,0x4d,0x89,0xcc,0x4c,0x8b,0x4d,0x30,0x49,0x8b,0x01,0x48,0x83};
    Dl_info info;
    if(!create || !process || !dladdr(create,&info) || !info.dli_fname) return false;
    const char *name=strrchr(info.dli_fname,'/'); name=name?name+1:info.dli_fname;
    uint64_t base=(uint64_t)info.dli_fbase;
    if(strcmp(name,"cxcompatdb.so") || (uint64_t)create!=base+0x4b00 || (uint64_t)process!=base+0x5380) return false;
    struct mach_header_64 h;
    if(pf_read(&h,base,sizeof(h),NULL)!=sizeof(h) || h.magic!=MH_MAGIC_64 || h.cputype!=CPU_TYPE_X86_64 ||
       h.ncmds>512 || h.sizeofcmds>1048576) return false;
    uint64_t cursor=base+sizeof(h),end=cursor+h.sizeofcmds; bool uuid=false;
    for(uint32_t i=0;i<h.ncmds;i++) {
        struct load_command c;
        if(cursor>end || end-cursor<sizeof(c) || pf_read(&c,cursor,sizeof(c),NULL)!=sizeof(c) || c.cmdsize<sizeof(c) || c.cmdsize>end-cursor) return false;
        if(c.cmd==LC_UUID) {
            struct uuid_command u;
            if(c.cmdsize!=sizeof(u) || pf_read(&u,cursor,sizeof(u),NULL)!=sizeof(u) || memcmp(u.uuid,expected_uuid,16)) return false;
            uuid=true;
        }
        cursor+=c.cmdsize;
    }
    unsigned char code[32];
    if(!uuid || pf_read(code,(uint64_t)create,32,NULL)!=32 || memcmp(code,create_entry,32) ||
       pf_read(code,(uint64_t)process,32,NULL)!=32 || memcmp(code,process_entry,32)) return false;
    *base_out=info.dli_fbase; return true;
}
