"""Preserve Wine syscall-export ordering for ARC Raiders on Preview 41303.
Run after patch-preview-tls.py on a private CrossOver runtime.
All four ordinary exports retain their original implementations.
"""
from pathlib import Path
import hashlib, json, struct, sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: patch-preview-export-order.py /absolute/private/CrossOver')
path = Path(sys.argv[1]).resolve() / 'lib/wine/x86_64-windows/ntdll-arc.dll'
original = path.read_bytes()
assert hashlib.sha256(original).hexdigest() in {
    'd253fa43c9822fd720ac63509d8e33b88fa8a9084a75e6017704c9fb2a6227a8',
    '09e72a99d99619e1ff6ee7265492746221540b1d459a142a3d6cbbaf15c8f9f4',
}, 'Requires the audited Preview 41303 TLS-compatible sibling'
data = bytearray(original)
u16 = lambda o: struct.unpack_from('<H', data, o)[0]
u32 = lambda o: struct.unpack_from('<I', data, o)[0]
pe = u32(0x3c)
optional = pe + 24
sections = []
for i in range(u16(pe + 6)):
    pos = optional + u16(pe + 20) + i * 40
    size, rva, raw_size, raw = struct.unpack_from('<IIII', data, pos + 8)
    sections.append((data[pos:pos + 8].rstrip(b'\0'), pos, size, rva, raw_size, raw))

def offset(rva):
    for _, _, size, base, raw_size, raw in sections:
        if base <= rva < base + max(size, raw_size):
            return raw + rva - base
    raise ValueError(hex(rva))

export = offset(u32(optional + 112))
functions = offset(u32(export + 28))
names = offset(u32(export + 32))
ordinals = offset(u32(export + 36))
expected = {'NtdllDefWindowProc_A': 0x4a050, 'NtdllDefWindowProc_W': 0x4a060,
            'NtdllDialogWndProc_A': 0x4a0f0, 'NtdllDialogWndProc_W': 0x4a100}
text = next(s for s in sections if s[0] == b'.text')
_, header, size, base, raw_size, raw = text
start = (size + 15) & ~15
assert start + 64 <= raw_size
assert data[raw + start:raw + start + 64] == b'\xcc' * 64
changes = []
for i in range(u32(export + 24)):
    name_pos = offset(u32(names + i * 4))
    name = data[name_pos:data.index(0, name_pos)].decode()
    if name not in expected:
        continue
    slot = functions + u16(ordinals + i * 2) * 4
    target = u32(slot)
    assert target == expected[name]
    rva = base + start + len(changes) * 16
    # Tail jump keeps arguments, return address, registers and original code intact.
    code = b'\xe9' + struct.pack('<i', target - (rva + 5))
    data[offset(rva):offset(rva) + 5] = code
    struct.pack_into('<I', data, slot, rva)
    changes.append(dict(name=name, old=hex(target), new=hex(rva)))
assert len(changes) == 4
struct.pack_into('<I', data, header + 8, start + 64)
struct.pack_into('<I', data, optional + 64, 0)  # PE checksum is recomputed below.
checksum = 0
for i in range(0, len(data), 2):
    checksum += int.from_bytes(data[i:i+2], 'little')
    checksum = (checksum & 0xffff) + (checksum >> 16)
checksum = (checksum & 0xffff) + (checksum >> 16)
struct.pack_into('<I', data, optional + 64, checksum + len(data))
path.unlink()  # Do not mutate another runtime through a hard link.
path.write_bytes(data)
print(json.dumps({'input_sha256': hashlib.sha256(original).hexdigest(),
                  'output_sha256': hashlib.sha256(data).hexdigest(),
                  'exports': changes}, indent=2))
