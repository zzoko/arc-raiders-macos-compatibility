# CPU dispatch additions

This patch extends the adjacent CPU correction source. For recognized Rosetta
and Wine builds, raw invalid system calls enter Wine's normal dispatcher without
the host exception round trip. Wine still supplies the result and delivers its
instrumentation callbacks. Other calls, single stepping and unsupported layouts
retain the original handling. No game or anti-cheat binary is changed.

The loader also keeps NT flag conversion inside the original runtime function
boundaries. Host/runtime identities, entry instructions and the active Wine
prologue are checked before using the optimized path. Translation-cache misses
use the original path. `ARC_WINE_SYSCALL_DISPATCH=0` selects the previous handling.

Rebuild from this source folder with:

```sh
python3 build.py --output-dir /absolute/path/to/a/new/build-directory
```

The recipe validates the base source, applies `cpu.patch` to a new copy and builds
the two ARM CPU components. It does not install or modify an existing runtime.
All original source licences remain in the adjacent `cpu` directory.
