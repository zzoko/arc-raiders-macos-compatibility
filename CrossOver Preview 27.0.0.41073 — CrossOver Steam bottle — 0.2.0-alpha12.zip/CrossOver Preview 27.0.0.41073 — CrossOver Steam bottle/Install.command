#!/bin/zsh
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL EXTENDED_GLOB
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
umask 077

base=${0:A:h}
support="$base/Support"
source "$support/lib/steam-paths.zsh"
build=27.0.0.41073
version=$(<"$support/version.txt")
dest="$HOME/Library/Application Support/ARC Raiders Compatibility/Preview-$build-$version-bottle"
preview=0
list_only=0
case ${1:-} in
  '') ;;
  --preview) preview=1 ;;
  --list-bottles) list_only=1 ;;
  --help|-h)
    print -r -- 'Install.command [--preview | --list-bottles]'
    print -r -- '  --preview       Choose a bottle and review the installation plan'
    print -r -- '  --list-bottles  Find bottles and their Steam installations'
    exit 0 ;;
  *) print -u2 -r -- "Unknown argument: $1"; exit 2 ;;
esac
(( $# <= 1 )) || exit 2

accent='' dim='' good='' warn='' reset=''
if [[ -t 1 && ${TERM:-dumb} != dumb && -z ${NO_COLOR:-} ]]; then
  accent=$'\e[1;36m' dim=$'\e[2m' good=$'\e[32m' warn=$'\e[33m' reset=$'\e[0m'
fi
typeset -a bottles=() available=() steam_choices=() scanned_roots=()
typeset -A preferred_steam=()
bottle='' steam='' app=''
section() { print -rl -- "" "${accent}── $1 ──${reset}"; }
notice() { print -r -- "  ${warn}• $1${reset}"; }
fail() { print -u2 -r -- "  ${warn}Error: $*${reset}"; exit 1; }
ask() {
  if [[ -t 0 && -t 1 ]]; then
    print -nr -- "  ${accent}$1${reset} "
  else
    print -r -- "  $1"
  fi
  IFS= read -r REPLY || REPLY=0
}
finish() {
  local code=$?
  if [[ -t 0 && -t 1 && $preview == 0 && $list_only == 0 ]]; then
    print -nr -- $'\n  Press Enter to close… '
    IFS= read -r _ || true
  fi
  return $code
}
trap finish EXIT
parse_location() {
  local input=$1
  # Finder drag-and-drop inserts shell escapes. Keep a literal path if it exists.
  if [[ ! -e $input ]]; then
    input=${input%%[[:blank:]]#}
    input=${(Q)input}
  fi
  [[ $input != '~/'* ]] || input="$HOME/${input#\~/}"
  [[ $input == /* && $input != *[[:cntrl:]]* ]] || return 1
  REPLY=${input:a}
}
valid_number() {
  [[ $1 == <1-9999> && $1 != 0* ]] && (( $1 <= $2 ))
}

add_bottle() {
  local candidate=${1:a} found
  [[ $candidate != *[[:cntrl:]]* && -f $candidate/cxbottle.conf && -d $candidate/drive_c ]] || return 0
  for found in "${bottles[@]}"; do
    [[ ! $candidate -ef $found ]] || return 0
  done
  bottles+=("$candidate")
}
scan_bottles() {
  local folder=${1:a} depth=$2 found marker
  [[ -d $folder && $folder != / ]] && path_without_links "$folder" || return 0
  for found in "${scanned_roots[@]}"; do
    [[ ! $folder -ef $found ]] || return 0
  done
  scanned_roots+=("$folder")
  while IFS= read -r -d '' marker; do
    add_bottle "${marker:h}"
  done < <(/usr/bin/find -P "$folder" -xdev -maxdepth "$depth" \
    \( -type d \( -name '.*' -o -name '*.app' -o -name drive_c -o -name dosdevices \) -prune \) \
    -o \( -type f -name cxbottle.conf -print0 \) 2>/dev/null)
}
discover_bottles() {
  local configured folder
  local config="$HOME/Library/Application Support/CrossOver/CrossOver.conf"
  bottles=()
  scanned_roots=()
  configured=$(/usr/bin/defaults read com.codeweavers.CrossOver BottleDir 2>/dev/null) || configured=''
  [[ $configured != /* ]] || scan_bottles "$configured" 4
  if [[ -f $config ]]; then
    configured=$(/usr/bin/awk '
      /^\[/ { active = ($0 == "[CrossOver]") }
      active && /^[[:space:]]*"BottlePath"[[:space:]]*=[[:space:]]*"/ {
        sub(/^[^=]*=[[:space:]]*"/, ""); sub(/"[[:space:]]*$/, ""); print; exit
      }' "$config")
    for folder in "${(@s/:/)configured}"; do
      [[ $folder != /* ]] || scan_bottles "$folder" 4
    done
  fi
  for folder in "${(@s/:/)${CX_BOTTLE_PATH:-}}"; do
    [[ $folder != /* ]] || scan_bottles "$folder" 4
  done
  scan_bottles "$HOME/Library/Application Support/CrossOver/Bottles" 3
  scan_bottles '/Library/Application Support/CrossOver/Bottles' 3
  if [[ -f ${base:h}/cxbottle.conf ]]; then
    add_bottle "${base:h}"
    scan_bottles "${base:h:h}" 4
  else
    scan_bottles "${base:h}" 2
  fi
  for folder in /Volumes/*(N/); do
    scan_bottles "$folder" 4
  done
}
bottle_issue() {
  local conf="$1/cxbottle.conf"
  if ! path_without_links "$conf" || ! path_without_links "$1/drive_c"; then
    print -r -- 'path contains a symbolic link'
  elif ! /usr/bin/grep -Eq '^"WineArch"[[:space:]]*=[[:space:]]*"win64"' "$conf"; then
    print -r -- 'requires a 64-bit bottle'
  elif ! /usr/bin/grep -Eq '^"Preview"[[:space:]]*=[[:space:]]*"1"' "$conf"; then
    print -r -- 'requires a CrossOver Preview bottle'
  elif /usr/bin/grep -Eq '^"(BinPath|LibPath|DllPath|CX_ROOT|ARC_[A-Z0-9_]+)"[[:space:]]*=' "$conf"; then
    print -r -- 'CrossOver runtime paths are overridden'
  fi
}
add_steam() {
  local folder=$1 exe=$2 existing
  steam_path_ok "$folder" "$exe" || return 0
  for existing in "${steam_choices[@]}"; do
    if [[ $exe -ef $existing && ${exe:h} -ef ${existing:h} ]]; then return 0; fi
  done
  steam_choices+=("$exe")
}
find_steam() {
  local folder=$1 exe
  steam_choices=()
  path_without_links "$folder/drive_c" || return 0
  add_steam "$folder" "$folder/drive_c/Steam/Steam.exe"
  add_steam "$folder" "$folder/drive_c/Program Files (x86)/Steam/Steam.exe"
  while IFS= read -r -d '' exe; do
    add_steam "$folder" "$exe"
  done < <(/usr/bin/find -P "$folder/drive_c" -xdev -maxdepth 6 \
    \( -type d \( -iname windows -o -iname steamapps -o -iname appcache -o -iname depotcache \) -prune \) \
    -o \( -type f -iname Steam.exe -print0 \) 2>/dev/null)
  if [[ -n ${preferred_steam[$folder]:-} ]]; then
    add_steam "$folder" "$preferred_steam[$folder]"
  fi
}
show_bottles() {
  local folder issue exe
  available=()
  section 'CrossOver Bottles'
  (( $#bottles )) || notice 'No bottles found. You can enter a folder manually.'
  for folder in "${bottles[@]}"; do
    issue=$(bottle_issue "$folder")
    find_steam "$folder"
    if [[ -z $issue && $#steam_choices == 0 ]]; then issue='Steam.exe not found'; fi
    if [[ -z $issue ]]; then
      available+=("$folder")
      print -r -- "  ${good}[$#available]${reset}  ${folder:t}"
    else
      print -r -- "  ${warn}[–]${reset}  ${folder:t}  ${dim}· $issue${reset}"
    fi
    print -r -- "       ${dim}$folder${reset}"
    for exe in "${steam_choices[@]}"; do
      print -r -- "       ↳ ${exe#"$folder/"}"
    done
    print
  done
}
manual_bottle() {
  local target folder
  ask 'Drag in a bottle folder, a folder containing bottles, or Steam.exe (0 to go back):'
  [[ $REPLY != 0 ]] || return 0
  if ! parse_location "$REPLY"; then
    notice 'Enter the full path to a folder or Steam.exe.'
    return 0
  fi
  target=$REPLY
  if [[ -d $target ]]; then
    scan_bottles "$target" 4
  elif [[ ${target:t:l} == steam.exe ]]; then
    folder=${target:h}
    while [[ $folder != / && ${folder:t} != drive_c ]]; do folder=${folder:h}; done
    if [[ $folder != / && -f ${folder:h}/cxbottle.conf ]] && steam_path_ok "${folder:h}" "$target"; then
      add_bottle "${folder:h}"
      preferred_steam[${folder:h}]=$target
    else
      notice 'Choose a regular Steam.exe file inside the bottle’s drive_c folder.'
    fi
  else
    notice 'Folder or Steam.exe not found at that path.'
  fi
}
pick_steam() {
  local n exe issue
  issue=$(bottle_issue "$bottle")
  [[ -z $issue ]] || { notice "$issue"; return 1; }
  find_steam "$bottle"
  (( $#steam_choices )) || return 1
  if (( $#steam_choices == 1 )); then steam=$steam_choices[1]; return 0; fi
  section "Steam · ${bottle:t}"
  for (( n=1; n<=$#steam_choices; ++n )); do
    exe=$steam_choices[n]
    print -rl -- "  [$n]  $(steam_windows_path "$bottle" "$exe")" "       $exe"
  done
  while true; do
    ask 'Select a Steam installation (0 to go back):'
    [[ $REPLY != 0 ]] || return 1
    if valid_number "$REPLY" "$#steam_choices"; then
      steam=$steam_choices[REPLY]
      return 0
    fi
    notice 'Enter a number from the list.'
  done
}
pick_bottle() {
  discover_bottles
  while true; do
    show_bottles
    print -r -- '  [M]  Enter a path    [R]  Scan again    [0]  Back'
    ask 'Select a bottle:'
    case ${REPLY:l} in
      0) return 1 ;;
      m) manual_bottle ;;
      r) discover_bottles ;;
      *)
        if valid_number "$REPLY" "$#available"; then
          bottle=$available[REPLY]
          pick_steam && return 0
        else
          notice 'Enter an available bottle number, M, R, or 0.'
        fi ;;
    esac
  done
}

app_build() {
  /usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$1/Contents/Info.plist" 2>/dev/null
}
pick_app() {
  local candidate n
  local -a matches=()
  for candidate in /Applications/*.app(N/) "$HOME"/Applications/*.app(N/); do
    [[ $candidate != *[[:cntrl:]]* && -f $candidate/Contents/Info.plist && -d $candidate/Contents/SharedSupport/CrossOver ]] || continue
    [[ $(app_build "$candidate") != $build ]] || matches+=("$candidate")
  done
  if (( $#matches == 1 )); then app=$matches[1]; return 0; fi
  section "CrossOver Preview · $build"
  (( $#matches )) || notice 'The required build was not found in Applications.'
  for (( n=1; n<=$#matches; ++n )); do
    print -r -- "  [$n]  $matches[n]"
  done
  while true; do
    ask 'Select a number or drag in CrossOver Preview.app (0 to go back):'
    [[ $REPLY != 0 ]] || return 1
    if valid_number "$REPLY" "$#matches"; then app=$matches[REPLY]; return 0; fi
    if parse_location "$REPLY" && [[ -d $REPLY/Contents/SharedSupport/CrossOver && $(app_build "$REPLY") == $build ]]; then
      app=$REPLY
      return 0
    fi
    notice "This package requires CrossOver Preview build $build."
  done
}
show_plan() {
  local manifest="${steam:h}/steamapps/appmanifest_1808500.acf"
  section 'Installation Plan'
  print -rl -- "  ${accent}CrossOver${reset}   $app" \
    "  ${accent}Bottle   ${reset}   ${bottle:t}" \
    "              $bottle" \
    "  ${accent}Steam    ${reset}   $(steam_windows_path "$bottle" "$steam")" \
    "              $steam" \
    "  ${accent}Launcher ${reset}   ARC Raiders (Patched)" \
    "  ${accent}Runtime  ${reset}   ~${dest#"$HOME"}"
  if [[ -f $manifest ]]; then
    print -r -- "  ${good}✓${reset} ARC Raiders manifest found in this Steam library."
  else
    print -r -- "  ${dim}· ARC Raiders may be in a different Steam library. The manifest was not found here.${reset}"
  fi
}
install_selected() {
  local -a args=(--profile bottle --destination "$dest" --crossover "$app")
  /bin/zsh "$support/install.zsh" --check "${args[@]}"
  if [[ -d $dest/CrossOver ]]; then
    /bin/zsh "$support/lib/bottle.zsh" --runtime "$dest/CrossOver" \
      --bottle "$bottle" --steam-exe "$steam" --dry-run
  fi
  if [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) != *enabled* ]]; then
    notice 'The private runtime requires macOS Developer Tools authorization.'
    ask 'Enable Developer Tools authorization now? [y/N]'
    case ${REPLY:l} in y|yes|д|да) ;; *) fail 'Installation canceled.' ;; esac
    /usr/bin/osascript -e 'do shell script "/usr/sbin/DevToolsSecurity -enable" with administrator privileges' || fail 'Developer Tools authorization failed or was canceled.'
    [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) == *enabled* ]] || fail 'Developer Tools authorization is still disabled.'
  fi
  /bin/zsh "$support/install.zsh" --install "${args[@]}"
  /bin/zsh "$support/install.zsh" --verify --destination "$dest"
  /bin/zsh "$support/lib/bottle.zsh" --runtime "$dest/CrossOver" --bottle "$bottle" --steam-exe "$steam"
  print -r -- "  ${good}✓${reset} Open ARC Raiders (Patched) in the \"${bottle:t}\" bottle."
}
install_flow() {
  while pick_bottle; do
    pick_app || continue
    show_plan
    if (( preview )); then
      print -rl -- "" "  ${good}✓${reset} Preview complete. No installation scripts were run."
      return 0
    fi
    ask 'Start installation? [y/N] (B to choose a different bottle)'
    case ${REPLY:l} in
      y|yes|д|да) install_selected; return 0 ;;
      b) continue ;;
      *) print -r -- '  Installation canceled.'; return 0 ;;
    esac
  done
}

print -rl -- "${accent}╭──────────────────────────────────────────────╮${reset}" \
  "${accent}│  ARC RAIDERS  /  CrossOver Installer         │${reset}" \
  "${accent}╰──────────────────────────────────────────────╯${reset}" \
  "  ${dim}CrossOver Preview $build · $version${reset}"
if (( list_only )); then
  discover_bottles
  show_bottles
  exit 0
fi
if (( preview )); then
  print -r -- "  ${warn}◇ PREVIEW · discovery and selection only${reset}"
  install_flow
  exit 0
fi
section 'Actions'
print -rl -- '  [1]  Install / update' \
  '  [2]  Verify installed runtime and launcher' \
  '  [3]  Restore previous launcher' \
  '  [4]  Remove launcher' \
  '  [5]  Clear D3DMetal shader cache' \
  '  [0]  Exit'
while true; do
  ask 'Select an action:'
  case $REPLY in
    0) exit 0 ;;
    1) install_flow; exit 0 ;;
    2)
      /bin/zsh "$support/install.zsh" --verify --destination "$dest"
      /bin/zsh "$support/lib/bottle.zsh" --verify
      exit 0 ;;
    3|4)
      if [[ $REPLY == 3 ]]; then mode=--rollback; else mode=--remove; fi
      ask 'Confirm launcher action? [y/N]'
      case ${REPLY:l} in y|yes|д|да) /bin/zsh "$support/lib/bottle.zsh" "$mode" ;; esac
      exit 0 ;;
    5)
      cache_dir="$(/usr/bin/getconf DARWIN_USER_CACHE_DIR)d3dm/PioneerGame.exe"
      /usr/bin/pgrep -if 'PioneerGame.exe' >/dev/null && fail 'Quit ARC Raiders before clearing the cache.'
      if [[ -d $cache_dir ]]; then
        ask 'Clear the shader cache? [y/N]'
        case ${REPLY:l} in
          y|yes|д|да)
            /bin/rm -r -- "$cache_dir"
            print -r -- '  Shader cache cleared. It will rebuild on the next launch.' ;;
        esac
      else
        print -r -- '  No shader cache found.'
      fi
      exit 0 ;;
    *) notice 'Enter an action number from the menu.' ;;
  esac
done
