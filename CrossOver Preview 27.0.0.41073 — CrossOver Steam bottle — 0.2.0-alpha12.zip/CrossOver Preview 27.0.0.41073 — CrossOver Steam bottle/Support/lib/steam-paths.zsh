# Shared by the bottle picker and launcher adapter. All paths are macOS paths.
path_without_links() {
  local component=${1:a}
  while [[ $component != / ]]; do
    [[ ! -L $component ]] || return 1
    component=${component:h}
  done
}

steam_path_ok() {
  local drive="$1/drive_c" exe=$2 relative
  [[ $exe == "$drive/"* && ${exe:t:l} == steam.exe && -f $exe ]] || return 1
  path_without_links "$exe" || return 1
  relative=${exe#"$drive/"}
  # Only accept paths that can be passed safely as Windows executable arguments.
  case $relative in
    *[[:cntrl:]]*|*\\*|*:*|*\"*|*\'*|*\<*|*\>*|*\|*|*\?*|*\**) return 1 ;;
  esac
  return 0
}

steam_windows_path() {
  local relative=${2#"$1/drive_c/"}
  print -r -- "C:\\${relative//\//\\}"
}
