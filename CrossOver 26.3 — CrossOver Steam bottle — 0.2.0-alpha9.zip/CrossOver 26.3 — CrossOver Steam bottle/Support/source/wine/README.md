# Source, reproducibility and future releases

The package changes Wine compatibility behavior. It does not patch game or anti-cheat binaries, forge anti-cheat results or remove authentication. The NT-flag and host-memory search defects are included in this release; unrelated future failures remain possible.

## Corresponding source

`wine-modified-source.tar.xz` contains the complete modified `sources/wine` tree used for the rebuilt Unix NTDLL and standard-bottle PE NTDLL. It comes from CodeWeavers' `crossover-sources-26.3.0.tar.gz`, original SHA-256:

`ac99c8ca4b3848f3e81784135f023df266b61c2345726ea55a50b3e030dd6872`

The five adjacent `.patch` files describe the modifications in application order:

1. `crossover26-gsbase-port.patch`: ARC-specific Windows GS/TLS compatibility and original-PE fallback for other processes.
2. `d3dmetal-dynamic-code-regions.patch`: register dynamic Windows executable regions through the graphics translation runtime.
3. `peb-image-key-missing-production.patch`: preserve native/WOW process-parameter flag semantics when the Image File Execution Options key is missing.
4. `mapped-all-executable-sections-production.patch`: register all relevant mapped executable sections.
5. `host-occupied-region-search.patch`: skip occupied Mach ranges after a genuine allocation collision; includes the shared search header.

The archive is already patched: **do not apply the patches to it again**. The patches can instead be applied in order to the unmodified Wine tree from the original archive. No NotProton donor-source patch is used in this build.

Source origin: [CodeWeavers source downloads](https://www.codeweavers.com/crossover/source). Wine is LGPL 2.1-or-later, subject to the per-file notices retained in the complete source. `../../licenses` contains Wine's license, authors and notices for the files changed here. The locally generated runtime also contains proprietary components supplied by the user's own CrossOver; those components are not included in this archive.

## Rebuild

`build-recipe.json` records the source/modified-file hashes, compiler versions, flags, artifact hashes, post-processing and validation. `rebuild.zsh OUTPUT_DIRECTORY` is a convenience implementation. It needs developer tools: Apple clang/SDK, a modern Bison and the recorded x86_64 MinGW toolchain. Normal installer users need none of these.

The recipe compiles only NTDLL targets with `MACOSX_DEPLOYMENT_TARGET=15.0`, maps source paths to `/arc-build`, removes debug-only data, and retains the two required native RPATHs. Compiler/SDK changes can change binary hashes; a different output needs new manifests and validation rather than ignoring a mismatch.

For the native-Steam profile, `build_candidate.py` reads the user's exact existing NotProton PE and original vendor PE. It performs two Wine compatibility changes: skip the macOS primary-TLS reservation block, and preserve process-parameter flags while retaining the displaced DebugFlags copy. `own-stub.S` is the complete original 16-byte leaf stub. `notproton-wine-edits.json` records offsets and expected/new bytes.

Every byte previously changed or added by NotProton remains unchanged. `make_additive_delta.py` generates a single BSDIFF40 control tuple, bytewise subtraction data and an empty extra stream. The compatibility patch has 24 nonzero diff bytes; the fallback-copy patch has zero. No complete DLL or bridge payload is shipped. These developer scripts write their outputs beside themselves; work on a copy in a build directory.

## Release maintenance

1. Keep the confirmed working install and user data untouched while testing a new runtime in an isolated directory.
2. Update the Wine source/patches or guarded PE recipe, rebuild, and repeat the behavior probes and game tests that exercise the change. A deployment target is not a substitute for testing that macOS version.
3. Increment `Support/version.txt`. Release versions are immutable: never publish different runtime bytes under an existing version.
4. Generate BSDIFF40 deltas using `bsdiff4==1.2.6` for rebuilt Wine files and the additive-only recipe for the existing NotProton PE. Retain the empty extra stream for the latter. End users apply deltas using macOS `bspatch`.
5. Update each profile's six-column TSV manifest: input-relative-path, output-relative-path, input-SHA256, patch-relative-path, patch-SHA256, output-SHA256. Update the separate dependency manifests only after validating the corresponding source runtime. A newer CrossOver build requires a deliberate port and installer changes; it must not silently pass the 26.3 guard.
6. Keep the original installed PE as `ntdll-stock.dll`, appropriate to each profile. Do not accidentally put the NotProton PE into the bottle profile or vice versa.
7. Exercise check/install/verify, unsupported inputs, changed destination refusal, idempotence, A→B update, rollback, removal, and paths with spaces/apostrophes. The adapters only switch after the core install has been verified. Inspect NotProton upstream changes before altering its pinned shim hash or transformation anchors.
8. Test through the real game launcher before promoting an alpha as confirmed. Include updated corresponding source and notices. Regenerate the file checksum list and ZIP checksum; publish no raw logs, prefixes, account data, complete runtime copies or copied NotProton launch shims.

Installed runtimes live in `~/Library/Application Support/ARC Raiders Compatibility/26.3-VERSION-PROFILE`. Adapter state is separate and stable across releases; it records current and previous launch choices. Prefixes/settings are not versioned with runtime binaries. This separation lets a later bug fix be installed or rolled back without rebuilding the game's prefix.

There is no online updater in this release. Deliver a new archive and rerun its console installer. Keep the previous archive for its matching full-runtime verification/removal command.

## NotProton integration boundary

The package contains our strict transformation recipe, not NotProton's `run` file, detour payload, bridge DLLs or runtime. The adapter reads the user's installed shim, checks its whole-file SHA-256, and produces a local copy with isolated paths and required environment settings. Upstream source reference: [NotProton](https://github.com/NotProtonNot/NotProton/tree/38af1d3bf9395b31389c93bb16fd72bf229da289). A local derivative generated during installation is distinct from including that code in this downloadable package.
