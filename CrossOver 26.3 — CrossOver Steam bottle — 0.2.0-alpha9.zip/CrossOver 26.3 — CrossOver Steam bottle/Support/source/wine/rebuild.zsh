#!/bin/zsh
# Developer-only Wine rebuild; not used by the installer.
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
(( $# == 1 )) || { print -u2 'Usage: rebuild.zsh NEW_OUTPUT_DIRECTORY'; exit 1; }
recipe=${0:A:h}; build_root=${1:a}
[[ ! -e $build_root ]] || { print -u2 'Use a new build directory.'; exit 1; }
for tool in clang clang++ x86_64-w64-mingw32-gcc x86_64-w64-mingw32-objcopy make bison; do
  command -v "$tool" >/dev/null || { print -u2 "Required developer tool missing: $tool"; exit 1; }
done
mkdir -p "$build_root/source" "$build_root/obj-portable" "$build_root/output"
tar -xJf "$recipe/wine-modified-source.tar.xz" -C "$build_root/source"
export CC='clang -arch x86_64' CXX='clang++ -arch x86_64'
export MACOSX_DEPLOYMENT_TARGET=15.0
export BISON=$(command -v bison)
export CFLAGS="-g -O2 -ffile-prefix-map=$build_root=/arc-build"
export CXXFLAGS=$CFLAGS CROSSCFLAGS=$CFLAGS
cd "$build_root/obj-portable"
"$build_root/source/sources/wine/configure" -C --build=x86_64-apple-darwin --host=x86_64-apple-darwin \
  --enable-win64 --without-freetype --without-x --without-gstreamer --without-alsa --without-pulse \
  --without-cups --without-v4l2 --without-oss
make -j6 dlls/ntdll/ntdll.so dlls/ntdll/x86_64-windows/ntdll.dll
cp dlls/ntdll/ntdll.so "$build_root/output/ntdll.so"
cp dlls/ntdll/x86_64-windows/ntdll.dll "$build_root/output/ntdll.dll"
x86_64-w64-mingw32-objcopy --strip-debug "$build_root/output/ntdll.dll"
if ! otool -l "$build_root/output/ntdll.so" | grep -q '@loader_path/../../../lib64'; then
  install_name_tool -add_rpath '@loader_path/../../../lib64' "$build_root/output/ntdll.so"
fi
strip -S "$build_root/output/ntdll.so"
shasum -a 256 "$build_root/output/ntdll.so" "$build_root/output/ntdll.dll"
print -r -- 'Build complete. Validate behavior and regenerate manifests before distribution.'
