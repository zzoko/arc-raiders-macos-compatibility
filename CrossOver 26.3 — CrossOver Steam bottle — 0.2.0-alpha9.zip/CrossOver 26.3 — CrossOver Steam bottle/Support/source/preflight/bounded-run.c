/* Bound our own test process group; never target other Wine sessions. */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
static volatile sig_atomic_t interrupted;
static void stop(int sig){interrupted=sig;}
int main(int argc,char **argv){
    if(argc<3)return 2;
    char *end;long seconds=strtol(argv[1],&end,10);
    if(*end || seconds<1 || seconds>300)return 2;
    signal(SIGINT,stop);signal(SIGTERM,stop);
    pid_t pid=fork();if(pid<0)return 2;
    if(!pid){setpgid(0,0);execv(argv[2],argv+2);perror("exec test");_exit(127);}
    setpgid(pid,pid);
    struct timespec start,now;clock_gettime(CLOCK_MONOTONIC,&start);
    int status=0;
    for(;;){
        pid_t r=waitpid(pid,&status,WNOHANG);
        if(r==pid)return WIFEXITED(status)?WEXITSTATUS(status):128+WTERMSIG(status);
        if(r<0 && errno!=EINTR)return 2;
        clock_gettime(CLOCK_MONOTONIC,&now);
        if(interrupted || now.tv_sec-start.tv_sec>=seconds){
            kill(-pid,SIGTERM);usleep(200000);kill(-pid,SIGKILL);
            while(waitpid(pid,&status,0)<0 && errno==EINTR){}
            fprintf(stderr,"Compatibility test %s\n",interrupted?"cancelled":"timed out");
            return interrupted?128+interrupted:124;
        }
        usleep(20000);
    }
}
