/* Independent Windows exception-context probe. No game dependencies. */
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
extern void context_probe(uint64_t *,uint64_t);
extern void nt_iret_probe(uint64_t *);
extern void nt_iret_load_probe(uint64_t *,uint64_t);
extern const unsigned char nt_iret_site[],nt_iret_resume[];
__asm__(".text\n.globl context_probe\ncontext_probe:\n"
"push %rbx\nmov %rcx,%rbx\npushfq\npopq 32(%rbx)\n"
"mov 32(%rbx),%rax\nandq $-16385,%rax\nor %rdx,%rax\npush %rax\npopfq\n"
"ud2\npushfq\npopq (%rbx)\npushq 32(%rbx)\npopfq\npop %rbx\nret\n"
".globl nt_iret_probe\nnt_iret_probe:\npush %rbx\nmov %rcx,%rbx\n"
"pushfq\npopq 32(%rbx)\npushfq\norq $0x4000,(%rsp)\npopfq\n"
"mov %rsp,%r10\nxor %eax,%eax\nmov %ss,%ax\npush %rax\npush %r10\n"
"pushfq\nxor %eax,%eax\nmov %cs,%ax\npush %rax\nlea nt_iret_resume(%rip),%rax\npush %rax\n"
".globl nt_iret_site\nnt_iret_site:\niretq\n"
".globl nt_iret_resume\nnt_iret_resume:\npushfq\npopq (%rbx)\n"
"pushq 32(%rbx)\npopfq\npop %rbx\nret\n"
".globl nt_iret_load_probe\nnt_iret_load_probe:\npush %rbx\nmov %rcx,%rbx\n"
"pushfq\npopq 32(%rbx)\nmov 32(%rbx),%r11\nandq $-16385,%r11\npush %r11\npopfq\nor %rdx,%r11\n"
"mov %rsp,%r10\nxor %eax,%eax\nmov %ss,%ax\npush %rax\npush %r10\npush %r11\n"
"xor %eax,%eax\nmov %cs,%ax\npush %rax\nlea 1f(%rip),%rax\npush %rax\niretq\n"
"1:\npushfq\npopq (%rbx)\npushq 32(%rbx)\npopfq\npop %rbx\nret\n");
static unsigned expected_in,wanted_out,seen,received,iret_fault,iret_frame_intact;
static LONG CALLBACK handler(EXCEPTION_POINTERS *e){
    CONTEXT *c=e->ContextRecord;
    if(c->Rip==(uintptr_t)nt_iret_site){
        iret_fault=e->ExceptionRecord->ExceptionCode;
        iret_frame_intact=(c->Rsp==c->R10-40) && ((c->EFlags&0x4000)!=0);
        c->Rsp=c->R10;c->Rip=(uintptr_t)nt_iret_resume;c->EFlags&=~0x4000;
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    if(e->ExceptionRecord->ExceptionCode!=EXCEPTION_ILLEGAL_INSTRUCTION)return EXCEPTION_CONTINUE_SEARCH;
    received++;
    seen=((c->EFlags&0x4000)!=0)==expected_in;
    c->EFlags=(c->EFlags&~0x4000)|(wanted_out?0x4000:0);
    c->Rip+=2;return EXCEPTION_CONTINUE_EXECUTION;
}
int main(void){
    setbuf(stdout,NULL);
    PVOID h=AddVectoredExceptionHandler(1,handler);if(!h)return 2;
    unsigned failed=0;
    for(unsigned in=0;in<2;in++)for(unsigned out=0;out<2;out++){
        expected_in=in;wanted_out=out;unsigned good=0;uint64_t r[5];
        for(int i=0;i<200;i++){seen=0;context_probe(r,in?0x4000:0);good+=seen && (((r[0]&0x4000)!=0)==out);}
        printf("exception NT=%u->%u context_and_restore=%u/200\n",in,out,good);
        failed+=good!=200;
    }
    uint64_t r[5];nt_iret_probe(r);
    printf("IRET with current NT=1 fault=%08x after=%llx (x86 requires GP)\n",iret_fault,r[0]);
    failed+=iret_fault!=EXCEPTION_ACCESS_VIOLATION || !iret_frame_intact || (r[0]&0x4000)!=0;
    for(unsigned nt=0;nt<2;nt++) {
        unsigned good=0;
        for(unsigned i=0;i<200;i++) {
            nt_iret_load_probe(r,nt?0x4000:0);
            good+=((r[0]&0x4000)!=0)==nt;
        }
        printf("IRET current NT=0 frame NT=%u restored=%u/200\n",nt,good);
        failed+=good!=200;
    }
    RemoveVectoredExceptionHandler(h);
    printf("failed_groups=%u exceptions=%u\n",failed,received);
    return failed?1:0;
}
