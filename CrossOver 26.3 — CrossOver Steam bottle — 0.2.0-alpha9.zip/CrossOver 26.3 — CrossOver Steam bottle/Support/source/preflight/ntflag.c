#include <windows.h>
#include <stdio.h>
#include <stdint.h>
extern void raw_ntflag(uint64_t *out);
__asm__(".text\n.globl raw_ntflag\nraw_ntflag:\n"
"push %rbx\nmov %rcx,%rbx\npushfq\npopq 32(%rbx)\n"
"pushfq\norq $0x4000,(%rsp)\npopfq\npushfq\npopq (%rbx)\n"
"mov $-1,%eax\nsyscall\nmov %r11,8(%rbx)\nmov %rax,24(%rbx)\npushfq\npopq 16(%rbx)\n"
"pushq 32(%rbx)\npopfq\npop %rbx\nret\n");
static DWORD WINAPI exercise(void *arg){uint64_t r[5];int fails=0;for(int i=0;i<1000;i++){raw_ntflag(r);if(!(r[0]&0x4000)||!(r[1]&0x4000)){if(fails++<3)printf("NT mismatch before=%llx R11=%llx after=%llx status=%llx\n",r[0],r[1],r[2],r[3]);}}printf("NT-bit raw invalid syscall thread=%lu before=%llx R11=%llx after=%llx status=%llx trials=1000 failures=%d\n",GetCurrentThreadId(),r[0],r[1],r[2],r[3],fails);return fails;}
int main(void){setbuf(stdout,NULL);DWORD fails=exercise(NULL),r=0;HANDLE t=CreateThread(NULL,0,exercise,NULL,0,NULL);WaitForSingleObject(t,INFINITE);GetExitCodeThread(t,&r);CloseHandle(t);return fails||r;}
