/* Source-independent compatibility experiment for the audited Preview build.
 * Wrap real Wine memory services, retain their results, and register successful
 * Windows executable mappings with the Preview's own Rosetta integration.
 * No game or anti-cheat module is modified. Only explicitly named processes opt in.
 */
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <crt_externs.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdarg.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int32_t status_t;
typedef uint32_t u32;
typedef uintptr_t uptr;
struct service_table { void **functions; void *counters; uptr count; unsigned char *args; };
struct memory_info { void *base, *allocation_base; u32 allocation_protect; u32 alignment1;
                     size_t size; u32 state, protect, type; u32 alignment2; };
static status_t (*real_alloc)(void *,void **,uptr,size_t *,u32,u32);
static status_t (*real_alloc_ex)(void *,void **,size_t *,u32,u32,void *,u32);
static status_t (*real_protect)(void *,void **,size_t *,u32,u32 *);
static status_t (*real_map)(void *,void *,void **,uptr,size_t,void *,size_t *,u32,u32,u32);
static status_t (*real_map_ex)(void *,void *,void **,const void *,size_t *,u32,u32,void *,u32);
static status_t (*real_query)(void *,const void *,u32,void *,size_t,size_t *);
static status_t (*real_compare)(void *,void *);
static void (*register_region)(void *,void *);
static pthread_once_t support_once = PTHREAD_ONCE_INIT;
static bool installed;
static bool scope_enabled;

static bool detect_scope(void)
{
    const char *enable = getenv("ARC_PREVIEW_CODE_REGIONS");
    if (!enable || strcmp(enable,"1")) return false;
    char **argv = *_NSGetArgv();
    for (int i=1; i<*_NSGetArgc(); i++)
    {
        const char *name = argv[i];
        for (const char *p=name; *p; p++) if (*p=='/' || *p=='\\') name=p+1;
        if (!strcasecmp(name,"PioneerGame.exe") || !strcasecmp(name,"runtime_probe.exe")) return true;
    }
    return false;
}
static bool opted_in(void) { return scope_enabled; }
static void init_support(void)
{
    const char *path=getenv("CX_APPLEGPTK_LIBD3DSHARED_PATH");
    void *lib=path ? dlopen(path,RTLD_NOW|RTLD_LOCAL) : NULL;
    bool (*supports)(void)=lib ? dlsym(lib,"supports_non_native_code_regions") : NULL;
    if (supports && supports()) register_region=dlsym(lib,"register_non_native_code_region");
    if (!register_region) fprintf(stderr,"ARC Preview: native-region support unavailable\n");
}
static void mark(void *base,size_t size)
{
    if (!base || !size || size>UINTPTR_MAX-(uptr)base) return;
    pthread_once(&support_once,init_support);
    if (register_region) register_region(base,(char *)base+size);
}
static bool self(void *process)
{
    void *current=(void *)(intptr_t)-1;
    return process==current || (real_compare && real_compare(process,current)==0);
}
static status_t wrap_alloc(void *p,void **b,uptr z,size_t *s,u32 t,u32 prot)
{
    status_t r=real_alloc(p,b,z,s,t,prot);
    if (r>=0 && self(p) && (t&0x1000) && (prot&0xf0)) mark(*b,*s);
    return r;
}
static status_t wrap_alloc_ex(void *p,void **b,size_t *s,u32 t,u32 prot,void *x,u32 n)
{
    status_t r=real_alloc_ex(p,b,s,t,prot,x,n);
    if (r>=0 && self(p) && (t&0x1000) && (prot&0xf0)) mark(*b,*s);
    return r;
}
static status_t wrap_protect(void *p,void **b,size_t *s,u32 prot,u32 *old)
{
    status_t r=real_protect(p,b,s,prot,old);
    if (r>=0 && self(p) && (prot&0xf0)) mark(*b,*s);
    return r;
}
static void mark_mapping(void *base,size_t size,u32 prot)
{
    struct memory_info info;
    size_t len;
    /* SEC_IMAGE may be requested PAGE_READONLY, while executable section
       permissions come from its headers. Match the native PE loader convention. */
    if (real_query((void *)(intptr_t)-1,base,0,&info,sizeof(info),&len)>=0 &&
        (info.type==0x1000000 || ((prot&0xf0) && info.state==0x1000))) mark(base,size);
}
static status_t wrap_map(void *h,void *p,void **b,uptr z,size_t c,void *o,size_t *s,u32 i,u32 t,u32 prot)
{
    status_t r=real_map(h,p,b,z,c,o,s,i,t,prot);
    if (r>=0 && self(p)) mark_mapping(*b,*s,prot);
    return r;
}
static status_t wrap_map_ex(void *h,void *p,void **b,const void *o,size_t *s,u32 t,u32 prot,void *x,u32 n)
{
    status_t r=real_map_ex(h,p,b,o,s,t,prot,x,n);
    if (r>=0 && self(p)) mark_mapping(*b,*s,prot);
    return r;
}

#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <unistd.h>
#include "hook.h"
static void install(void *lib)
{
    if (installed || !opted_in()) return;
    struct service_table *table=dlsym(lib,"KeServiceDescriptorTable");
    if (!table || table->count!=265 || !table->functions || !table->args) return;
    const char *names[]={"NtAllocateVirtualMemory","NtAllocateVirtualMemoryEx","NtProtectVirtualMemory",
                         "NtMapViewOfSection","NtMapViewOfSectionEx"};
    void *wrappers[]={wrap_alloc,wrap_alloc_ex,wrap_protect,wrap_map,wrap_map_ex};
    const unsigned char argument_bytes[]={48,56,40,80,72};
    void **originals[]={(void **)&real_alloc,(void **)&real_alloc_ex,(void **)&real_protect,
                       (void **)&real_map,(void **)&real_map_ex};
    void **replacement=malloc(table->count*sizeof(void *));
    if (!replacement) return;
    memcpy(replacement,table->functions,table->count*sizeof(void *));
    size_t matched=0;
    for (size_t n=0;n<5;n++)
    {
        *originals[n]=dlsym(lib,names[n]);
        size_t found=0;
        for (size_t i=0;*originals[n] && i<table->count;i++)
            if (replacement[i]==*originals[n] && table->args[i]==argument_bytes[n])
            { replacement[i]=wrappers[n]; found++; }
        if (found==1) matched++;
    }
    real_query=dlsym(lib,"NtQueryVirtualMemory");
    real_compare=dlsym(lib,"NtCompareObjects");
    if (matched!=5 || !real_query || !real_compare) { free(replacement); return; }
    /* Replace the descriptor pointer; the original read-only service array and
       all unrelated services are preserved. Installed before Wine starts PE code. */
    __atomic_store_n(&table->functions,replacement,__ATOMIC_RELEASE);
    if (!arc_install_vm_search(lib)) { fprintf(stderr,"ARC_VM_SEARCH refused mismatched runtime\n"); _exit(122); }
    installed=true;
    fprintf(stderr,"ARC Preview: executable memory registration active (5 Wine services)\n");
}
static void *arc_dlopen(const char *path,int mode)
{
    void *result=dlopen(path,mode);
    if (result && path && strstr(path,"/ntdll.so")) install(result);
    return result;
}
__attribute__((used,section("__DATA,__interpose")))
static struct { const void *replacement,*original; } interpose_dlopen={arc_dlopen,dlopen};

/* Select the compatibility PE only for the initial NTDLL path construction in
 * opted-in processes. The original PE remains available to Wine helpers and
 * NotProton's bridge verification. This is a loader-path adjustment, not a
 * change to any Windows API's status or TLS allocation result. */
static int arc_asprintf(char **out,const char *format,...)
{
    va_list ap;
    va_start(ap,format);
    int result=vasprintf(out,format,ap);
    va_end(ap);
    if (result<0 || strcmp(format,"%s%s/ntdll.dll") || !opted_in()) return result;
    const char *replacement=getenv("ARC_PREVIEW_NTDLL_PATH");
    if (!replacement) return result;
    char expected[PATH_MAX], actual[PATH_MAX], source[PATH_MAX], target[PATH_MAX];
    if (strlen(replacement)>=sizeof(source)) return result;
    strcpy(source,replacement);
    char *slash=strrchr(source,'/');
    if (!slash || strcmp(slash+1,"ntdll-arc.dll")) return result;
    strcpy(slash+1,"ntdll.dll");
    if (!realpath(source,expected) || !realpath(*out,actual) || strcmp(expected,actual) ||
        !realpath(replacement,target)) return result;
    char *selected=strdup(target);
    if (!selected) return result;
    free(*out); *out=selected;
    fprintf(stderr,"ARC Preview: process-scoped TLS-compatible NTDLL selected\n");
    return (int)strlen(selected);
}
__attribute__((used,section("__DATA,__interpose")))
static struct { const void *replacement,*original; } interpose_asprintf={arc_asprintf,asprintf};

__attribute__((constructor)) static void initialize(void)
{
    /* Wine rewrites argv during initialization; capture scope before that. */
    scope_enabled=detect_scope();
    /* Handles a preloaded NTDLL as well as Wine's usual later dlopen. */
    if (!opted_in()) return;
    for (uint32_t i=0;i<_dyld_image_count();i++)
    {
        const char *name=_dyld_get_image_name(i);
        if (name && strstr(name,"/ntdll.so"))
        {
            void *lib=dlopen(name,RTLD_NOW|RTLD_NOLOAD);
            if (lib) install(lib);
        }
    }
}
