/* Private Wine entry: resolve the paired CPU loader relative to this file. */
#include <mach-o/dyld.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

int main(int argc, char **argv) {
    char own[PATH_MAX], resolved[PATH_MAX], loader[PATH_MAX], wine[PATH_MAX];
    uint32_t size = sizeof(own);
    if (_NSGetExecutablePath(own, &size) || !realpath(own, resolved)) {
        perror("ARC CPU loader: executable path"); return 2;
    }
    // CrossOver starts children through temporary hard links named for the PE.
    // Carry the original directory, but accept it only for the same shim inode.
    const char *inherited = getenv("ARC_NT_WINE_DIR");
    char candidate[PATH_MAX];
    struct stat actual, paired;
    int useInherited = 0;
    if (inherited) {
        int n = snprintf(candidate, sizeof(candidate), "%s/wine", inherited);
        useInherited = n > 0 && n < (int)sizeof(candidate) &&
            !stat(resolved, &actual) && !stat(candidate, &paired) &&
            actual.st_dev == paired.st_dev && actual.st_ino == paired.st_ino;
    }
    if (useInherited) {
        if (strlen(inherited) >= sizeof(resolved)) return 2;
        strcpy(resolved, inherited);
    } else {
        char *slash = strrchr(resolved, '/');
        if (!slash) return 2;
        *slash = 0;
    }
    if (setenv("ARC_NT_WINE_DIR", resolved, 1)) return 2;
    int a = snprintf(loader, sizeof(loader), "%s/../../arc-nt/runtime_loader", resolved);
    int b = snprintf(wine, sizeof(wine), "%s/wine-nt-original", resolved);
    if (a < 0 || a >= (int)sizeof(loader) || b < 0 || b >= (int)sizeof(wine)) return 2;
    if (access(loader, X_OK) || access(wine, X_OK)) {
        fprintf(stderr,"ARC CPU loader: paired runtime missing (self=%s loader=%s wine=%s)\n", own, loader, wine); return 2;
    }
    const char *dyld = getenv("DYLD_INSERT_LIBRARIES");
    if (dyld && *dyld && setenv("ARC_NT_LAB_TARGET_DYLD", dyld, 1)) return 2;
    if (unsetenv("DYLD_INSERT_LIBRARIES") || setenv("ARC_NT_CPU_FIX", "1", 1)) return 2;
    char **next = calloc((size_t)argc + 2, sizeof(*next));
    if (!next) return 2;
    next[0] = loader; next[1] = wine;
    for (int i = 1; i < argc; i++) next[i+1] = argv[i];
    execv(loader, next);
    perror("ARC CPU loader"); return 2;
}
