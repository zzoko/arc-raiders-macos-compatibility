#include "search.h"
#include <mach-o/loader.h>
#include <libkern/OSCacheControl.h>
static void *(*arc_original_fixed)(void *,size_t,int);
static unsigned long arc_search_reports;
static bool arc_vm_log_enabled;
static void *arc_host_try(void *p,size_t n,int prot,void *unused)
{ (void)unused; return arc_original_fixed(p,n,prot); }
static bool arc_host_region(uintptr_t a,uintptr_t *lo,uintptr_t *hi,void *unused)
{
    (void)unused;mach_vm_address_t addr=a;mach_vm_size_t size=0;
    vm_region_basic_info_data_64_t info;mach_msg_type_number_t count=VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t object=MACH_PORT_NULL;
    kern_return_t k=mach_vm_region(mach_task_self(),&addr,&size,VM_REGION_BASIC_INFO_64,(vm_region_info_t)&info,&count,&object);
    if(object)mach_port_deallocate(mach_task_self(),object);
    if(k!=KERN_SUCCESS || size>UINTPTR_MAX-addr)return false;
    *lo=addr;*hi=addr+size;return true;
}
static void *arc_host_search(void *base,void *end,ptrdiff_t step,void *start,size_t size,int prot)
{
    struct arc_search_stats stats={0};
    void *p=arc_search((uintptr_t)base,(uintptr_t)end,step,(uintptr_t)start,size,prot,arc_host_try,arc_host_region,NULL,&stats);
    int saved=errno;
    if(arc_vm_log_enabled && stats.skipped>=4096 && __atomic_fetch_add(&arc_search_reports,1,__ATOMIC_RELAXED)<32)
        fprintf(stderr,"ARC_VM_SEARCH pid=%d start=%p size=%zx step=%td result=%p attempts=%llu skipped=%llu\n",getpid(),start,size,step,p,stats.attempts,stats.skipped);
    errno=saved;return p;
}
static bool arc_vm_selftest(void *entry)
{
    void *(*search)(void *,void *,ptrdiff_t,void *,size_t,int)=entry;
    const size_t page=65536,span=1ULL<<30;mach_vm_address_t arena=0;
    if(mach_vm_allocate(mach_task_self(),&arena,span+2*page,VM_FLAGS_ANYWHERE))return false;
    bool ok=false;
    if(mach_vm_protect(mach_task_self(),arena,span+2*page,TRUE,VM_PROT_NONE))goto done;
    if(mach_vm_deallocate(mach_task_self(),arena,page))goto done;
    if(mach_vm_deallocate(mach_task_self(),arena+span+page,page))goto done;
    void *up=search((void *)arena,(void *)(arena+span+2*page),page,(void *)(arena+page),page,PROT_READ|PROT_WRITE);
    if(up!=(void *)(arena+span+page))goto done;
    *(volatile int *)up=123;
    void *down=search((void *)arena,(void *)(arena+span+2*page),-(ptrdiff_t)page,(void *)(arena+span),page,PROT_READ|PROT_WRITE);
    if(down!=(void *)arena)goto done;
    *(volatile int *)down=456;ok=true;
done:
    mach_vm_deallocate(mach_task_self(),arena,span+2*page);
    fprintf(stderr,"ARC_VM_SELFTEST %s\n",ok?"PASS":"FAIL");
    return ok;
}
static bool arc_install_vm_search(void *lib)
{
    arc_vm_log_enabled = getenv("ARC_VM_LOG") != NULL;
    Dl_info image;
    if(!dladdr(dlsym(lib,"NtCreatePagingFile"),&image))return false;
    unsigned char *base=image.dli_fbase;
    /* Exact audited Preview builds: Unix ntdll UUID, region-search entry and fixed-address helper. */
    static const struct { unsigned char uuid[16]; uintptr_t entry, fixed; const char *build; } builds[]={
        {{0x51,0xa9,0x8c,0x89,0x6a,0x27,0x35,0xfa,0x92,0x09,0xdf,0xf6,0xfb,0xe1,0x43,0x96},0x6c750,0x6c430,"27.0.0.40734"},
        {{0xad,0xc4,0x55,0x84,0x5e,0xf7,0x38,0x29,0xb5,0xb9,0x76,0xd2,0xd9,0xb8,0xe0,0xd4},0x6cfd0,0x6ccb0,"27.0.0.41073"},
    };
    struct mach_header_64 *header=(void *)base;int match=-1;
    if(header->magic!=MH_MAGIC_64 || header->cputype!=CPU_TYPE_X86_64)return false;
    struct load_command *cmd=(void *)(header+1);
    for(uint32_t i=0;i<header->ncmds;i++,cmd=(void *)((char *)cmd+cmd->cmdsize))
        if(cmd->cmd==LC_UUID)
            for(int b=0;b<(int)(sizeof(builds)/sizeof(builds[0]));b++)
                if(!memcmp(((struct uuid_command *)cmd)->uuid,builds[b].uuid,16))match=b;
    if(match<0)return false;
    const unsigned char expected_entry[]={0x55,0x48,0x89,0xe5,0x41,0x57,0x41,0x56,0x41,0x55,0x41,0x54,0x53,0x48,0x83,0xec,0x28};
    const unsigned char expected_fixed[]={0x55,0x48,0x89,0xe5,0x41,0x57,0x41,0x56,0x41,0x54,0x53,0x48,0x83,0xec,0x10};
    unsigned char *entry=base+builds[match].entry;
    if(memcmp(entry,expected_entry,sizeof(expected_entry)) ||
       memcmp(base+builds[match].fixed,expected_fixed,sizeof(expected_fixed)))return false;
    arc_original_fixed=(void *)(base+builds[match].fixed);
    unsigned char jump[12]={0x48,0xb8};uintptr_t target=(uintptr_t)arc_host_search;
    memcpy(jump+2,&target,8);jump[10]=0xff;jump[11]=0xe0;
    mach_vm_address_t page=(uintptr_t)entry & ~((uintptr_t)vm_page_size-1);
    if(mach_vm_protect(mach_task_self(),page,vm_page_size,FALSE,VM_PROT_READ|VM_PROT_WRITE|VM_PROT_COPY))return false;
    memcpy(entry,jump,sizeof(jump));sys_icache_invalidate(entry,sizeof(jump));
    if(mach_vm_protect(mach_task_self(),page,vm_page_size,FALSE,VM_PROT_READ|VM_PROT_EXECUTE))_exit(120);
    if(getenv("ARC_VM_SELFTEST") && !arc_vm_selftest(entry))_exit(121);
    fprintf(stderr,"ARC_VM_SEARCH installed Preview %s host-region search\n",builds[match].build);
    return true;
}
