# CrossOver Preview 27.0.0.40734 — NotProton Steam native

ARC Raiders compatibility installer **0.2.0-alpha7**.

## What you need

- An Apple Silicon Mac running **macOS 27.x**, with Rosetta installed.
- Your own **CrossOver Preview 27.0.0.40734 (July build)**, native macOS Steam and ARC Raiders license.
- This package supports that specific older Preview build, not a newer Preview.
- NotProton installed and set up with that CrossOver build's **Rosetta runner**.
  NotProton 1.1.7's launch interface is tested. The installer checks the actual
  runner and launch-script files; a different app version needs no change here
  if those files remain compatible. An incompatible input is rejected.

**You do not need a CrossOver Steam bottle or a Windows Steam installation.**
With NotProton set up, download ARC through native macOS Steam. An existing game
installation already recognized by native Steam can also be reused, including
one stored in a CrossOver bottle. You do not need to move or download it again.

The installer checks Rosetta components and CPU behavior automatically. There is
no exact macOS build-number requirement and no Xcode, Python or compiler to
install. If startup authorization is needed, it explains the system setting and
asks before showing macOS's administrator prompt.

## Install and play

1. Finish NotProton's normal setup for the CrossOver build above and download ARC
   in native Steam. You do not have to launch ARC successfully before patching it.
2. Quit native Steam and close ARC if it is running. Extract this entire ZIP;
   keep `Install.command` beside `Support`.
3. Open **Install.command** and choose **1 — Install / update**. It looks for the
   matching NotProton-prepared runtime and asks for its location only if needed.
   There is no bottle-selection step. Do not select the unprepared CrossOver app
   when asked for a NotProton runtime.
4. Restart native Steam. Open **ARC Raiders → Properties → Compatibility** and
   select **ARC Raiders - CrossOver Preview 27.0.0.40734 — NotProton Steam native**. Enable the option to force a compatibility
   tool if your Steam version shows it, then click **Play**.
5. Let initial shaders compile, then try the Practice Range. The first launch
   creates an isolated ARC prefix and may take longer. It does not copy the game.

Use NotProton's graphics controls in Steam: **D3DMetal**, with **MSync** and
**Advertise AVX2 to Rosetta** unchecked, is the tested configuration. **DLSS** and
**High Resolution** are optional. Keep the Launch Options those controls generate;
changes apply on the next launch. DLSS also needs a suitable in-game selection.

## Where the game and settings live

Steam supplies the installed game's location to the launcher. The Windows
environment is separate from the game download: this adapter uses
`~/Library/Application Support/ARC Raiders Compatibility/SteamData-Preview-27.0.0.40734/pfx`.
It creates that prefix automatically, without a CrossOver-managed bottle or a
full Windows Steam client. Existing settings in another prefix are not imported.

The private patched runtime also lives under `ARC Raiders Compatibility`.
Your CrossOver app, NotProton's source runner and game files are preserved. Game
and anti-cheat binaries are not patched. Do not rebuild a working prefix solely
to install this package.

## If something needs attention

- If macOS blocks the unsigned installer, use Finder's **Open** command and review
  the prompt. Compatibility-check failures write a report under
  `~/Library/Logs/ARC Raiders Compatibility`; the new launcher is not activated.
- If the runner is missing, finish setting up that build in NotProton first.
- The launcher defaults to English to avoid the observed missing-text startup
  screen. An explicit `-culture=` or `-language=` argument is respected; other
  languages have not been validated.
- Practice Range gameplay has been confirmed using the lean runtime and existing shared game files. This is an experimental release; a fresh native-Steam-only
  game download and a second Mac have not received end-to-end gameplay testing.

## Manage the installation

Open `Install.command` again: **2** verifies this package's installation, **3**
restores its previous launcher, and **4** removes its launcher while preserving
the game, prefix and runtime. Quit native Steam before changing its launcher.
To update, run the newer package's installer. Verification applies to an
installation made by this package, not a separate manually patched runtime.

## Files in this download

- **Install.command** — install, verify, restore or remove the launcher.
- **README.md** — this setup guide.
- **Support/** — patches, automatic checks, source, rebuild instructions and
  license notices. Keep this folder intact; nothing inside needs manual editing.
- **release.json** — version and compatibility metadata.
- **SHA256SUMS.txt** — checksums for the extracted files.
