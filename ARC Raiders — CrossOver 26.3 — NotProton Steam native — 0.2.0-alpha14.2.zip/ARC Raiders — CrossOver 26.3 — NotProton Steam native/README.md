# CrossOver 26.3 — NotProton Steam native

ARC Raiders compatibility installer **0.2.0-alpha14.2**.

## What you need

- An Apple Silicon Mac running **macOS 27.x**, with Rosetta installed.
  **macOS 27.2 or 27.2.1 is required to use the improved Wine performance optimization.**
- Your own **CrossOver 26.3 (build 26.3.0.39832)**, native macOS Steam and ARC Raiders license.

- NotProton installed and set up with that CrossOver build's **Rosetta runner**.
  **NotProton 1.2.6 is required** (other versions are rejected). The installer checks the actual runner,
  NotProton's Steam bridge and its launch script by exact hash; other NotProton
  versions are rejected. The launch script may come from any of NotProton's
  Rosetta tools; the CrossOver build is enforced by the runner checks.

**You do not need a CrossOver Steam bottle or a Windows Steam installation.**
With NotProton set up, download ARC through native macOS Steam. An existing game
installation already recognized by native Steam can also be reused, including
one stored in a CrossOver bottle. You do not need to move or download it again.

The installer checks Rosetta components and CPU behavior automatically. There is
no exact macOS build-number requirement and no Xcode, Python or compiler to
install. If startup authorization is needed, it explains the system setting and
asks before showing macOS's administrator prompt.

## Install and play

1. Finish NotProton's normal setup for the CrossOver build above and download ARC
   in native Steam. You do not have to launch ARC successfully before patching it.
2. Quit native Steam and close ARC if it is running. Extract this entire ZIP;
   keep `Install.command` beside `Support`.
3. Open **Install.command** and choose **1 — Install / update**. It looks for the
   matching NotProton-prepared runtime and asks for its location only if needed.
   There is no bottle-selection step. Do not select the unprepared CrossOver app
   when asked for a NotProton runtime.
4. Restart native Steam. Open **ARC Raiders → Properties → Compatibility** and
   select **ARC Raiders - CrossOver 26.3**. Enable the option to force a compatibility
   tool if your Steam version shows it, then click **Play**.
5. Let initial shaders compile, then try the Practice Range. The first launch
   creates an isolated ARC prefix and may take longer. It does not copy the game.

Use NotProton's graphics controls in Steam: Select **D3DMetal**, then choose **MSync**, **DLSS** and **High Resolution**. Leave **Advertise AVX2 to Rosetta** off.
Keep the Launch Options those controls generate; changes apply on the next launch.
DLSS also needs a suitable in-game selection.

## Where the game and settings live

Steam supplies the installed game's location to the launcher. The Windows
environment is separate from the game download: this adapter uses
`~/Library/Application Support/ARC Raiders Compatibility/SteamData-26.3/pfx`.
It creates that prefix automatically, without a CrossOver-managed bottle or a
full Windows Steam client. Existing settings in another prefix are not imported.

The private patched runtime also lives under `ARC Raiders Compatibility`.
Your CrossOver app, NotProton's source runner and game files are preserved. Game
and anti-cheat binaries are not patched. Do not rebuild a working prefix solely
to install this package.

## If something needs attention

- If macOS blocks the unsigned installer, use Finder's **Open** command and review
  the prompt. Compatibility-check failures write a report under
  `~/Library/Logs/ARC Raiders Compatibility`; the new launcher is not activated.
- If the runner is missing, finish setting up that build in NotProton first.
- The launcher defaults to English to avoid the observed missing-text startup
  screen. An explicit `-culture=` or `-language=` argument is respected.

## Manage the installation

Open `Install.command` again: **2** verifies this package's installation, **3**
restores its previous launcher, and **4** removes its launcher while preserving
the game, prefix and runtime, and **5** clears the D3DMetal shader cache if the game
freezes after long play (it rebuilds automatically). Quit native Steam before changing its launcher.
To update, run the newer package's installer. Verification applies to an
installation made by this package, not a separate manually patched runtime.

## Files in this download

- **Install.command** — install, verify, restore or remove the launcher.
- **README.md** — this setup guide.
- **Support/** — patches, automatic checks, source, rebuild instructions and
  license notices. Keep this folder intact; nothing inside needs manual editing.
- **release.json** — version and compatibility metadata.
- **SHA256SUMS.txt** — checksums for the extracted files.

If macOS blocks `hostcheck`, click **Done**, then open **System Settings → Privacy & Security → Open Anyway**, approve it and rerun the installer. Removing quarantine from the whole folder is not required.
