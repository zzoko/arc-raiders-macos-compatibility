#!/bin/zsh
# Optional adapter; derive launch scripts only from the user's owned NotProton shim.
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
umask 077
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
readonly tool_id=notproton-arc-cx263-compat build_id=26.3.0.39832
readonly source_hash=057df0aa1a9c493a3dd13a1972d32193009d4af0b48fa4f5004be7f9983d0dab  # NotProton 1.2.6 generic Rosetta run script
readonly source_version='NotProton 1.2.6'
readonly display_name='ARC Raiders - CrossOver 26.3'
readonly marker_text='ARC Raiders Compatibility NotProton adapter v2'
readonly state_marker='ARC Raiders Compatibility NotProton state v1'
typeset -a tool_files=(arc-run run-base run compatibilitytool.vdf toolmanifest.vdf build arc-flavor)
default_tools="$HOME/Library/Application Support/Steam/compatibilitytools.d"
runtime='' source_tool='' tool_root=$default_tools mode=install
registry="$HOME/Library/Application Support/notproton/tools"
data="$HOME/Library/Application Support/ARC Raiders Compatibility/SteamData-26.3"
state_dir="$HOME/Library/Application Support/ARC Raiders Compatibility/NotProtonAdapter-26.3-entry2"
integer dry=0 production=0 row_count=0
stage='' registry_temp='' lock_dir='' current_row=''
integer old_moved=0 new_moved=0 registry_moved=0 previous_moved=0 previous_published=0 committed=0
fail() { print -u2 -r -- "Error: $*"; exit 1; }
usage() {
  print -r -- "Usage: notproton.zsh [--runtime PATH | --rollback | --remove | --verify]
  [--source-tool PATH] [--tool-root PATH] [--registry PATH] [--data PATH]
  [--state-dir PATH] [--dry-run]
Default mode installs/updates from a core-verified NotProton-compatible runtime.
--rollback swaps current and previous owned tool/registry state, including undoing removal.
--remove unregisters and archives only this owned tool; runtime and game prefix remain.
--verify checks the active owned tool and registry without writing or requiring Steam to close.
--tool-root is the compatibilitytools.d parent. Backups are outside it in --state-dir.
--dry-run validates the plan without installation writes. Exit 0 means success.
No game or Steam is launched. Native Steam must be closed for production writes."
}
while (( $# )); do
  case $1 in
    --runtime|--source-tool|--tool-root|--registry|--data|--state-dir)
      (( $# >= 2 )) && [[ -n $2 && $2 != --* ]] || fail "Missing value for $1."
      case $1 in
        --runtime) runtime=$2 ;; --source-tool) source_tool=$2 ;; --tool-root) tool_root=$2 ;;
        --registry) registry=$2 ;; --data) data=$2 ;; --state-dir) state_dir=$2 ;;
      esac; shift 2 ;;
    --rollback|--remove|--verify) [[ $mode == install ]] || fail 'Choose one mode.'; mode=${1#--}; shift ;;
    --dry-run) dry=1; shift ;; --help|-h) usage; exit 0 ;;
    *) fail "Unknown argument: $1" ;;
  esac
done
[[ $mode != install || -n $runtime ]] || { usage; exit 1; }
sha() { /usr/bin/shasum -a 256 -- "$1" | /usr/bin/awk '{print $1}'; }
no_links() { local p=$1; while [[ $p != / ]]; do [[ ! -L $p ]] || fail "Symbolic-link path refused: $p"; p=${p:h}; done; }
for value in "$runtime" "$source_tool" "$tool_root" "$registry" "$data" "$state_dir"; do
  [[ $value != *$'\n'* && $value != *$'\r'* && $value != *$'\t'* ]] || fail 'Paths cannot contain tabs or newlines.'
done
tool_root=${tool_root:a}; registry=${registry:a}; data=${data:a}; state_dir=${state_dir:a}
target="$tool_root/$tool_id"; previous="$state_dir/previous"
[[ $tool_root != / && $data != / && $state_dir != / && $state_dir != ${HOME:a} ]] || fail 'Unsafe target path.'
[[ $state_dir != $tool_root && $state_dir != $tool_root/* && $tool_root != $state_dir/* ]] || fail 'State and tool directories must be separate trees.'
for value in "$tool_root" "$registry" "$data" "$state_dir"; do no_links "$value"; done
row="$tool_id"$'\t'"$build_id"$'\t'"rosetta"$'\t'"$display_name"
state_identity="$state_marker"$'\n'"tool=$target"$'\n'"registry=$registry"
files_record() { local f; for f in $tool_files; do print -r -- "$(sha "$1/$f")"$'\t'"$f"; done; }
verify_tool() {
  local p=$1 f
  no_links "$p"
  [[ -d $p && -f $p/.arc-adapter-owner && -f $p/.arc-adapter-files ]] || fail "Unowned tool: $p"
  [[ $(<"$p/.arc-adapter-owner") == $marker_text ]] || fail "Tool ownership mismatch: $p"
  [[ $(/bin/ls -A "$p") == $(print -rl -- .arc-adapter-files .arc-adapter-owner $tool_files | /usr/bin/sort) ]] || fail "Unexpected tool content: $p"
  for f in $tool_files .arc-adapter-owner .arc-adapter-files; do no_links "$p/$f"; [[ -f $p/$f ]] || fail "Missing tool file: $f"; done
  [[ $(<"$p/.arc-adapter-files") == $(files_record "$p") ]] || fail "Owned tool was modified: $p"
  for f in arc-run run-base run; do [[ -x $p/$f ]] || fail "Tool executable permission changed: $f"; done
}
verify_snapshot() {
  local p=$1 f
  no_links "$p"
  for f in present registry-row; do no_links "$p/$f"; [[ -f $p/$f ]] || fail "Invalid previous-state snapshot: $p"; done
  [[ $(<"$p/registry-row") == '' || $(<"$p/registry-row") == $row ]] || fail 'Previous registry row does not belong to this adapter.'
  case $(<"$p/present") in
    1) [[ $(/bin/ls -A "$p") == $'present\nregistry-row\ntool' ]] || fail 'Unexpected snapshot content.'; verify_tool "$p/tool" ;;
    0) [[ $(/bin/ls -A "$p") == $'present\nregistry-row' && $(<"$p/registry-row") == '' ]] || fail 'Invalid absent-state snapshot.' ;;
    *) fail 'Invalid previous-state presence marker.' ;;
  esac
}
if [[ -e $state_dir ]]; then
  [[ -d $state_dir && -f $state_dir/.arc-adapter-state && ! -L $state_dir/.arc-adapter-state ]] || fail 'State directory is not owned by this adapter.'
  [[ $(<"$state_dir/.arc-adapter-state") == $state_identity ]] || fail 'State directory belongs to different target paths.'
  for entry in "$state_dir"/*(DN); do
    case ${entry:t} in .arc-adapter-state|previous) ;; *) fail "Unexpected/interrupted state retained for recovery: $entry" ;; esac
  done
  [[ ! -e $previous ]] || verify_snapshot "$previous"
fi
[[ ! -e $target ]] || verify_tool "$target"
[[ ! -e $registry || -f $registry ]] || fail 'Registry must be a regular file.'
registry_before=absent; [[ ! -f $registry ]] || registry_before=$(sha "$registry")
if [[ -f $registry ]]; then
  while IFS= read -r line || [[ -n $line ]]; do
    [[ ${line%%$'\t'*} == $tool_id ]] || continue
    (( ++row_count )); [[ $line == $row && -d $target ]] || fail 'Registry tool ID is not owned by this configuration.'
    current_row=$line
  done < "$registry"
fi
(( row_count <= 1 )) || fail 'Duplicate tool IDs in registry.'
if [[ $mode == verify ]]; then
  [[ -d $target && -z $current_row ]] || fail 'Owned disk-discovered tool is required; it must not be managed by NotProton regeneration.'
  print -r -- "Verified owned Steam adapter: $target"; exit 0
fi
for value in "$target" "$registry"; do
  case $value in "$HOME/Library/Application Support/Steam"/*|"$HOME/Library/Application Support/notproton"/*) production=1 ;; esac
done
steam_stopped() {
  (( ! production )) || { ! /usr/bin/pgrep -x steam_osx >/dev/null && ! /usr/bin/pgrep -x Steam >/dev/null; } \
    || fail 'Quit native Steam before changing its compatibility tools; no process was stopped.'
}
if [[ $mode == install ]]; then
  runtime=${runtime:a}; no_links "$runtime"
  if [[ -z $source_tool ]]; then
    typeset -a matches=() seen=()
    for candidate in "$default_tools"/*(N/); do
      [[ ${candidate:t} != $tool_id && -f $candidate/build && -f $candidate/flavor && -f $candidate/run ]] || continue
      # Ignore this project's derived tools when finding the original NotProton tool.
      [[ ${candidate:t} != *arc* && ${candidate:t} != *finals* ]] || continue
      [[ $(<"$candidate/flavor") == rosetta ]] || continue
      candidate_hash=$(sha "$candidate/run")
      seen+=("${candidate:t} (run ${candidate_hash[1,16]})")
      if [[ $candidate_hash == $source_hash ]]; then matches+=("$candidate"); fi
    done
    if (( ${#matches} == 0 )); then
      print -u2 -r -- "Error: This package requires $source_version. No Steam compatibility tool generated by it was found in:"
      print -u2 -r -- "  $default_tools"
      if (( ${#seen} )); then
        print -u2 -r -- 'Rosetta NotProton tools found, but their run script is from a different NotProton version:'
        print -u2 -rl -- "  "${^seen}
      else
        print -u2 -r -- 'No original Rosetta NotProton tool was found.'
      fi
      fail "Update NotProton to ${source_version#NotProton }, open it so it regenerates its Steam tools, then retry. Nothing was changed."
    fi
    source_tool=$matches[1]
  fi
  source_tool=${source_tool:a}; no_links "$source_tool"
  for file in build flavor run; do no_links "$source_tool/$file"; [[ -f $source_tool/$file ]] || fail "Missing source $file."; done
  [[ $(<"$source_tool/flavor") == rosetta ]] || fail 'A Rosetta NotProton source tool is required.'
  [[ $(sha "$source_tool/run") == $source_hash ]] || fail "Unsupported NotProton run script; this package requires $source_version. Nothing was changed."
  np_bridge="$HOME/Library/Application Support/notproton/bridge"
  for file in steamclient64.dll steamclient.dll tier0_s64.dll vstdlib_s64.dll lsteamclient.dll steam.exe x86_64-unix/lsteamclient.so; do
    [[ -f $np_bridge/$file ]] || fail "NotProton's Steam bridge is incomplete (missing $file). Open $source_version and finish its setup, then retry. Nothing was changed."
  done
  for file in bin/wineserver lib/wine/x86_64-unix/wine lib/wine/x86_64-unix/ntdll.so lib/wine/x86_64-windows/ntdll.dll; do
    [[ -f $runtime/$file ]] || fail "Verified runtime is incomplete: $file"
  done
  [[ -x $runtime/bin/wineserver && -x $runtime/lib/wine/x86_64-unix/wine ]] || fail 'Runtime executables are not executable.'
elif [[ $mode == rollback ]]; then
  [[ -d $previous ]] || fail 'No previous adapter state to restore.'
fi
quote_sh() { REPLY=${(qq)1}; }
quote_sh "$runtime"; runtime_quoted=$REPLY
quote_sh "$data"; data_quoted=$REPLY
readonly launcher_patch="${0:A:h:h}/patches/notproton-run.bsdiff"
generate_base() {
  local temp template_text
  [[ $(sha "$launcher_patch") == 7d98dbc6a3c467cfafea4fde51af12b7283eeda859eea2ce2f94cccee077dcb4 ]] || fail 'Launcher patch checksum mismatch.'
  temp=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/arc-render.XXXXXXXX") || return 1
  {
    /usr/bin/bspatch "$source_tool/run" "$temp/run-base" "$launcher_patch" || return 1
    [[ $(sha "$temp/run-base") == 300987c307f671b5985f121d510a09bbde3d7ee652f3ec490fcaf30d6dbd8e9d ]] || fail 'Reconstructed launcher checksum mismatch.'
    template_text=$(<"$temp/run-base")
    [[ $template_text == *__ARC_RUNTIME_SHELL__* ]] || fail 'Missing runtime path marker.'
    print -r -- "${template_text/__ARC_RUNTIME_SHELL__/$runtime_quoted}"
  } always {
    /bin/rm -rf -- "$temp"
  }
}
generate_wrapper() {
  print -r -- '#!/bin/zsh
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL
arc_id=${STEAM_COMPAT_APP_ID:-${SteamAppId:-}}
[[ $arc_id == 1808500 ]] || { print -u2 -- "This compatibility tool is only for ARC Raiders (1808500)."; exit 1; }'
  print -r -- 'for arc_other_id in "${SteamAppId:-}" "${SteamGameId:-}"; do
  [[ -z $arc_other_id || $arc_other_id == 0 || $arc_other_id == 1808500 ]] || {
    print -u2 -- "Conflicting Steam application ID; refusing this launch."; exit 1
  }
done'
  print -r -- "export STEAM_COMPAT_DATA_PATH=$data_quoted"
  print -r -- 'case ${1:-} in
  getcompatpath) print -r -- "$STEAM_COMPAT_DATA_PATH"; exit 0 ;;
esac
[[ -n ${STEAM_COMPAT_INSTALL_PATH:-} && -d $STEAM_COMPAT_INSTALL_PATH ]] || {
  print -u2 -- "Steam did not provide an existing game installation path."; exit 1
}
mkdir -p -- "$STEAM_COMPAT_DATA_PATH"
case ${1:-} in
  run|waitforexitandrun)
arc_prefix="$STEAM_COMPAT_DATA_PATH/pfx"
# Shader-cache recovery: the Apple GPU driver can hang a game whose D3DMetal shader cache grew too
# large ("AGX: exceeded compiled variants footprint limit"). After a hang crash, clear that cache once.
arc_cache_dir="$(/usr/bin/getconf DARWIN_USER_CACHE_DIR)d3dm/PioneerGame.exe"
arc_stamp="$HOME/Library/Application Support/ARC Raiders Compatibility/shader-cache-checked"
if [[ -f $arc_stamp ]]; then
  for arc_crash in "$arc_prefix"/drive_c/users/*/AppData/Local/PioneerGame/Saved/Crashes/*/CrashContext.runtime-xml(N.); do
    [[ $arc_crash -nt $arc_stamp ]] || continue
    if /usr/bin/grep -q "Hang detected" "$arc_crash" 2>/dev/null; then
      [[ ! -d $arc_cache_dir ]] || /bin/rm -rf -- "$arc_cache_dir"
      print -u2 -- "ARC Raiders: the last session ended in a hang; the D3DMetal shader cache was cleared once. Expect some stutter while it rebuilds."
      break
    fi
  done
fi
/usr/bin/touch -- "$arc_stamp" 2>/dev/null || true
;;
esac
export ARC_NATIVE_CODE_REGIONS=1 WINEDEBUG=-all
# Optional graphics settings come from the NotProton controls.
export ARC_NT_USE_AOT=1
# English avoids the missing-localization first-run screen in a new prefix.
case ${1:-} in
  run|waitforexitandrun)
    arc_has_language=0
    for arc_arg in "$@"; do
      case ${arc_arg:l} in -culture=*|-language=*) arc_has_language=1 ;; esac
    done
    if (( ! arc_has_language )); then set -- "$@" -culture=en; fi ;;
esac
exec "${0:A:h}/run-base" "$@"'
}
if [[ $mode == install ]]; then generate_base | /bin/sh -n; generate_wrapper | /bin/zsh -n; fi
if (( dry )); then
  print -r -- "Validated $mode plan. Runtime compatibility is verified separately by the core installer.
Tool: $target
Registry: $registry
Rollback state: $previous
Dry run: no files installed or registration changed."
  exit 0
fi
[[ $mode != remove || -d $target ]] || { print -r -- 'Already removed; rollback state preserved.'; exit 0; }
steam_stopped
undo_transaction() {
  if (( previous_published )); then /bin/mv -- "$previous" "$stage/prior" || return 1; fi
  if (( new_moved )); then /bin/mv -- "$target" "$stage/failed-new" || return 1; fi
  if (( old_moved )); then /bin/mv -- "$stage/prior/tool" "$target" || return 1; fi
  if (( registry_moved )); then
    [[ $(sha "$registry") == $registry_after ]] || return 1
    if [[ $registry_before == absent ]]; then /bin/rm -f -- "$registry" || return 1
    else /bin/mv -f -- "$stage/registry-original" "$registry" || return 1; fi
  fi
  if (( previous_moved )); then /bin/mv -- "$stage/old-previous" "$previous" || return 1; fi
  return 0
}
cleanup() {
  local exit_code=$?
  if (( ! committed && (old_moved || new_moved || registry_moved || previous_moved) )); then
    if ! undo_transaction; then
      print -u2 -r -- "Recovery data retained after interrupted transaction: $stage"
      stage=''; exit_code=1
    fi
  fi
  [[ -z $stage || ! -d $stage ]] || /bin/rm -rf -- "$stage"
  [[ -z $registry_temp || ! -f $registry_temp ]] || /bin/rm -f -- "$registry_temp"
  [[ -z $lock_dir || ! -d $lock_dir ]] || /bin/rmdir -- "$lock_dir" 2>/dev/null || true
  return $exit_code
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
/bin/mkdir -p -- "$tool_root" "${registry:h}" "$state_dir"
[[ $(/usr/bin/stat -f '%d' "$tool_root") == $(/usr/bin/stat -f '%d' "$state_dir") ]] || fail 'Tool and rollback state must be on the same filesystem for atomic renames.'
if [[ ! -f $state_dir/.arc-adapter-state ]]; then print -r -- "$state_identity" > "$state_dir/.arc-adapter-state"; fi
lock_dir="$tool_root/.$tool_id.lock"
/bin/mkdir -- "$lock_dir" 2>/dev/null || { lock_dir=''; fail 'Another adapter operation is active.'; }
stage=$(/usr/bin/mktemp -d "$state_dir/.transaction.XXXXXXXX")
/bin/mkdir -- "$stage/prior"
print -r -- "$current_row" > "$stage/prior/registry-row"
if [[ -d $target ]]; then print -r -- 1 > "$stage/prior/present"; else print -r -- 0 > "$stage/prior/present"; fi
[[ ! -f $registry ]] || /bin/cp -p -- "$registry" "$stage/registry-original"
desired_row=''
if [[ $mode == install ]]; then
  /bin/mkdir -- "$stage/next"
  generate_base > "$stage/next/run-base"; generate_wrapper > "$stage/next/arc-run"
  # /run and a notproton-prefixed directory are the NotProton shell-hook interface.
  # Own this entry ourselves: no source-managed registry row or flavor file.
  print -r -- '#!/bin/zsh
# ARC Raiders compatibility entry point; managed by the ARC installer.
exec "${0:A:h}/arc-run" "$@"' > "$stage/next/run"
  [[ $(sha "$source_tool/run") == $source_hash ]] || fail 'Source shim changed during staging.'
  print -r -- "$build_id" > "$stage/next/build"; print -r -- rosetta > "$stage/next/arc-flavor"
  print -r -- "$marker_text" > "$stage/next/.arc-adapter-owner"
  print -r -- '"manifest" { "version" "2" "commandline" "/run %verb%" }' > "$stage/next/toolmanifest.vdf"
  print -r -- "\"compatibilitytools\" { \"compat_tools\" { \"$tool_id\" {
  \"install_path\" \".\" \"display_name\" \"$display_name\"
  \"from_oslist\" \"windows\" \"to_oslist\" \"macos\"
} } }" > "$stage/next/compatibilitytool.vdf"
  /bin/chmod +x "$stage/next/run" "$stage/next/run-base" "$stage/next/arc-run"
  files_record "$stage/next" > "$stage/next/.arc-adapter-files"
  desired_row=''  # Steam discovers the VDF; NotProton must not regenerate our run.
elif [[ $mode == rollback ]]; then
  [[ $(<"$previous/present") != 1 ]] || /bin/cp -pR -- "$previous/tool" "$stage/next"
  desired_row=$(<"$previous/registry-row")
fi
[[ ! -d $stage/next ]] || verify_tool "$stage/next"
if [[ -d $target && -d $stage/next && $current_row == $desired_row ]]; then
  if /usr/bin/diff -qr -- "$target" "$stage/next" >/dev/null; then
    print -r -- 'Already installed and identical; previous rollback state preserved.'; exit 0
  fi
elif [[ ! -e $target && ! -d $stage/next && $current_row == $desired_row ]]; then
  print -r -- 'State already matches; previous rollback state preserved.'; exit 0
fi
registry_temp=$(/usr/bin/mktemp "${registry:h}/.arc-registry.XXXXXXXX")
if [[ -f $registry ]]; then
  /bin/cp -p -- "$registry" "$registry_temp"
  /usr/bin/awk -F '\t' -v id="$tool_id" '$1 != id' "$registry" > "$registry_temp"
fi
[[ -z $desired_row ]] || print -r -- "$desired_row" >> "$registry_temp"
registry_after=$(sha "$registry_temp")
steam_stopped
registry_now=absent; [[ ! -f $registry ]] || registry_now=$(sha "$registry")
[[ $registry_now == $registry_before ]] || fail 'Registry changed during staging; nothing committed.'
[[ ! -e $target ]] || verify_tool "$target"
commit_changes() {
  if [[ -d $previous ]]; then /bin/mv -- "$previous" "$stage/old-previous" || return 1; previous_moved=1; fi
  if [[ -d $target ]]; then /bin/mv -- "$target" "$stage/prior/tool" || return 1; old_moved=1; fi
  if [[ -d $stage/next ]]; then
    [[ ! -e $target && ! -L $target ]] || return 1
    /bin/mv -- "$stage/next" "$target" || return 1; new_moved=1
  fi
  /bin/mv -f -- "$registry_temp" "$registry" || return 1; registry_temp=''; registry_moved=1
  /bin/mv -- "$stage/prior" "$previous" || return 1; previous_published=1
  committed=1
}
commit_changes || fail 'Adapter transaction failed; restoring the previous state.'
print -r -- "Adapter $mode completed. Previous owned state saved at: $previous
Restart native Steam. Select the installed or restored tool in Compatibility. If the tool was removed, select your previous tool.
Other registry entries, runtimes and game prefixes were preserved. No game was launched."
