/* Stable native identity: no MSync state or other runtime is modified. */
#include "stable_native_signatures.h"
static bool pf_cxcompat_matches(void *,void *,void **);
static const unsigned char pf_sync_uuid[16]={0x35,0x16,0x08,0x58,0x51,0x22,0x35,0x75,0x95,0x0c,0x33,0x48,0xa3,0x60,0xcf,0x05};
static bool pf_sync_identity(uint64_t base)
{
    struct mach_header_64 h;
    if(!pf_user_pointer(base)||pf_read(&h,base,sizeof(h),NULL)!=sizeof(h)||h.magic!=MH_MAGIC_64||
       h.cputype!=CPU_TYPE_X86_64||!h.ncmds||h.ncmds>128||h.sizeofcmds<sizeof(struct load_command)*h.ncmds||h.sizeofcmds>65536)return false;
    uint64_t off=sizeof(h),end=off+h.sizeofcmds;bool found=false;
    for(unsigned i=0;i<h.ncmds;i++){
        struct load_command c;if(off+sizeof(c)>end||pf_read(&c,base+off,sizeof(c),NULL)!=sizeof(c)||c.cmdsize<sizeof(c)||off+c.cmdsize>end)return false;
        if(c.cmd==LC_UUID){unsigned char uuid[16];if(c.cmdsize!=24||pf_read(uuid,base+off+8,16,NULL)!=16||memcmp(uuid,pf_sync_uuid,16))return false;found=true;}off+=c.cmdsize;
    }
    static const uint64_t offsets[4]={0x4942b,0x1c102,0x4bc20,0x58df0};
    static const size_t sizes[4]={sizeof(pf_native_cache),sizeof(pf_native_shm),sizeof(pf_native_wait),sizeof(pf_native_teb)};
    const unsigned char *signatures[4]={pf_native_cache,pf_native_shm,pf_native_wait,pf_native_teb};
    unsigned char code[64];if(!found)return false;
    for(unsigned i=0;i<4;i++)if(pf_read(code,base+offsets[i],sizes[i],NULL)!=sizes[i]||memcmp(code,signatures[i],sizes[i]))return false;
    return true;
}
/* Validate the stable table without modifying it. Defer file wrapping until
 * cxcompatdb's constructor has installed the normal CodeWeavers hooks. */
static void pf_prepare(void *lib,void **replacement,struct service_table *table)
{
    int saved=errno;const char *flag=getenv("ARC_ASYNC_COMPLETION_FENCE");
    if(!flag||strcmp(flag,"1")){errno=saved;return;}
    static const char *names[8]={"NtCreateFile","NtOpenFile","NtClose","NtQueryPerformanceCounter","NtWaitForSingleObject","NtSetEvent","NtResetEvent","NtCreateUserProcess"};
    static const unsigned char args[8]={88,48,8,16,24,16,16,88};
    static const size_t exact_indices[8]={85,51,15,49,4,14,215,137};
    if(table->count!=259||!table->args||!replacement){errno=saved;return;}
    bool valid=true;
    for(unsigned k=0;k<8;k++){
        void *fn=dlsym(lib,names[k]);unsigned any=0,matched=0;size_t found=0;
        /* Stable calls NtWait directly; it has its own low-byte normalization. */
        for(size_t i=0;i<table->count;i++)if(fn&&replacement[i]==fn){any++;if(table->args[i]==args[k]){matched++;found=i;}}
        if(any!=1||matched!=1||found!=exact_indices[k]||(k==PF_QPC&&found!=0x31)||(k==PF_WAIT&&found!=4)||
           (k==PF_SET&&found!=14)||(k==PF_RESET&&found!=215))valid=false;
        pf_original[k]=fn;pf_indices[k]=found;
    }
    pf_current_teb=dlsym(lib,"NtCurrentTeb");
    if(!valid||!pf_current_teb){fprintf(stderr,"ARC_ASYNC_FENCE refused service identity\n");errno=saved;return;}
    pf_table=table;pf_prepared=true;errno=saved;
}
static void pf_after_cxcompatdb(void)
{
    int saved=errno;if(!pf_prepared||pf_active){errno=saved;return;}pf_prepared=false;
    void **current=__atomic_load_n(&pf_table->functions,__ATOMIC_ACQUIRE);void *base=NULL;
    static const unsigned char args[8]={88,48,8,16,24,16,16,88};bool valid=pf_table->count==259;
    for(unsigned k=0;k<8;k++)if(pf_indices[k]>=pf_table->count||pf_table->args[pf_indices[k]]!=args[k]||
       (k!=PF_CREATE&&k!=PF_PROCESS&&current[pf_indices[k]]!=pf_original[k]))valid=false;
    if(!valid||!pf_cxcompat_matches(current[pf_indices[PF_CREATE]],current[pf_indices[PF_PROCESS]],&base)){
        fprintf(stderr,"ARC_ASYNC_FENCE refused completed cxcompatdb chain\n");errno=saved;return;}
    void **replacement=malloc(pf_table->count*sizeof(void *));if(!replacement){errno=saved;return;}
    memcpy(replacement,current,pf_table->count*sizeof(void *));uint64_t now=pf_now();
    if(!now){free(replacement);errno=saved;return;}
    pf_real_create=current[pf_indices[PF_CREATE]];pf_real_open=pf_original[PF_OPEN];pf_real_close=pf_original[PF_CLOSE];
    pf_real_qpc=pf_original[PF_QPC];pf_real_wait=pf_original[PF_WAIT];pf_real_setevent=pf_original[PF_SET];pf_real_resetevent=pf_original[PF_RESET];
    void *wrappers[7]={pf_create,pf_open,pf_close,pf_qpc,pf_wait,pf_setevent,pf_resetevent};
    for(unsigned k=0;k<7;k++)replacement[pf_indices[k]]=wrappers[k];
    pf_start=now;pf_enabled=true;
    __atomic_store_n(&pf_table->functions,replacement,__ATOMIC_RELEASE);pf_active=true;
    fprintf(stderr,"ARC_ASYNC_FENCE ready: 7 services, exact provider, bound100ms\n");errno=saved;
}
static bool pf_cxcompat_matches(void *create,void *process,void **base_out)
{
    static const unsigned char expected_uuid[16]={0x8b,0x61,0xfa,0xf7,0xeb,0xe4,0x3b,0x2f,0x99,0x54,0xf9,0x1d,0x8a,0xd0,0xf7,0x94};
    Dl_info info;
    if(!create || !process || !dladdr(create,&info) || !info.dli_fname) return false;
    const char *name=strrchr(info.dli_fname,'/'); name=name?name+1:info.dli_fname;
    uint64_t base=(uint64_t)info.dli_fbase;
    if(strcmp(name,"cxcompatdb.so") || (uint64_t)create!=base+0x55b0 || (uint64_t)process!=base+0x5e40) return false;
    struct mach_header_64 h;
    if(pf_read(&h,base,sizeof(h),NULL)!=sizeof(h) || h.magic!=MH_MAGIC_64 || h.cputype!=CPU_TYPE_X86_64 ||
       !h.ncmds || h.ncmds>128 || h.sizeofcmds<sizeof(struct load_command)*h.ncmds || h.sizeofcmds>65536) return false;
    uint64_t cursor=base+sizeof(h),end=cursor+h.sizeofcmds; bool uuid=false;
    for(uint32_t i=0;i<h.ncmds;i++) {
        struct load_command c;
        if(cursor>end || end-cursor<sizeof(c) || pf_read(&c,cursor,sizeof(c),NULL)!=sizeof(c) || c.cmdsize<sizeof(c) || c.cmdsize>end-cursor) return false;
        if(c.cmd==LC_UUID) {
            struct uuid_command u;
            if(c.cmdsize!=sizeof(u) || pf_read(&u,cursor,sizeof(u),NULL)!=sizeof(u) || memcmp(u.uuid,expected_uuid,16)) return false;
            uuid=true;
        }
        cursor+=c.cmdsize;
    }
    unsigned char code[32];
    if(!uuid || pf_read(code,(uint64_t)create,32,NULL)!=32 || memcmp(code,pf_cx_create,32) ||
       pf_read(code,(uint64_t)process,32,NULL)!=32 || memcmp(code,pf_cx_process,32)) return false;
    *base_out=info.dli_fbase; return true;
}
