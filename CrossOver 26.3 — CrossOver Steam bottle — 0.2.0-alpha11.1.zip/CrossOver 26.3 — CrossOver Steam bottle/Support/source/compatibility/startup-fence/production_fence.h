/* Private production extraction for audited stable 26.3 / ARC build 26159202.
 * The real Windows calls/results are preserved; the proven completion waiter
 * only awaits the producer's actual IOSB publication, bounded to 100 ms.
 * No recorders, monitors, game writes or anti-cheat changes are included. */
#ifndef ARC_PRODUCTION_FENCE_H
#define ARC_PRODUCTION_FENCE_H
#include <errno.h>
#include <stddef.h>
#include <time.h>
#include <sched.h>
#include <mach-o/loader.h>
#include "native_guards.h"
#define PF_DURATION_NS UINT64_C(120000000000)
#define PF_OPEN_LIMIT 16u
#define PF_QPC_ARM_NS UINT64_C(10000000000)
#define PF_QPC_PREFILTER_LIMIT 128u
#define PF_QPC_VALIDATION_LIMIT 4u
struct pf_unicode {uint16_t length,maximum;uint32_t pad;uint64_t buffer;};
struct pf_object_attributes {uint32_t length,pad1;uint64_t root,name;uint32_t attributes,pad2;uint64_t security,qos;};
_Static_assert(sizeof(struct pf_unicode)==16,"UNICODE_STRING64");
_Static_assert(sizeof(struct pf_object_attributes)==48,"OBJECT_ATTRIBUTES64");
struct pf_open_record {uint64_t exit_ns,windows_pid,windows_tid;unsigned index,kind;};
struct pf_wait_identity {
    uint64_t handle,receiver,overlapped,kernelbase,ntdll,thunk,target,slot,caller;
    unsigned flags,kind;
};
struct pf_clock_identity {uint64_t ntdll,kernel32,thunk,target;unsigned flags;};
static struct ac_domain pf_domain;
static struct pf_open_record pf_records[PF_OPEN_LIMIT],*pf_wait_opened[2];
static uint64_t pf_handles[PF_OPEN_LIMIT],pf_start;
static unsigned pf_next,pf_done,pf_qpc_validations,pf_wait_prefilters,pf_wait_validations,pf_wait_counts[2];
static __thread struct pf_open_record *pf_qpc_opened;
static __thread unsigned pf_qpc_prefilters,pf_recursing;
static bool pf_enabled,pf_prepared,pf_active;
static struct service_table *pf_table;
static size_t pf_indices[8];
static void *pf_original[8];
static void *(*pf_current_teb)(void);
static status_t (*pf_real_create)(void **,u32,void *,void *,void *,u32,u32,u32,u32,void *,u32);
static status_t (*pf_real_open)(void **,u32,void *,void *,u32,u32);
static status_t (*pf_real_close)(void *);
static status_t (*pf_real_qpc)(void *,void *);
static status_t (*pf_real_wait)(void *,unsigned char,const void *);
static status_t (*pf_real_setevent)(void *,void *),(*pf_real_resetevent)(void *,void *);
enum {PF_CREATE,PF_OPEN,PF_CLOSE,PF_QPC,PF_WAIT,PF_SET,PF_RESET,PF_PROCESS};
static uint64_t pf_now(void)
{struct timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t))return 0;return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
static size_t pf_read(void *dst,uint64_t address,size_t bytes,uint32_t *error)
{
    size_t done=0;if(!address||bytes>UINT64_MAX-address){if(error)*error=KERN_INVALID_ADDRESS;return 0;}
    while(done<bytes){size_t part=4096u-((address+done)&4095u);if(part>bytes-done)part=bytes-done;
        mach_vm_size_t got=0;kern_return_t k=mach_vm_read_overwrite(mach_task_self(),address+done,part,(mach_vm_address_t)((char *)dst+done),&got);
        if(k!=KERN_SUCCESS||got!=part){if(error)*error=(uint32_t)(k?k:KERN_FAILURE);break;}done+=part;
    }return done;
}
static uint64_t pf_u64(const void *p){uint64_t v;memcpy(&v,p,8);return v;}
static uint32_t pf_u32(const void *p){uint32_t v;memcpy(&v,p,4);return v;}
static bool pf_user_pointer(uint64_t p){return p>=0x10000&&p<UINT64_C(0x7fffffffffff);}
/* Match the same four basenames as the validated lean helper. PAK kinds are
 * bits 1/2; UTOC opens consume a bounded identity slot but do not arm a fence. */
static unsigned pf_name(const uint16_t *s,size_t length)
{
    size_t first=0;for(size_t i=0;i<length;i++)if(s[i]=='/'||s[i]=='\\')first=i+1;
    static const char *names[]={"pakchunk9_s2-windowsclient.pak","pakchunk9_s1-windowsclient.pak","pakchunk9_s2-windowsclient.utoc","pakchunk9_s1-windowsclient.utoc"};
    for(unsigned n=0;n<4;n++){
        if(strlen(names[n])!=length-first)continue;size_t i=0;
        for(;i<length-first;i++){unsigned c=s[first+i];if(c>='A'&&c<='Z')c+='a'-'A';if(c!=(unsigned char)names[n][i])break;}
        if(i==length-first)return n+1;
    }return 0;
}
static bool pf_in_window(uint64_t now)
{return now&&now>=pf_start&&now-pf_start<=PF_DURATION_NS;}
static void pf_retire_handle(uint64_t handle)
{
    for(unsigned i=0;i<AC_CAPACITY;i++){struct ac_operation *o=&pf_domain.operations[i];
        if(atomic_load_explicit(&o->state,memory_order_acquire)==AC_ACTIVE&&o->identity.handle==handle)
            atomic_store_explicit(&o->state,AC_RETIRED,memory_order_release);
    }
}
static void pf_retire_kind(unsigned kind)
{
    uint64_t size=kind==1?315971:365;
    for(unsigned i=0;i<AC_CAPACITY;i++){struct ac_operation *o=&pf_domain.operations[i];
        if(atomic_load_explicit(&o->state,memory_order_acquire)==AC_ACTIVE&&o->identity.file_size==size)
            atomic_store_explicit(&o->state,AC_RETIRED,memory_order_release);
    }
}
static struct pf_open_record *pf_begin_open(void *object)
{
    if(__atomic_load_n(&pf_next,__ATOMIC_RELAXED)>=PF_OPEN_LIMIT||!pf_in_window(pf_now()))return NULL;
    struct pf_object_attributes oa;struct pf_unicode name;uint16_t tail[128];
    if(pf_read(&oa,(uint64_t)object,sizeof(oa),NULL)!=sizeof(oa)||oa.length!=sizeof(oa)||
       pf_read(&name,oa.name,sizeof(name),NULL)!=sizeof(name)||!name.buffer||!name.length||(name.length&1)||name.length>name.maximum)return NULL;
    size_t length=name.length<sizeof(tail)?name.length:sizeof(tail);unsigned matched=0;
    if(pf_read(tail,name.buffer+name.length-length,length,NULL)!=length||!(matched=pf_name(tail,length/2)))return NULL;
    unsigned index=__atomic_fetch_add(&pf_next,1,__ATOMIC_RELAXED);if(index>=PF_OPEN_LIMIT)return NULL;
    struct pf_open_record *r=&pf_records[index];r->index=index;
    /* Preserve the original complete-path guard without storing that path. */
    uint16_t path[1024];size_t wanted=name.length<sizeof(path)-2?name.length:sizeof(path)-2;
    size_t got=pf_read(path,name.buffer,wanted,NULL);
    if(got==wanted&&wanted==name.length&&matched<=2&&pf_name(path,got/2)==matched)r->kind=matched;
    unsigned char identity[104];uint64_t teb=(uint64_t)pf_current_teb();
    if(pf_read(identity,teb,sizeof(identity),NULL)==sizeof(identity)&&pf_u64(identity+0x30)==teb){r->windows_pid=pf_u64(identity+0x40);r->windows_tid=pf_u64(identity+0x48);}
    return r;
}
static void pf_finish_open(struct pf_open_record *r,status_t actual,void **output)
{
    if(!r)return;r->exit_ns=pf_now();uint64_t handle=0;
    if(actual<0||(uint32_t)actual==AC_PENDING||pf_read(&handle,(uint64_t)output,8,NULL)!=8||!handle||handle==UINT64_MAX)return;
    for(unsigned i=0;i<PF_OPEN_LIMIT;i++)if(__atomic_load_n(&pf_handles[i],__ATOMIC_ACQUIRE)==handle){uint64_t expected=handle;
        (void)__atomic_compare_exchange_n(&pf_handles[i],&expected,0,false,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE);}
    __atomic_store_n(&pf_handles[r->index],handle,__ATOMIC_RELEASE);
    if(r->kind){pf_qpc_opened=r;pf_qpc_prefilters=0;__atomic_store_n(&pf_wait_opened[r->kind-1],r,__ATOMIC_RELEASE);}
}
static status_t pf_create(void **h,u32 access,void *o,void *io,void *allocation,u32 attributes,u32 share,u32 disposition,u32 options,void *ea,u32 length)
{
    if(pf_recursing)return pf_real_create(h,access,o,io,allocation,attributes,share,disposition,options,ea,length);
    int incoming=errno;pf_recursing=1;struct pf_open_record *r=pf_begin_open(o);errno=incoming;
    status_t actual=pf_real_create(h,access,o,io,allocation,attributes,share,disposition,options,ea,length);int outgoing=errno;
    pf_finish_open(r,actual,h);pf_recursing=0;errno=outgoing;return actual;
}
static status_t pf_open(void **h,u32 access,void *o,void *io,u32 share,u32 options)
{
    if(pf_recursing)return pf_real_open(h,access,o,io,share,options);
    int incoming=errno;pf_recursing=1;struct pf_open_record *r=pf_begin_open(o);errno=incoming;
    status_t actual=pf_real_open(h,access,o,io,share,options);int outgoing=errno;
    pf_finish_open(r,actual,h);pf_recursing=0;errno=outgoing;return actual;
}
static status_t pf_close(void *handle)
{
    int incoming=errno;pf_retire_handle((uint64_t)handle);
    for(unsigned i=PF_OPEN_LIMIT;i>0;i--)if(__atomic_load_n(&pf_handles[i-1],__ATOMIC_ACQUIRE)==(uint64_t)handle){uint64_t expected=(uint64_t)handle;
        if(__atomic_compare_exchange_n(&pf_handles[i-1],&expected,0,false,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE))break;}
    if(pf_recursing){errno=incoming;return pf_real_close(handle);}
    pf_recursing=1;errno=incoming;status_t actual=pf_real_close(handle);int outgoing=errno;
    pf_recursing=0;errno=outgoing;return actual;
}
#include "pak_checkpoint.h"
#include "wait_boundary.h"
#include "provider_completion.h"
#include "service_chain.h"
#endif
