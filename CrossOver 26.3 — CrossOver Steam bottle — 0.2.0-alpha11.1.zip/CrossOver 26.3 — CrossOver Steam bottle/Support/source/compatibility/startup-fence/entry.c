/* Private stable 26.3 completion fence only. Existing stable NTDLL retains
 * its maintained memory, TLS and CPU compatibility implementation. */
#include <dlfcn.h>
#include <crt_externs.h>
#include <mach-o/dyld.h>
#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
typedef int32_t status_t;
typedef uint32_t u32;
typedef uintptr_t uptr;
struct service_table {void **functions;void *counters;uptr count;unsigned char *args;};
#include "production_fence.h"
static bool scope_enabled,installed;

static const char *basename_any(const char *path)
{
    if(!path)return "";
    const char *name=path;
    for(const char *p=path;*p;p++)if(*p=='/'||*p=='\\')name=p+1;
    return name;
}
static bool detect_scope(void)
{
    const char *flag=getenv("ARC_ASYNC_COMPLETION_FENCE");
    if(!flag||strcmp(flag,"1"))return false;
    char **argv=*_NSGetArgv();
    for(int i=1;i<*_NSGetArgc();i++){
        const char *name=basename_any(argv[i]);
        if(!strcasecmp(name,"PioneerGame.exe")||!strcasecmp(name,"runtime_probe.exe"))return true;
    }
    return false;
}
static void install(void *lib)
{
    if(installed||!scope_enabled)return;
    void *wait=dlsym(lib,"NtWaitForSingleObject");Dl_info info;
    if(!wait||!dladdr(wait,&info)||strcmp(basename_any(info.dli_fname),"ntdll.so"))return;
    uint64_t base=(uint64_t)info.dli_fbase;
    struct service_table *table=dlsym(lib,"KeServiceDescriptorTable");
    /* All reads precede activation. No Preview ABI normalizer or memory-service
     * overlay is accepted as a substitute for this exact stable runtime. */
    if((uint64_t)wait!=base+0x4bc20||!pf_sync_identity(base)||
       (uint64_t)table!=base+0x83320)return;
    struct service_table snapshot;
    if(pf_read(&snapshot,(uint64_t)table,sizeof(snapshot),NULL)!=sizeof(snapshot)||
       snapshot.count!=259||(uint64_t)snapshot.functions!=base+0x812a0||
       (uint64_t)snapshot.args!=base+0x83210)return;
    pf_prepare(lib,snapshot.functions,table);
    installed=pf_prepared;
}
static void *arc_dlopen(const char *path,int mode)
{
    /* dyld resolves @rpath and @loader_path using dlopen's actual caller.
     * A normal call through this image changes that identity. Unobserved calls
     * must restore our frame and jump directly to dlopen, with no post-call work.
     * musttail makes a future accidental call/return a compilation error. */
    if(!scope_enabled||!path||path[0]!='/')
        __attribute__((musttail)) return dlopen(path,mode);
    static const char ntdll_suffix[]="/lib/wine/x86_64-unix/ntdll.so";
    static const char cx_suffix[]="/lib/wine/x86_64-unix/cxcompatdb.so";
    size_t length=strlen(path);unsigned kind=0;
    if(length>=sizeof(ntdll_suffix)-1&&!strcmp(path+length-(sizeof(ntdll_suffix)-1),ntdll_suffix))kind=1;
    else if(length>=sizeof(cx_suffix)-1&&!strcmp(path+length-(sizeof(cx_suffix)-1),cx_suffix))kind=2;
    if(!kind)__attribute__((musttail)) return dlopen(path,mode);
    void *result=dlopen(path,mode);int saved=errno;
    if(result){
        if(kind==1)install(result);
        else pf_after_cxcompatdb();
    }
    errno=saved;return result;
}
__attribute__((used,section("__DATA,__interpose")))
static struct {const void *replacement,*original;} interpose_dlopen={arc_dlopen,dlopen};
__attribute__((constructor)) static void initialize(void)
{
    int saved=errno;scope_enabled=detect_scope();
    if(scope_enabled)for(uint32_t i=0;i<_dyld_image_count();i++){
        const char *name=_dyld_get_image_name(i);
        if(!strcmp(basename_any(name),"ntdll.so")){
            void *lib=dlopen(name,RTLD_NOW|RTLD_NOLOAD);
            if(lib){install(lib);dlclose(lib);}
        }
    }
    errno=saved;
}
