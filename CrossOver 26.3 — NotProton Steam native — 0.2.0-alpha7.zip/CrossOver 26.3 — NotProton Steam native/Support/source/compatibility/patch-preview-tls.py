"""Create an ARC-only PE sibling, guarded to the exact audited Preview build."""
from pathlib import Path
import hashlib, json, sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 patch-preview-tls.py /absolute/private/CrossOver')
root = Path(sys.argv[1]).expanduser().resolve()
source = root / 'lib/wine/x86_64-windows/ntdll.dll'
target = source.with_name('ntdll-arc.dll')
original = source.read_bytes()
assert hashlib.sha256(original).hexdigest() in {
    '6c57653f9b42668fffe90c8cc36ed0434825fc43880b40cb8b80b9df3a2c45a9',  # NotProton bridge retained
    '6b8dab5e4f32d95b33ac7b7ba1920de05ba2fbaa7111264afa4505cf0f04adb2',  # Vendor Steam-bottle input
}
assert original[0x6269a:0x6269c] == bytes.fromhex('756c')
assert hashlib.sha256(original[0x6269a:0x62708]).hexdigest() == '2eab99d1cfa4a2ac7e9f22e5a52abb4ce029590e946ec4194f5e6366476e4f93'
patched = bytearray(original)
patched[0x6269a] = 0xeb  # Unconditional skip of CW18756; mirrors the 26.3 source deletion.
target.write_bytes(patched)
assert source.read_bytes() == original
record = {'source': str(source), 'target': str(target), 'offset': '0x6269a',
          'before': '756c', 'after': 'eb6c',
          'original_sha256': hashlib.sha256(original).hexdigest(),
          'patched_sha256': hashlib.sha256(patched).hexdigest(),
          'scope': 'Companion selects this sibling only for opted-in ARC/probe processes'}
print(json.dumps(record, indent=2))
