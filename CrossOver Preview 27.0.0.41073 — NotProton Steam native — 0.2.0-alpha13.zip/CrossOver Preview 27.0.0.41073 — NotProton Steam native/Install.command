#!/bin/zsh
emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL EXTENDED_GLOB
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
umask 077
base=${0:A:h}; support="$base/Support"
profile=notproton; build=27.0.0.41073; short=Preview-27.0.0.41073
root="$HOME/Library/Application Support/ARC Raiders Compatibility"
version=$(<"$support/version.txt")
dest="$root/$short-$version-$profile"
source "$support/lib/installer-ui.zsh"
preview=0 list_only=0
case ${1:-} in
  '') ;;
  --preview) preview=1 ;;
  --help|-h)
    print -r -- 'Install.command [--preview]'
    print -r -- '  --preview       Select locations and review the plan without installing'
    exit 0 ;;
  *) fail "Unknown argument: $1" ;;
esac
(( $# <= 1 )) || fail 'Choose one command-line option.'
finish() {
  local code=$?
  if [[ -t 0 && -t 1 && $preview == 0 && $list_only == 0 ]]; then
    print -nr -- $'\n  Press Enter to close… '
    IFS= read -r _ || true
  fi
  return $code
}
trap finish EXIT

prepare_launch() {
   source_runtime="$HOME/Library/Application Support/notproton/runners/crossover-$build/CrossOver"
   while [[ ! -d $source_runtime ]]; do
    read_path "NotProton-prepared CrossOver $build runtime" || return 1
    source_runtime=$REPLY
    [[ -d $source_runtime ]] || notice 'Runtime folder not found.'
   done
   args+=(--source-runtime "$source_runtime")
}
show_plan() {
  section 'Installation plan'
  print -rl -- '  ARC Raiders · CrossOver Preview 27.0.0.41073 — NotProton Steam native' "  Runtime: $dest"
  print -rl -- "  Source: $source_runtime" '  Launcher: native Steam compatibility tool'
}
install_flow() {
  local -a args=()
  while true; do
    args=(--profile "$profile" --destination "$dest")
    prepare_launch || return 0
    show_plan
    if (( preview )); then
      print -r -- '  Preview complete. Nothing was installed or changed.'
      return 0
    fi
    ask 'Start installation? [y/N] (B to change selection)'
    case ${REPLY:l} in
      y|yes) break ;;
      b) continue ;;
      *) print -r -- '  Installation canceled.'; return 0 ;;
    esac
  done
  if /usr/bin/pgrep -x steam_osx >/dev/null || /usr/bin/pgrep -x Steam >/dev/null; then
    fail 'Quit native Steam before installing this launch integration.'
  fi
  /bin/zsh "$support/install.zsh" --check "${args[@]}"
  if [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) != *enabled* ]]; then
   print -r -- 'The private runtime needs macOS Developer Tools authorization for its startup setup.
This is a system authorization setting; it does not require installing Xcode.
macOS will ask for an administrator password. No game is being launched.'
   read -r 'allow?Enable this authorization now? [y/N]: '
   [[ ${allow:l} == y || ${allow:l} == yes ]] || fail 'Setup cancelled; authorization was not changed.'
   /usr/bin/osascript -e 'do shell script "/usr/sbin/DevToolsSecurity -enable" with administrator privileges' || fail 'Administrator authorization was cancelled or failed.'
   [[ $(/usr/sbin/DevToolsSecurity -status 2>&1) == *enabled* ]] || fail 'macOS has not enabled the required authorization.'
  fi
  /bin/zsh "$support/install.zsh" --install "${args[@]}"
  /bin/zsh "$support/install.zsh" --verify --destination "$dest"
   /bin/zsh "$support/lib/notproton.zsh" --runtime "$dest/CrossOver"
   print -r -- 'Restart native Steam. For ARC, select the tool matching this download under Properties → Compatibility. Use D3DMetal; choose DLSS, High Resolution and MSync in NotProton. Keep Advertise AVX2 off.'
}

print -rl -- "${accent}ARC Raiders / Compatibility installer${reset}" \
  'CrossOver Preview 27.0.0.41073 — NotProton Steam native' "  $version · Apple Silicon · macOS 27 · automatic compatibility check"
if (( preview )); then install_flow; exit 0; fi
section 'Actions'
print -rl -- '  [1] Install / update' '  [2] Verify installed runtime and launcher' \
  '  [3] Restore previous launcher' '  [4] Remove launcher (preserve game and runtime)' \
  '  [5] Clear D3DMetal shader cache' '  [0] Exit'
while true; do
  ask 'Select an action:'
  case $REPLY in
    0) exit 0 ;;
    1) install_flow; exit 0 ;;
    2)
      /bin/zsh "$support/install.zsh" --verify --destination "$dest"
      /bin/zsh "$support/lib/$profile.zsh" --verify
      exit 0 ;;
    3|4)
      if [[ $REPLY == 3 ]]; then mode=--rollback; else mode=--remove; fi
      ask 'Confirm launcher action? [y/N]'
      if confirmed "$REPLY"; then /bin/zsh "$support/lib/$profile.zsh" "$mode"; fi
      exit 0 ;;
    5)
      cache_dir="$(/usr/bin/getconf DARWIN_USER_CACHE_DIR)d3dm/PioneerGame.exe"
      if /usr/bin/pgrep -if 'PioneerGame.exe' >/dev/null; then fail 'Quit ARC Raiders before clearing the cache.'; fi
      if [[ -d $cache_dir ]]; then
        ask 'Clear the shader cache? [y/N]'
        if confirmed "$REPLY"; then
          /bin/rm -rf -- "$cache_dir"
          print -r -- '  Shader cache cleared. It will rebuild on the next launch.'
        fi
      else print -r -- '  No shader cache found.'; fi
      exit 0 ;;
    *) notice 'Enter an action number from the menu.' ;;
  esac
done
