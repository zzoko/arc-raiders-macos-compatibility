# Shared console helpers. Based on the installer contribution by @alex-paradeyev.
# Sourced by Install.command; no installation or discovery occurs here.
accent='' dim='' good='' warn='' reset=''
if [[ -t 1 && ${TERM:-dumb} != dumb && -z ${NO_COLOR:-} ]]; then
  accent=$'\e[1;36m' dim=$'\e[2m' good=$'\e[32m' warn=$'\e[33m' reset=$'\e[0m'
fi
section() { print -rl -- '' "${accent}── $1 ──${reset}"; }
notice() { print -r -- "  ${warn}• $1${reset}"; }
fail() { print -u2 -r -- "  ${warn}Error: $*${reset}"; exit 1; }
ask() {
  if [[ -t 0 && -t 1 ]]; then print -nr -- "  ${accent}$1${reset} "
  else print -r -- "  $1"; fi
  IFS= read -r REPLY || REPLY=0
}
confirmed() { case ${1:l} in y|yes) return 0 ;; *) return 1 ;; esac; }
parse_location() {
  local input=$1
  # Finder supplies shell quoting. Decode quotes without evaluating shell code.
  if [[ ! -e $input ]]; then
    input=${input%%[[:blank:]]#}
    input=${(Q)input}
  fi
  [[ $input != '~/'* ]] || input="$HOME/${input#\~/}"
  [[ $input == /* && $input != *[[:cntrl:]]* ]] || return 1
  REPLY=${input:a}
}
read_path() {
  while true; do
    ask "$1 (0 to go back):"
    [[ $REPLY != 0 ]] || return 1
    parse_location "$REPLY" && return 0
    notice 'Enter a full path or drag the item from Finder.'
  done
}
valid_number() { [[ $1 == <1-9999> && $1 != 0* ]] && (( $1 <= $2 )); }
