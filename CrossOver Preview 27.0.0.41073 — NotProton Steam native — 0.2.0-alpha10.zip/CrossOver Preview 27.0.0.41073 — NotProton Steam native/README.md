# CrossOver Preview 27.0.0.41073 — NotProton Steam native

ARC Raiders compatibility installer **0.2.0-alpha10**.

## What you need

- An Apple Silicon Mac running **macOS 27.x**, with Rosetta installed.
- Your own **CrossOver Preview 20261015 (build 27.0.0.41073)**: `crossover-preview-20261015.zip`
  from CodeWeavers' Preview Center (not the `arm64` download), native macOS Steam and ARC Raiders license.
- This package supports exactly that Preview build; other Preview builds are rejected.
- NotProton installed and set up with that CrossOver build's **Rosetta runner**.
  **NotProton 1.2.1 is required** (other versions are rejected). The installer checks the actual runner,
  NotProton's Steam bridge and its launch script by exact hash; other NotProton
  versions are rejected. The launch script may come from any of NotProton's
  Rosetta tools; the CrossOver build is enforced by the runner checks.
  alpha9's launcher is NotProton 1.2.1's script with the same ARC edits as
  before.

**You do not need a CrossOver Steam bottle or a Windows Steam installation.**
With NotProton set up, download ARC through native macOS Steam. An existing game
installation already recognized by native Steam can also be reused, including
one stored in a CrossOver bottle. You do not need to move or download it again.

The installer checks Rosetta components and CPU behavior automatically. There is
no exact macOS build-number requirement and no Xcode, Python or compiler to
install. If startup authorization is needed, it explains the system setting and
asks before showing macOS's administrator prompt.

## Install and play

1. Finish NotProton's normal setup for the CrossOver build above and download ARC
   in native Steam. You do not have to launch ARC successfully before patching it.
2. Quit native Steam and close ARC if it is running. Extract this entire ZIP;
   keep `Install.command` beside `Support`.
3. Open **Install.command** and choose **1 — Install / update**. It looks for the
   matching NotProton-prepared runtime and asks for its location only if needed.
   There is no bottle-selection step. Do not select the unprepared CrossOver app
   when asked for a NotProton runtime.
4. Restart native Steam. Open **ARC Raiders → Properties → Compatibility** and
   select **ARC Raiders - CrossOver Preview 27.0.0.41073**. Enable the option to force a compatibility
   tool if your Steam version shows it, then click **Play**.
5. Let initial shaders compile, then try the Practice Range. The first launch
   creates an isolated ARC prefix and may take longer. It does not copy the game.

Use NotProton's graphics controls in Steam: **D3DMetal**, with **MSync** and
**Advertise AVX2 to Rosetta** unchecked, is the tested configuration. **DLSS** and
**High Resolution** are optional. Keep the Launch Options those controls generate;
changes apply on the next launch. DLSS also needs a suitable in-game selection.

## Where the game and settings live

Steam supplies the installed game's location to the launcher. The Windows
environment is separate from the game download: this adapter uses
`~/Library/Application Support/ARC Raiders Compatibility/SteamData-Preview-27.0.0.41073/pfx`.
It creates that prefix automatically, without a CrossOver-managed bottle or a
full Windows Steam client. Existing settings in another prefix are not imported.

The private patched runtime also lives under `ARC Raiders Compatibility`.
Your CrossOver app, NotProton's source runner and game files are preserved. Game
and anti-cheat binaries are not patched. Do not rebuild a working prefix solely
to install this package.

## If something needs attention

- If macOS blocks the unsigned installer, use Finder's **Open** command and review
  the prompt. Compatibility-check failures write a report under
  `~/Library/Logs/ARC Raiders Compatibility`; the new launcher is not activated.
- If the runner is missing, finish setting up that build in NotProton first.
- The launcher defaults to English to avoid the observed missing-text startup
  screen. An explicit `-culture=` or `-language=` argument is respected; other
  languages have not been validated.
- Ray tracing is no longer forced off. Choose Dynamic GI in the game; availability
  depends on D3DMetal and your Mac. An explicit `D3DM_SUPPORT_DXR=0` in Launch Options
  still disables it.
- If startup reports an RTPSO/pipeline error, quit the game and try **5 — Clear
  D3DMetal shader cache** in `Install.command`, then relaunch. Shaders rebuild.
  Cache refresh was part of the successful M5 test; the earlier crash cause is unconfirmed.
- Preview testing reached the Practice Range with the highest Dynamic GI setting.
  This does not establish every graphics setting, map or Apple Silicon chip.

## Manage the installation

Open `Install.command` again: **2** verifies this package's installation, **3**
restores its previous launcher, and **4** removes its launcher while preserving
the game, prefix and runtime, and **5** clears the D3DMetal shader cache if the game
freezes after long play (it rebuilds automatically). Quit native Steam before changing its launcher.
To update, run the newer package's installer. Verification applies to an
installation made by this package, not a separate manually patched runtime.

## Files in this download

- **Install.command** — install, verify, restore or remove the launcher.
- **README.md** — this setup guide.
- **Support/** — patches, automatic checks, source, rebuild instructions and
  license notices. Keep this folder intact; nothing inside needs manual editing.
- **release.json** — version and compatibility metadata.
- **SHA256SUMS.txt** — checksums for the extracted files.
