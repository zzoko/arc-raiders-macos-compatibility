/* Private diagnostic prototype: not installed or enabled by this header.
 * Call-site validators belong to the native integration, not this lifecycle core.
 * No function below writes target memory, changes a Windows result, or signals an event.
 */
#ifndef ARC_ASYNC_COMPLETION_FENCE_H
#define ARC_ASYNC_COMPLETION_FENCE_H
#include <stdbool.h>
#include <stdint.h>
#include <stdatomic.h>
#include <errno.h>

#define AC_CAPACITY 64u
#define AC_PENDING UINT32_C(0x103)
#define AC_RESET_PROOF UINT32_C(0x41525231)
#define AC_WAIT_PROOF UINT32_C(0x41525731)
#define AC_PRODUCER_PROOF UINT32_C(0x41525031)

struct ac_identity {
    uint64_t handle, receiver, iosb, context, offset, requested, file_size;
    uint32_t guard;
};
struct ac_ticket { uint32_t slot; uint64_t generation; };
static const struct ac_ticket ac_no_ticket = { AC_CAPACITY, 0 };

enum ac_state { AC_UNUSED, AC_BUILDING, AC_ACTIVE, AC_RETIRED };
enum ac_outcome {
    AC_BYPASS, AC_ALREADY_PUBLISHED, AC_PUBLICATION_OBSERVED,
    AC_NO_PRODUCER, AC_IDENTITY_CHANGED, AC_GENERATION_CHANGED,
    AC_UNREADABLE, AC_TIMEOUT, AC_CLOCK_FAILURE
};
struct ac_report {
    enum ac_outcome outcome;
    struct ac_ticket ticket;
    uint32_t actual_status, observed_status, loads, yields;
    uint64_t elapsed_ns;
};
struct ac_operation {
    _Atomic uint32_t state;
    struct ac_identity identity; /* Immutable once state is ACTIVE. */
    uint64_t generation;
    _Atomic uint64_t producer_generation;
    _Atomic uint32_t waiter_claimed;
};
struct ac_domain {
    _Atomic uint32_t next_slot, registration_lock, ambiguous_registration;
    struct ac_operation operations[AC_CAPACITY]; /* Never recycled in this prototype. */
};
struct ac_callbacks {
    void *opaque;
    bool (*acquire_status)(void *, uint64_t iosb, uint32_t *);
    bool (*identity_still_matches)(void *, const struct ac_identity *);
    uint64_t (*now_ns)(void *);
    void (*yield)(void *);
    void (*report)(void *, const struct ac_report *);
    uint64_t maximum_ns;
    uint32_t spin_loads;
};

static bool ac_scope(const struct ac_identity *a)
{
    if (!a || !a->handle || a->receiver < 0x10000 || a->receiver > UINT64_MAX-0x68 ||
        a->iosb != a->receiver+0x58 || (a->iosb & 3)) return false;
    if (!((a->file_size == 315971 && (a->offset == 0 || a->offset == 262144)) ||
          (a->file_size == 365 && a->offset == 0))) return false;
    return a->requested > 0 && a->requested <= 65536;
}
static bool ac_same_receiver(const struct ac_identity *a, const struct ac_identity *b)
{
    return a->handle == b->handle && a->receiver == b->receiver && a->iosb == b->iosb;
}
static bool ac_same_request(const struct ac_identity *a, const struct ac_identity *b)
{
    return ac_same_receiver(a,b) && a->offset == b->offset &&
           a->requested == b->requested && a->file_size == b->file_size;
}
static struct ac_operation *ac_lookup(struct ac_domain *d, struct ac_ticket t)
{
    if (!d || t.slot >= AC_CAPACITY || !t.generation ||
        atomic_load_explicit(&d->ambiguous_registration,memory_order_acquire)) return 0;
    struct ac_operation *o = &d->operations[t.slot];
    if (atomic_load_explicit(&o->state, memory_order_acquire) != AC_ACTIVE ||
        o->generation != t.generation) return 0;
    return o;
}
static void ac_retire_receiver(struct ac_domain *d, const struct ac_identity *a)
{
    for (unsigned i=0;i<AC_CAPACITY;i++) {
        struct ac_operation *o=&d->operations[i];
        if (atomic_load_explicit(&o->state,memory_order_acquire)==AC_ACTIVE &&
            ac_same_receiver(&o->identity,a))
            atomic_store_explicit(&o->state,AC_RETIRED,memory_order_release);
    }
}

/* AFTER the actual, exact-provider ResetEvent returned SUCCESS, before guest
 * submission resumes. A reset from any other native path must not call this.
 * Reset failures and an exhausted diagnostic slot budget retain ordinary behavior.
 */
static struct ac_ticket ac_register_operation(struct ac_domain *d,
                                              const struct ac_identity *a,
                                              uint32_t actual_reset_status)
{
    int saved_errno=errno;
    struct ac_ticket t=ac_no_ticket; bool owns_lock=false;
    if (!d || actual_reset_status || !ac_scope(a) || a->guard!=AC_RESET_PROOF ||
        !a->context || atomic_load_explicit(&d->ambiguous_registration,memory_order_acquire)) goto done;
    uint32_t unlocked=0;
    if (!atomic_compare_exchange_strong_explicit(&d->registration_lock,&unlocked,1,
            memory_order_acquire,memory_order_relaxed)) {
        /* Never guess which concurrent submission owns one IOSB. Conservatively
         * disable this private domain, without blocking either real reset. */
        atomic_store_explicit(&d->ambiguous_registration,1,memory_order_release);
        goto done;
    }
    owns_lock=true;
    /* A new request is an explicit epoch boundary, including allocator reuse. */
    ac_retire_receiver(d,a);
    if (atomic_load_explicit(&d->next_slot,memory_order_relaxed)>=AC_CAPACITY) goto done;
    uint32_t i=atomic_fetch_add_explicit(&d->next_slot,1,memory_order_relaxed);
    if (i>=AC_CAPACITY) goto done;
    struct ac_operation *o=&d->operations[i];
    atomic_store_explicit(&o->state,AC_BUILDING,memory_order_relaxed);
    o->identity=*a; o->generation=(uint64_t)i+1;
    atomic_store_explicit(&o->producer_generation,0,memory_order_relaxed);
    atomic_store_explicit(&o->waiter_claimed,0,memory_order_relaxed);
    atomic_store_explicit(&o->state,AC_ACTIVE,memory_order_release);
    t=(struct ac_ticket){i,o->generation};
done:
    if (owns_lock) atomic_store_explicit(&d->registration_lock,0,memory_order_release);
    errno=saved_errno; return t;
}

/* Before the real exact-provider NtSetEvent. This never waits. The provider
 * proof must join its live context+38 to IOSB and context+70/+78 to this request.
 * It may arrive before or during NtWait: registration was at request reset.
 */
static bool ac_bind_producer(struct ac_domain *d, const struct ac_identity *a)
{
    int saved_errno=errno; bool bound=false;
    if (!d || !ac_scope(a) || a->guard!=AC_PRODUCER_PROOF || !a->context ||
        atomic_load_explicit(&d->ambiguous_registration,memory_order_acquire)) goto done;
    for (unsigned i=0;i<AC_CAPACITY;i++) {
        struct ac_operation *o=&d->operations[i];
        if (atomic_load_explicit(&o->state,memory_order_acquire)!=AC_ACTIVE ||
            !ac_same_request(&o->identity,a) || o->identity.context!=a->context) continue;
        uint64_t zero=0;
        bound=atomic_compare_exchange_strong_explicit(&o->producer_generation,&zero,
            o->generation,memory_order_release,memory_order_relaxed);
        /* Retirement racing with publication is harmless: slots never recycle. */
        if (atomic_load_explicit(&o->state,memory_order_acquire)!=AC_ACTIVE ||
            atomic_load_explicit(&d->ambiguous_registration,memory_order_acquire)) bound=false;
        break;
    }
done:
    errno=saved_errno; return bound;
}

/* Before real NtWait; only the exact native GOR path, nonalertable and infinite.
 * Integration supplies requested length from the registered provider operation
 * after matching receiver/IOSB/offset, never from stale InternalHigh.
 */
static struct ac_ticket ac_begin_wait(struct ac_domain *d, const struct ac_identity *a,
                                      bool alertable, const void *timeout)
{
    int saved_errno=errno; struct ac_ticket t=ac_no_ticket;
    if (!d || alertable || timeout || !ac_scope(a) || a->guard!=AC_WAIT_PROOF ||
        atomic_load_explicit(&d->ambiguous_registration,memory_order_acquire)) goto done;
    for (unsigned i=0;i<AC_CAPACITY;i++) {
        struct ac_operation *o=&d->operations[i];
        if (atomic_load_explicit(&o->state,memory_order_acquire)!=AC_ACTIVE ||
            !ac_same_request(&o->identity,a)) continue;
        uint32_t zero=0;
        if (atomic_compare_exchange_strong_explicit(&o->waiter_claimed,&zero,1,
            memory_order_acq_rel,memory_order_relaxed)) t=(struct ac_ticket){i,o->generation};
        break;
    }
done:
    errno=saved_errno; return t;
}

/* After the real NtWait. Return value and errno are always the real call's.
 * Core cannot turn a pending/error status into success. It only prevents the
 * proven waiter from reusing its IOSB before that producer's real status store.
 * All timeouts/refusals fall back to the untouched API result and are reported.
 */
static uint32_t ac_finish_wait(struct ac_domain *d, struct ac_ticket t,
                               uint32_t actual_status, const struct ac_callbacks *cb)
{
    int actual_errno=errno;
    struct ac_report r={.outcome=AC_BYPASS,.ticket=t,.actual_status=actual_status,
                        .observed_status=AC_PENDING};
    struct ac_operation *o=ac_lookup(d,t); uint64_t start=0;
    if (!o || actual_status || !cb || !cb->acquire_status || !cb->identity_still_matches ||
        !cb->now_ns || !cb->yield || !cb->maximum_ns || cb->maximum_ns>1000000000ULL)
        goto done;
    if (atomic_load_explicit(&o->producer_generation,memory_order_acquire)!=t.generation) {
        r.outcome=AC_NO_PRODUCER; goto done;
    }
    start=cb->now_ns(cb->opaque);
    if (!start) { r.outcome=AC_CLOCK_FAILURE; goto done; }
    for (;;) {
        if (!ac_lookup(d,t)) { r.outcome=AC_GENERATION_CHANGED; break; }
        if (!cb->identity_still_matches(cb->opaque,&o->identity)) {
            r.outcome=AC_IDENTITY_CHANGED; break;
        }
        if (!cb->acquire_status(cb->opaque,o->identity.iosb,&r.observed_status)) {
            r.outcome=AC_UNREADABLE; break;
        }
        r.loads++;
        if (!ac_lookup(d,t)) { r.outcome=AC_GENERATION_CHANGED; break; }
        if (!cb->identity_still_matches(cb->opaque,&o->identity)) {
            r.outcome=AC_IDENTITY_CHANGED; break;
        }
        if (r.observed_status!=AC_PENDING) {
            uint32_t active=AC_ACTIVE;
            if (!atomic_compare_exchange_strong_explicit(&o->state,&active,AC_RETIRED,
                    memory_order_acq_rel,memory_order_acquire)) {
                r.outcome=AC_GENERATION_CHANGED; break;
            }
            r.outcome=r.loads==1?AC_ALREADY_PUBLISHED:AC_PUBLICATION_OBSERVED; break;
        }
        uint64_t now=cb->now_ns(cb->opaque);
        if (!now || now<start) { r.outcome=AC_CLOCK_FAILURE; break; }
        r.elapsed_ns=now-start;
        if (r.elapsed_ns>=cb->maximum_ns) { r.outcome=AC_TIMEOUT; break; }
        if (r.loads>cb->spin_loads) { cb->yield(cb->opaque); r.yields++; }
    }
done:
    if (o) atomic_store_explicit(&o->state,AC_RETIRED,memory_order_release);
    if (cb && cb->report) cb->report(cb->opaque,&r);
    errno=actual_errno; return actual_status;
}
#endif
