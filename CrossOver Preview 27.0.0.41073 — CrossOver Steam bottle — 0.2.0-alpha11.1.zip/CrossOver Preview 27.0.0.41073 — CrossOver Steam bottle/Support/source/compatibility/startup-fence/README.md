# Startup completion fence

This directory contains the source matching this route. It preserves real Windows
results and waits briefly for actual completion publication on a guarded startup path.
It does not modify game or anti-cheat files. Loader forwarding retains dyld caller identity.

On macOS with Xcode Command Line Tools and Python 3, run:

```sh
python3 build.py --output-dir /absolute/new/build-directory
```

The build uses the adjacent entry and headers plus the parent compatibility headers.
The package payload is the validated build with only install-name/debug-path metadata
made portable and its signature renewed. build-profile.json records both hashes.
A different compiler or SDK may produce a different binary; validate a rebuilt helper
before activation. The script never installs a runtime or launches a game.
Keep the package runtime, CPU/TLS additions and launcher settings together.
