/* Exact native GOR/Wait chain retained from validated lean source. */
#include "wait_signatures.h"
static bool pf_wait_chain(struct pf_wait_identity *w,unsigned char chain[1152])
{
    uint64_t base=w->caller==UINT64_C(0x1402f688b)?UINT64_C(0x1402f6830):UINT64_C(0x1402f6a00);
    const unsigned char *sig=base==UINT64_C(0x1402f6830)?pf_sig_seek:pf_sig_read;
    size_t length=base==UINT64_C(0x1402f6830)?sizeof(pf_sig_seek):sizeof(pf_sig_read);
    if(pf_read(chain,base,length,NULL)!=length || memcmp(chain,sig,length))return false;
    if(pf_read(chain+512,w->kernelbase+0x2e100,288,NULL)!=288 || memcmp(chain+512,pf_sig_gor,288) ||
       pf_read(chain+800,w->kernelbase+0x765f0,165,NULL)!=165 || memcmp(chain+800,pf_sig_wait,165) ||
       pf_read(chain+976,w->ntdll+0xed10,32,NULL)!=32 || memcmp(chain+976,pf_sig_ntwait,32) ||
       pf_read(chain+1064,w->kernelbase+0xd2270,8,NULL)!=8 || pf_u64(chain+1064)!=w->ntdll+0xed10)return false;
    w->slot=UINT64_C(0x15024b5c8);
    if(pf_read(chain+1056,w->slot,8,NULL)!=8)return false;
    w->thunk=pf_u64(chain+1056);
    if(!pf_user_pointer(w->thunk) || pf_read(chain+1008,w->thunk,39,NULL)!=39 ||
       memcmp(chain+1008,pf_sig_encoded,3) || memcmp(chain+1019,pf_sig_encoded+11,3) ||
       memcmp(chain+1026,pf_sig_encoded+18,6) || memcmp(chain+1040,pf_sig_encoded+32,7))return false;
    int32_t disp;memcpy(&disp,chain+1022,4);uint64_t cookie=w->thunk+18+(int64_t)disp;
    if(!pf_user_pointer(cookie) || pf_read(chain+1048,cookie,8,NULL)!=8)return false;
    uint64_t v=pf_u64(chain+1011)+pf_u64(chain+1048);v=(v<<51)|(v>>13);w->target=v^pf_u64(chain+1032);
    uint64_t k32=w->target-0xe8fc;
    static const unsigned char forward[14]={0x48,0x8d,0xa4,0x24,0,0,0,0,0xff,0x25,0x5e,0x5e,0x04,0};
    if(!pf_user_pointer(k32) || (k32&0xffff) || pf_read(chain+1072,w->target,14,NULL)!=14 || memcmp(chain+1072,forward,14) ||
       pf_read(chain+1088,k32+0x54768,8,NULL)!=8 || pf_u64(chain+1088)!=w->kernelbase+0x2e100)return false;
    return true;
}
static bool pf_probe_wait(void *handle,unsigned char alertable,const void *timeout,struct pf_wait_identity *out)
{
    if(alertable||timeout||(__atomic_load_n(&pf_done,__ATOMIC_RELAXED)&3)==3)return false;
    uint64_t now=pf_now();if(!pf_in_window(now))return false;
    struct pf_open_record *opened[2]={__atomic_load_n(&pf_wait_opened[0],__ATOMIC_ACQUIRE),__atomic_load_n(&pf_wait_opened[1],__ATOMIC_ACQUIRE)};
    bool armed=false;for(unsigned i=0;i<2;i++)if(opened[i]&&now>=opened[i]->exit_ns&&now-opened[i]->exit_ns<=PF_QPC_ARM_NS)armed=true;
    if(!armed||__atomic_fetch_add(&pf_wait_prefilters,1,__ATOMIC_RELAXED)>=1024)return false;
    unsigned char teb[104],frame[176],stack[184];uint64_t fp=0,t=(uint64_t)pf_current_teb();
    if(pf_read(teb,t,104,NULL)!=104||pf_u64(teb+0x30)!=t||pf_read(&fp,t+0x378,8,NULL)!=8||pf_read(frame,fp,176,NULL)!=176)return false;
    uint64_t sp=pf_u64(frame+0x88),pc=pf_u64(frame+0x70);
    if((sp&7)||sp<pf_u64(teb+0x10)||sp>pf_u64(teb+8)||pf_u64(teb+8)-sp<184||pf_read(stack,sp,184,NULL)!=184)return false;
    uint64_t kb=pf_u64(stack)-0x7663d,ntdll=pc-0xed24,caller=pf_u64(stack+0xb0);
    if(!pf_user_pointer(kb)||(kb&0xffff)||!pf_user_pointer(ntdll)||(ntdll&0xffff)||pf_u64(stack+0x50)!=kb+0x2e14c||
       !(caller==UINT64_C(0x1402f688b)||caller==UINT64_C(0x1402f6a71)||caller==UINT64_C(0x1402f6bd5)))return false;
    uint64_t receiver=caller==UINT64_C(0x1402f688b)?pf_u64(frame+0x60):pf_u64(stack+0x98),overlapped=pf_u64(frame+8);
    unsigned char head[24];if(!pf_user_pointer(receiver)||overlapped!=receiver+0x58||pf_read(head,receiver,24,NULL)!=24||
       pf_u64(head)!=UINT64_C(0x14d0e7d70)||pf_u64(head+8)!=(uint64_t)handle)return false;
    uint64_t size=pf_u64(head+16);unsigned kind=size==315971?1:size==365?2:0;if(!kind)return false;
    struct pf_open_record *source=opened[kind-1];
    if(!source||now<source->exit_ns||now-source->exit_ns>PF_QPC_ARM_NS||(__atomic_load_n(&pf_done,__ATOMIC_RELAXED)&kind)||
       __atomic_load_n(&pf_wait_counts[kind-1],__ATOMIC_RELAXED)>=3)return false;
    if(__atomic_fetch_add(&pf_wait_validations,1,__ATOMIC_RELAXED)>=8)return false;
    struct pf_wait_identity w={.flags=1,.handle=(uint64_t)handle,.receiver=receiver,.overlapped=overlapped,.kernelbase=kb,.ntdll=ntdll,.caller=caller,.kind=kind};
    unsigned char chain[1152];if(!pf_wait_chain(&w,chain))return false;
    w.flags|=2;if(__atomic_fetch_add(&pf_wait_counts[kind-1],1,__ATOMIC_RELAXED)>=3)return false;*out=w;return true;
}
