/* Unchanged lifecycle core, with the validated lean receiver/provider guards. */
static bool pf_target_read(void *opaque,uint64_t address,void *out,size_t bytes)
{(void)opaque;return pf_read(out,address,bytes,NULL)==bytes;}
static bool pf_event_before(unsigned api,void *handle,void *previous,struct ac_identity *out)
{
    if(!pf_enabled||previous||(__atomic_load_n(&pf_done,__ATOMIC_RELAXED)&3)==3)return false;
    if(!__atomic_load_n(&pf_wait_opened[0],__ATOMIC_ACQUIRE)&&!__atomic_load_n(&pf_wait_opened[1],__ATOMIC_ACQUIRE))return false;
    uint64_t now=pf_now();if(!pf_in_window(now))return false;
    uint64_t teb=(uint64_t)pf_current_teb(),frame_address=0;unsigned char th[104],frame[176];
    if(pf_read(th,teb,sizeof(th),NULL)!=sizeof(th)||pf_u64(th+0x30)!=teb||pf_u64(th+0x10)>=pf_u64(th+8)||
       pf_read(&frame_address,teb+0x378,8,NULL)!=8||pf_read(frame,frame_address,sizeof(frame),NULL)!=sizeof(frame)||
       !ac_provider_identity(pf_target_read,NULL,frame,pf_u64(th+0x10),pf_u64(th+8),api,(uint64_t)handle,(uint64_t)previous,out))return false;
    unsigned kind=out->file_size==315971?1:2;struct pf_open_record *opened=__atomic_load_n(&pf_wait_opened[kind-1],__ATOMIC_ACQUIRE);
    if(!opened||now<opened->exit_ns||now-opened->exit_ns>PF_QPC_ARM_NS||(__atomic_load_n(&pf_done,__ATOMIC_RELAXED)&kind))return false;
    return api==7?ac_bind_producer(&pf_domain,out):true;
}
static bool pf_status(void *opaque,uint64_t iosb,uint32_t *status)
{
    (void)opaque;uint32_t probe;if((iosb&3)||pf_read(&probe,iosb,4,NULL)!=4)return false;
    /* The exact synchronous native waiter owns this receiver until return. */
    *status=__atomic_load_n((const uint32_t *)(uintptr_t)iosb,__ATOMIC_ACQUIRE);return true;
}
static bool pf_identity(void *opaque,const struct ac_identity *id)
{
    (void)opaque;unsigned char h[128];
    return id&&id->iosb==id->receiver+0x58&&pf_read(h,id->receiver,sizeof(h),NULL)==sizeof(h)&&
        pf_u64(h)==UINT64_C(0x14d0e7d70)&&pf_u64(h+8)==id->handle&&pf_u64(h+0x10)==id->file_size&&
        pf_u32(h+0x38)==65536&&pf_u64(h+0x68)==id->offset&&!pf_u64(h+0x70);
}
static uint64_t pf_clock(void *opaque){(void)opaque;return pf_now();}
static void pf_yield(void *opaque){(void)opaque;(void)sched_yield();}
static status_t pf_wait(void *handle,unsigned char alertable,const void *timeout)
{
    if(pf_recursing||!pf_enabled)return pf_real_wait(handle,alertable,timeout);
    int incoming=errno;pf_recursing=1;struct pf_wait_identity w={0};struct ac_ticket ticket=ac_no_ticket;
    if(pf_probe_wait(handle,alertable,timeout,&w)){struct ac_identity id={0};
        if((w.flags&3)==3&&ac_wait_identity_from_registered(&pf_domain,pf_target_read,NULL,w.receiver,w.handle,w.overlapped,true,&id))
            ticket=ac_begin_wait(&pf_domain,&id,false,NULL);}
    /* Unselected/alertable waits may return nonlocally. Do not retain TLS there. */
    if(ticket.slot>=AC_CAPACITY){pf_recursing=0;errno=incoming;return pf_real_wait(handle,alertable,timeout);}
    errno=incoming;status_t actual=pf_real_wait(handle,alertable,timeout);int outgoing=errno;
    const struct ac_callbacks callbacks={.opaque=&pf_domain.operations[ticket.slot].identity,.acquire_status=pf_status,
        .identity_still_matches=pf_identity,.now_ns=pf_clock,.yield=pf_yield,.maximum_ns=100000000,.spin_loads=8};
    actual=(status_t)ac_finish_wait(&pf_domain,ticket,(uint32_t)actual,&callbacks);
    pf_recursing=0;errno=outgoing;return actual;
}
static status_t pf_event(unsigned api,void *handle,void *previous)
{
    status_t (*real)(void *,void *)=api==7?pf_real_setevent:pf_real_resetevent;
    if(pf_recursing)return real(handle,previous);
    int incoming=errno;pf_recursing=1;struct ac_identity id={0};bool selected=pf_event_before(api,handle,previous,&id);
    if(!selected){pf_recursing=0;errno=incoming;return real(handle,previous);}
    errno=incoming;status_t actual=real(handle,previous);int outgoing=errno;
    if(api==8)(void)ac_register_operation(&pf_domain,&id,(uint32_t)actual);
    pf_recursing=0;errno=outgoing;return actual;
}
static status_t pf_setevent(void *handle,void *previous){return pf_event(7,handle,previous);}
static status_t pf_resetevent(void *handle,void *previous){return pf_event(8,handle,previous);}
