#!/usr/bin/env python3
"""Build this package's own startup helper into a fresh directory on macOS."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
from macho_metadata import normalize, verify


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    profile = json.loads((here / 'build-profile.json').read_text())
    output = args.output_dir.resolve()
    if output.exists():
        raise SystemExit('Choose a new output directory; existing files are never overwritten.')
    output.mkdir(parents=True)
    library = output / profile['filename']
    command = ['/usr/bin/clang', '-arch', 'x86_64', '-O2', '-g', '-dynamiclib',
               '-Wall', '-Wextra', *profile['compiler_flags'], '-I', '.', '-I', '..',
               'entry.c', '-Wl,-install_name,@rpath/' + profile['filename'], '-o', str(library)]
    subprocess.run(command, cwd=here, check=True)
    subprocess.run(['/usr/bin/codesign', '--force', '--sign', '-', str(library)], check=True)
    before = library.read_bytes()
    changed, edits = normalize(before, '@rpath/' + profile['filename'])
    library.write_bytes(changed)
    subprocess.run(['/usr/bin/codesign', '--force', '--sign', '-', str(library)], check=True)
    subprocess.run(['/usr/bin/codesign', '--verify', '--strict', str(library)], check=True)
    proof = verify(before, library.read_bytes())
    print(json.dumps({'output': str(library), 'sha256': hashlib.sha256(library.read_bytes()).hexdigest(),
                      'metadata_edits': edits, 'validation': proof}, indent=2))


if __name__ == '__main__':
    main()
