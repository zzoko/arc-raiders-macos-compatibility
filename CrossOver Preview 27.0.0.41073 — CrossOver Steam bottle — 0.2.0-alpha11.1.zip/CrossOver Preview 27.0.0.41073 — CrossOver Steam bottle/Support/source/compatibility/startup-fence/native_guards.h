/* Read-only current-build provider guards. Caller must separately validate the
 * game/process and preserved Wine service chain before enabling this candidate.
 */
#ifndef ARC_ASYNC_NATIVE_GUARDS_H
#define ARC_ASYNC_NATIVE_GUARDS_H
#include <stddef.h>
#include <string.h>
#include "async_completion_fence.h"

typedef bool (*ac_read_bytes)(void *opaque, uint64_t address, void *out, size_t bytes);
static uint64_t ac_u64(const void *p) { uint64_t v; memcpy(&v,p,8); return v; }
static uint32_t ac_u32(const void *p) { uint32_t v; memcpy(&v,p,4); return v; }
static bool ac_user_pointer(uint64_t p) { return p>=0x10000 && p<UINT64_C(0x0000800000000000); }
/* IOSB Status/Information are the producer's mutable publication words.
 * They may change during guard reads without changing the operation identity.
 * Every other byte, including buffers, offset, event and ownership, must agree. */
static bool ac_same_receiver_identity(const unsigned char a[128],const unsigned char b[128])
{
    return !memcmp(a,b,0x58) && !memcmp(a+0x68,b+0x68,128-0x68);
}
static bool ac_signature(ac_read_bytes read,void *opaque,uint64_t p,const unsigned char *expected,size_t n)
{
    unsigned char got[32];
    return n<=sizeof(got) && ac_user_pointer(p) && read(opaque,p,got,n) && !memcmp(got,expected,n);
}
static bool ac_provider_code(ac_read_bytes read,void *opaque,uint64_t pc,unsigned api)
{
    static const unsigned char syscall[10]={0x44,0x89,0xc0,0x49,0x89,0xca,0x31,0xd2,0x0f,0x05};
    static const unsigned char set_after[14]={0x48,0x8b,0x4c,0x24,0x58,0x48,0x8b,0x49,0x28,0x48,0x85,0xc9,0x74,0x34};
    static const unsigned char set_status[23]={0x48,0x8b,0x4c,0x24,0x58,0x48,0x8b,0x41,0x38,0x48,0x85,0xc0,0x74,0x09,0x31,0xc9,0x87,0x08,0x48,0x8b,0x4c,0x24,0x58};
    static const unsigned char set_info[26]={0x48,0x8b,0x4c,0x24,0x58,0x48,0x8b,0x41,0x38,0x48,0x85,0xc0,0x74,0x0c,0x4c,0x89,0xf1,0x48,0x87,0x48,0x08,0x48,0x8b,0x4c,0x24,0x58};
    static const unsigned char reset_after[16]={0x48,0x89,0xc1,0x31,0xc0,0x85,0xc9,0x0f,0x48,0xc1,0x0f,0x88,0xe9,0,0,0};
    static const unsigned char reset_before[17]={0x48,0x8b,0x44,0x24,0x58,0x48,0x89,0x58,0x50,0x48,0x89,0x70,0x58,0x48,0x8b,0x40,0x20};
    static const unsigned char reset_next[9]={0x4c,0x8b,0x44,0x24,0x58,0x49,0x8b,0x40,0x20};
    if (!read || !ac_user_pointer(pc) || pc<0x100a4 || pc>UINT64_MAX-0x80 ||
        !ac_signature(read,opaque,pc-10,syscall,sizeof(syscall))) return false;
    if (api==7) return ac_signature(read,opaque,pc,set_after,sizeof(set_after)) &&
        ac_signature(read,opaque,pc+0x42,set_status,sizeof(set_status)) &&
        ac_signature(read,opaque,pc-0xa4,set_info,sizeof(set_info));
    if (api==8) return ac_signature(read,opaque,pc,reset_after,sizeof(reset_after)) &&
        ac_signature(read,opaque,pc-0x49,reset_before,sizeof(reset_before)) &&
        ac_signature(read,opaque,pc+0x10,reset_next,sizeof(reset_next));
    return false;
}

/* frame is a complete already validated 176-byte Wine syscall frame. Its RSP
 * belongs to the stopped guest caller on this same thread. All provider data is
 * read before the real event call; no retired operation is followed afterward.
 */
static bool ac_provider_identity(ac_read_bytes read,void *opaque,
                                  const unsigned char frame[176],uint64_t stack_low,uint64_t stack_high,
                                  unsigned api,uint64_t actual_handle,uint64_t previous_state,
                                  struct ac_identity *out)
{
    int saved_errno=errno; bool ok=false;
    if (!read || !frame || !out || previous_state || !(api==7 || api==8)) goto done;
    uint64_t pc=ac_u64(frame+0x70),sp=ac_u64(frame+0x88),context=0,iosb=0;
    if ((sp&7) || sp<stack_low || sp>stack_high || stack_high-sp<0x60 ||
        !ac_provider_code(read,opaque,pc,api) || !read(opaque,sp+0x58,&context,8) ||
        !ac_user_pointer(context) || context>UINT64_MAX-0x80 ||
        !read(opaque,context+0x38,&iosb,8) || iosb<0x10058 || (iosb&7)) goto done;
    unsigned char request[16],header[128],request_again[16],again[128];
    uint64_t context_again=0,iosb_again=0,receiver=iosb-0x58;
    if (!read(opaque,context+0x70,request,16) || !read(opaque,receiver,header,128)) goto done;
    struct ac_identity a={.handle=actual_handle,.receiver=receiver,.iosb=iosb,.context=context,
        .requested=ac_u64(request),.offset=ac_u64(request+8),.file_size=ac_u64(header+0x10),
        .guard=api==7?AC_PRODUCER_PROOF:AC_RESET_PROOF};
    if (!ac_scope(&a) || ac_u64(header)!=UINT64_C(0x14d0e7d70) ||
        ac_u64(header+8)!=actual_handle || ac_u32(header+0x38)!=65536 ||
        ac_u32(header+0x3c)>1 || ac_u32(header+0x40)>1 || ac_u32(header+0x48)>1 ||
        ac_u64(header+0x68)!=a.offset || ac_u64(header+0x70)!=0 ||
        !ac_user_pointer(ac_u64(header+0x28)) || !ac_user_pointer(ac_u64(header+0x30))) goto done;
    if (!read(opaque,sp+0x58,&context_again,8) || context_again!=context ||
        !read(opaque,context+0x38,&iosb_again,8) || iosb_again!=iosb ||
        !read(opaque,context+0x70,request_again,16) || memcmp(request,request_again,16) ||
        !read(opaque,receiver,again,128) || !ac_same_receiver_identity(header,again) ||
        !ac_provider_code(read,opaque,pc,api)) goto done;
    *out=a; ok=true;
done:
    errno=saved_errno; return ok;
}

/* Called only after the existing exact native GOR/Wait-chain validator passes.
 * Native frame/return-PC signatures are validated by that integration. Requested
 * length is copied from the registered operation, never InternalHigh.
 */
static bool ac_wait_identity_from_registered(struct ac_domain *d,ac_read_bytes read,void *opaque,
                                               uint64_t receiver,uint64_t handle,uint64_t iosb,
                                               bool exact_native_chain,struct ac_identity *out)
{
    int saved_errno=errno; bool ok=false; unsigned char header[128],again[128];
    if (!d || !read || !out || !exact_native_chain || !ac_user_pointer(receiver) ||
        receiver>UINT64_MAX-0x80 || iosb!=receiver+0x58 ||
        atomic_load_explicit(&d->ambiguous_registration,memory_order_acquire) ||
        !read(opaque,receiver,header,128)) goto done;
    if (ac_u64(header)!=UINT64_C(0x14d0e7d70) || ac_u64(header+8)!=handle ||
        ac_u32(header+0x38)!=65536 || ac_u64(header+0x70)!=0) goto done;
    for (unsigned i=0;i<AC_CAPACITY;i++) {
        struct ac_operation *o=&d->operations[i];
        if (atomic_load_explicit(&o->state,memory_order_acquire)!=AC_ACTIVE ||
            o->identity.receiver!=receiver || o->identity.handle!=handle || o->identity.iosb!=iosb ||
            o->identity.offset!=ac_u64(header+0x68) || o->identity.file_size!=ac_u64(header+0x10)) continue;
        if (!read(opaque,receiver,again,128) || !ac_same_receiver_identity(header,again) ||
            atomic_load_explicit(&o->state,memory_order_acquire)!=AC_ACTIVE) goto done;
        *out=o->identity; out->guard=AC_WAIT_PROOF; ok=true; break;
    }
done:
    errno=saved_errno; return ok;
}
#endif
