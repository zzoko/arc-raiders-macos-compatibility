"""Portable Mach-O metadata cleanup; executable/data sections are immutable."""
import struct
from pathlib import PurePosixPath


def layout(data):
    if len(data) < 32 or struct.unpack_from('<II', data) != (0xFEEDFACF, 0x1000007):
        raise ValueError('Expected x86_64 Mach-O')
    count, size = struct.unpack_from('<II', data, 16)
    pos = 32
    commands, sections, symbols = [], [], []
    for _ in range(count):
        cmd, length = struct.unpack_from('<II', data, pos)
        if length < 8 or pos + length > 32 + size:
            raise ValueError('Invalid Mach-O command')
        commands.append((cmd, pos, length, bytes(data[pos:pos + length])))
        if cmd == 0x19:
            nsects = struct.unpack_from('<I', data, pos + 64)[0]
            for i in range(nsects):
                s = struct.unpack_from('<16s16sQQ8I', data, pos + 72 + 80 * i)
                name = s[1].rstrip(b'\0').decode() + ',' + s[0].rstrip(b'\0').decode()
                zero = (s[8] & 0xff) in (1, 12, 18)
                payload = b'' if zero else bytes(data[s[4]:s[4] + s[3]])
                sections.append((name, s[2:], payload))
        elif cmd == 2:
            symoff, nsyms, stroff, strsize = struct.unpack_from('<IIII', data, pos + 8)
            for i in range(nsyms):
                at = symoff + 16 * i
                idx, kind = struct.unpack_from('<IB', data, at)
                if idx >= strsize:
                    raise ValueError('Invalid symbol string')
                start = stroff + idx
                end = data.find(b'\0', start, stroff + strsize)
                if end < 0:
                    raise ValueError('Unterminated symbol')
                symbols.append((kind, start, end + 1, bytes(data[start:end]), bytes(data[at:at + 16])))
        pos += length
    if pos != 32 + size:
        raise ValueError('Invalid command total')
    return commands, sections, symbols


def normalize(data, install_name):
    commands, _, symbols = layout(data)
    changed = bytearray(data)
    edits = []
    ids = [c for c in commands if c[0] == 13]
    if len(ids) != 1 or not install_name.startswith('@rpath/'):
        raise ValueError('Expected one portable dylib install name')
    _, at, length, _ = ids[0]
    name_offset = struct.unpack_from('<I', data, at + 8)[0]
    start, end = at + name_offset, at + length
    replacement = install_name.encode() + b'\0'
    if len(replacement) > end - start:
        raise ValueError('Portable name exceeds original command allocation')
    changed[start:end] = replacement.ljust(end - start, b'\0')
    edits.append({'kind': 'LC_ID_DYLIB', 'start': start, 'end': end})
    seen = set()
    for kind, start, end, name, _ in symbols:
        if not kind & 0xe0 or not name.startswith(b'/') or start in seen:
            continue
        seen.add(start)
        if any(not other_kind & 0xe0 and start <= other_start < end
               for other_kind, other_start, _, _, _ in symbols):
            raise ValueError('Debug path overlaps a runtime symbol name')
        replacement = b'./' if name.endswith(b'/') else (
            b'entry.o' if kind == 0x66 else PurePosixPath(name.decode()).name.encode())
        if len(replacement) + 1 > end - start:
            raise ValueError('Portable debug name exceeds original allocation')
        changed[start:end] = (replacement + b'\0').ljust(end - start, b'\0')
        edits.append({'kind': 'debug-path', 'start': start, 'end': end})
    return bytes(changed), edits


def verify(before, after):
    bc, bs, bn = layout(before)
    ac, ass, an = layout(after)
    if bs != ass:
        raise ValueError('A runtime section or its layout changed')
    if len(bc) != len(ac):
        raise ValueError('Load-command count changed')
    for old, new in zip(bc, ac):
        if old[:3] != new[:3]:
            raise ValueError('Load-command position or size changed')
        if old[0] != 13 and old[3] != new[3]:
            raise ValueError('Non-ID load command changed: ' + hex(old[0]))
    if [(s[0], s[4]) for s in bn] != [(s[0], s[4]) for s in an]:
        raise ValueError('Symbol entries changed')
    if [s for s in bn if not s[0] & 0xe0] != [s for s in an if not s[0] & 0xe0]:
        raise ValueError('Runtime imports/exports changed')
    for component in ('Users', 'var/folders', 'research', 'Documents'):
        token = ('/' + component + '/').encode()
        if token in after:
            raise ValueError('Private path remains in payload')
    return {'all_sections_and_layout_unchanged': True,
            'all_non_id_load_commands_unchanged': True,
            'symbol_entries_and_runtime_imports_exports_unchanged': True,
            'private_build_paths_removed': True}
