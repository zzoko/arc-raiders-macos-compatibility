/* Exact post-Pak constructor chain retained from validated lean source. */
#include "qpc_signatures.h"
static bool pf_clock_chain(uint64_t ntdll,unsigned char *chain,struct pf_clock_identity *pk)
{
    if(!pf_user_pointer(ntdll) || (ntdll&0xffff))return false;
    if(pf_read(chain,UINT64_C(0x141d8cf00),64,NULL)!=64 || memcmp(chain,pf_sig_ctor,64) ||
       pf_read(chain+64,UINT64_C(0x1401e8c20),7,NULL)!=7 || memcmp(chain+64,pf_sig_timer,7) ||
       pf_read(chain+204,UINT64_C(0x141d8cbeb),3,NULL)!=3 || memcmp(chain+204,pf_sig_rsi,3))return false;
    uint64_t thunk=0;
    if(pf_read(&thunk,UINT64_C(0x15024b8c8),8,NULL)!=8 || !pf_user_pointer(thunk) ||
       pf_read(chain+71,thunk,39,NULL)!=39 || (memcmp(chain+71,pf_sig_encoded,3) || memcmp(chain+82,pf_sig_encoded+11,3) || memcmp(chain+89,pf_sig_encoded+18,6) || memcmp(chain+103,pf_sig_encoded+32,7)))return false;
    int32_t disp;memcpy(&disp,chain+85,4);
    uint64_t cookie_address=thunk+18+(int64_t)disp;
    if(!pf_user_pointer(cookie_address) || pf_read(chain+110,cookie_address,8,NULL)!=8)return false;
    uint64_t value=pf_u64(chain+74)+pf_u64(chain+110);
    value=(value<<51)|(value>>13);
    uint64_t target=value^pf_u64(chain+95),kernel32=target-0xfd24;
    if(!pf_user_pointer(kernel32) || (kernel32&0xffff) ||
       pf_read(chain+118,target,14,NULL)!=14 || memcmp(chain+118,pf_sig_forward,14) ||
       pf_read(chain+132,kernel32+0x54e90,8,NULL)!=8 || pf_u64(chain+132)!=ntdll+0x34c10 ||
       pf_read(chain+140,ntdll+0x34c10,32,NULL)!=32 || memcmp(chain+140,pf_sig_rtl,32) ||
       pf_read(chain+172,ntdll+0xf2b0,32,NULL)!=32 || memcmp(chain+172,pf_sig_nt,32))return false;
    pk->ntdll=ntdll;pk->kernel32=kernel32;pk->thunk=thunk;pk->target=target;
    pk->flags|=128;return true;
}
static void pf_checkpoint(void)
{
    struct pf_open_record *opened=pf_qpc_opened;
    if(!opened||(__atomic_load_n(&pf_done,__ATOMIC_RELAXED)&3)==3)return;
    unsigned kind=opened->kind;if(!kind||(__atomic_load_n(&pf_done,__ATOMIC_RELAXED)&kind))return;
    uint64_t now=pf_now();
    if(!pf_in_window(now)||now<opened->exit_ns||now-opened->exit_ns>PF_QPC_ARM_NS||++pf_qpc_prefilters>PF_QPC_PREFILTER_LIMIT){pf_qpc_opened=NULL;return;}
    unsigned char teb[104],frame[176],checkpoint[56];uint64_t fp=0,t=(uint64_t)pf_current_teb();
    if(pf_read(teb,t,sizeof(teb),NULL)!=sizeof(teb)||pf_u64(teb+0x30)!=t||
       pf_u64(teb+0x48)!=opened->windows_tid||pf_u64(teb+0x40)!=opened->windows_pid||
       pf_read(&fp,t+0x378,8,NULL)!=8||pf_read(frame,fp,sizeof(frame),NULL)!=sizeof(frame))return;
    uint64_t sp=pf_u64(frame+0x88),pak=pf_u64(frame+0x20);
    if(!sp||(sp&7)||sp<pf_u64(teb+0x10)||sp>pf_u64(teb+8)||pf_u64(teb+8)-sp<sizeof(checkpoint)||
       pf_read(checkpoint,sp,sizeof(checkpoint),NULL)!=sizeof(checkpoint)||pf_u64(checkpoint+0x30)!=UINT64_C(0x141d8cf38))return;
    pf_qpc_opened=NULL;
    if(__atomic_fetch_add(&pf_qpc_validations,1,__ATOMIC_RELAXED)>=PF_QPC_VALIDATION_LIMIT)return;
    unsigned char chain[256]={0};struct pf_clock_identity identity={0};uint64_t ntdll=pf_u64(checkpoint)-0x34c23;
    if(!pf_user_pointer(pak)||!pf_clock_chain(ntdll,chain,&identity))return;
    unsigned char filename[16];uint16_t name[512];
    if(pf_read(filename,pak+0x18,16,NULL)!=16)return;
    uint64_t buffer=pf_u64(filename);uint32_t num=pf_u32(filename+8),cap=pf_u32(filename+12);
    if(!pf_user_pointer(buffer)||num<2||num>512||cap<num||cap>65536||
       pf_read(name,buffer,num*2,NULL)!=num*2||name[num-1]!=0||pf_name(name,num-1)!=kind)return;
    /* The exact post-constructor checkpoint is the retirement boundary. Pak
     * validity was only logged by the old observer; it never gated retirement. */
    __atomic_fetch_or(&pf_done,kind,__ATOMIC_RELAXED);pf_retire_kind(kind);
}
static status_t pf_qpc(void *counter,void *frequency)
{
    if(pf_recursing)return pf_real_qpc(counter,frequency);
    int incoming=errno;pf_recursing=1;pf_checkpoint();errno=incoming;
    status_t result=pf_real_qpc(counter,frequency);int outgoing=errno;pf_recursing=0;errno=outgoing;return result;
}
