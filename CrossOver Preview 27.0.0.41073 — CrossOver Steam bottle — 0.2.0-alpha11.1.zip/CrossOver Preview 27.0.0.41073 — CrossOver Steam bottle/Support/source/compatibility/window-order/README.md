# Window cleanup lock ordering

The 41-byte repair removes the dying window from its protected dictionary, releases
the window-data mutex, then releases its D3DMetal surface collection. Data is freed
last. This avoids the opposite window/client-surface lock acquisition order while
preserving collection ownership and destruction. Full input/function/UUID guards
are in profiles.json; unsupported builds are refused.

```sh
python3 build.py --input /absolute/private/winemac.so --output-dir /absolute/new/output
```

Requires macOS, Python 3 and Command Line Tools. It preserves the original, verifies
branch/call targets and unchanged code/unwind sections, signs the new copy and checks
the release output hash. It does not modify the source or activate the result.
