#!/usr/bin/env python3
"""Reproduce the guarded window cleanup patch in a new private copy."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'startup-fence'))
from macho_metadata import layout


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    profiles = json.loads((here / 'profiles.json').read_text())
    source = args.input.resolve()
    before = source.read_bytes()
    profile = next((v for v in profiles.values() if v['input_sha256'] == digest(before)), None)
    if profile is None:
        raise SystemExit('Unsupported or already patched winemac input.')
    commands, sections, _ = layout(before)
    uuid = next(c[3][8:24].hex() for c in commands if c[0] == 0x1b)
    start, end = profile['function_range']
    at = profile['patch_offset']
    old, new = bytes.fromhex(profile['old_bytes']), bytes.fromhex(profile['new_bytes'])
    require(uuid == profile['uuid'].replace('-', '').lower(), 'UUID mismatch')
    require(digest(before[start:end]) == profile['function_sha256'], 'Function mismatch')
    require(before[start:start + len(bytes.fromhex(profile['prologue']))] == bytes.fromhex(profile['prologue']), 'Prologue mismatch')
    require(len(old) == len(new) == 41 and before[at:at + 41] == old, 'Instruction block mismatch')
    require(before[at + 41:at + 41 + len(bytes.fromhex(profile['free_tail']))] == bytes.fromhex(profile['free_tail']), 'Cleanup tail mismatch')
    output = args.output_dir.resolve()
    if output.exists():
        raise SystemExit('Choose a new output directory; nothing is overwritten.')
    output.mkdir(parents=True)
    (output / 'original-winemac.so').write_bytes(before)
    changed = bytearray(before)
    changed[at:at + 41] = new
    for instruction, width, displacement, target in profile['targets']:
        require(instruction + width + struct.unpack_from('<i', changed, instruction + displacement)[0] == target, 'Call target mismatch')
    branch = profile['null_branch']
    require(changed[branch:branch + 2] == b'\x74\x05' and branch + 7 == at + 41, 'Null branch mismatch')
    candidate = output / 'winemac.so'
    candidate.write_bytes(changed)
    subprocess.run(['/usr/bin/codesign', '--force', '--sign', '-', str(candidate)], check=True)
    subprocess.run(['/usr/bin/codesign', '--verify', '--strict', str(candidate)], check=True)
    after = candidate.read_bytes()
    _, after_sections, _ = layout(after)
    require(len(sections) == len(after_sections), 'Section count changed')
    for (name, meta, body), (after_name, after_meta, after_body) in zip(sections, after_sections):
        require(name == after_name and meta == after_meta, 'Section layout changed')
        if name == '__TEXT,__text':
            expected = bytearray(body)
            expected[at - meta[2]:at + 41 - meta[2]] = new
            require(bytes(expected) == after_body, 'Unexpected executable change')
        else:
            require(body == after_body, 'Unrelated section changed')
    require(digest(after) == profile['output_sha256'], 'Signature/toolchain output differs from the release recipe')
    require(source.read_bytes() == before, 'Original input changed')
    print(json.dumps({'output': str(candidate), 'sha256': digest(after),
                      'original_preserved': True, 'no_install_or_launch': True}, indent=2))


if __name__ == '__main__':
    main()
